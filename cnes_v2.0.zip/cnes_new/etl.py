#!/usr/bin/env python3
"""
Pipeline ETL para dados do CNES.

Extrai dados do DATASUS via PySUS, transforma com Polars e salva em S3.
"""
import sys
import logging
import argparse
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import PREFIXOS, PREFIXO_DESCRICAO, UFS
from extracao import download_cnes, get_previous_month
from transformacao import transform, create_semantic_view
from storage import upload_parquet, file_exists
from utils import setup_logging, save_execution_summary

logger = logging.getLogger(__name__)


def run(
    ano: int | None = None,
    mes: int | None = None,
    prefixos: list[str] | None = None,
    ufs: list[str] | None = None,
    force: bool = False,
    upload_logs_s3: bool = True,
) -> dict[str, int]:
    """Executa pipeline ETL completo: extracao, transformacao e carga."""
    if ano is None or mes is None:
        ano, mes = get_previous_month()

    prefixos = prefixos or PREFIXOS
    resultado = {}

    # Configurar logging com arquivos
    log_file, summary_file = setup_logging(ano, mes, upload_to_s3=upload_logs_s3)
    inicio_execucao = time.time()

    logger.info(f"Iniciando ETL para {mes:02d}/{ano}")
    logger.info(f"Prefixos: {prefixos}")
    logger.info(f"UFs: {ufs or 'Todas'}")

    for prefixo in prefixos:
        desc = PREFIXO_DESCRICAO.get(prefixo, prefixo)
        logger.info(f"--- Processando {prefixo} ({desc}) ---")

        if not force and file_exists(prefixo, ano, mes):
            logger.info(f"{prefixo}: Ja existe no S3, pulando (use --force para reprocessar)")
            resultado[prefixo] = -1
            continue

        try:
            downloads = download_cnes(ano, mes, [prefixo], ufs)
            arquivos = downloads.get(prefixo, [])

            if not arquivos:
                logger.warning(f"{prefixo}: Nenhum arquivo disponivel")
                resultado[prefixo] = 0
                continue

            df = transform(prefixo, arquivos, ano, mes)

            if df.is_empty():
                logger.warning(f"{prefixo}: DataFrame vazio apos transformacao")
                resultado[prefixo] = 0
                continue

            upload_parquet(df, prefixo, ano, mes, layer="raw")
            logger.info(f"{prefixo}: {len(df)} registros salvos na camada raw")

            view_semantica = create_semantic_view(prefixo, df)
            upload_parquet(view_semantica, prefixo, ano, mes, layer="semantic")
            logger.info(f"{prefixo}: {len(view_semantica)} registros salvos na camada semantic")

            resultado[prefixo] = len(df)
            logger.info(f"{prefixo}: Processamento completo")

        except Exception as e:
            logger.error(f"{prefixo}: Erro - {e}", exc_info=True)
            resultado[prefixo] = -1

    # Calcular tempo de execucao
    tempo_execucao = time.time() - inicio_execucao

    logger.info("=" * 50)
    logger.info("RESUMO:")
    for pref, qtd in resultado.items():
        status = "OK" if qtd > 0 else ("SKIP" if qtd == -1 else "VAZIO")
        logger.info(f"  {pref}: {qtd} registros ({status})")
    logger.info(f"Tempo total: {tempo_execucao:.2f} segundos")

    # Salvar resumo JSON
    save_execution_summary(
        summary_file=summary_file,
        log_file=log_file,
        ano=ano,
        mes=mes,
        resultado=resultado,
        prefixos=prefixos,
        ufs=ufs,
        tempo_execucao=tempo_execucao,
        upload_to_s3=upload_logs_s3,
    )

    return resultado


def main():
    """Ponto de entrada CLI."""
    parser = argparse.ArgumentParser(
        description="CNES ETL - Extrai dados do DATASUS e salva em S3"
    )
    parser.add_argument(
        "--ano", type=int,
        help="Ano de referencia (YY)"
    )
    parser.add_argument(
        "--mes", type=int,
        help="Mes de referencia (1-12)"
    )
    parser.add_argument(
        "--prefixos", nargs="+", choices=PREFIXOS,
        help="Prefixos a processar (ST, PF, EQ, SR)"
    )
    parser.add_argument(
        "--uf", nargs="+", choices=UFS,
        help="UFs para filtrar"
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Reprocessar mesmo se ja existir no S3"
    )
    parser.add_argument(
        "--no-s3-logs", action="store_true",
        help="Nao enviar logs para S3 (apenas local)"
    )

    args = parser.parse_args()

    ufs = [u.upper() for u in args.uf] if args.uf else None

    run(
        ano=args.ano,
        mes=args.mes,
        prefixos=args.prefixos,
        ufs=ufs,
        force=args.force,
        upload_logs_s3=not args.no_s3_logs,
    )


if __name__ == "__main__":
    main()
