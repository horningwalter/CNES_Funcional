#!/usr/bin/env python3
"""
Script de validacao do ambiente para CNES ETL.
Verifica dependencias, credenciais AWS e configuracoes.
"""
import sys
import logging
from pathlib import Path

# Adiciona diretorio ao path
sys.path.insert(0, str(Path(__file__).parent))

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s"
)
logger = logging.getLogger(__name__)


def check_python_version():
    """Verifica versao minima do Python."""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 10):
        logger.error(f"Python 3.10+ requerido. Versao atual: {version.major}.{version.minor}")
        return False
    logger.info(f"✓ Python {version.major}.{version.minor}.{version.micro}")
    return True


def check_dependencies():
    """Verifica pacotes Python necessarios."""
    required = {
        "pysus": "0.12.0",
        "polars": "0.20.0",
        "pyarrow": "14.0.0",
        "boto3": "1.34.0",
        "dateutil": "2.8.0",
    }

    all_ok = True
    for package, min_version in required.items():
        try:
            if package == "dateutil":
                import dateutil
                pkg = dateutil
            else:
                pkg = __import__(package)

            version = getattr(pkg, "__version__", "desconhecida")
            logger.info(f"✓ {package}: {version}")
        except ImportError:
            logger.error(f"✗ {package} nao instalado (requerido: >={min_version})")
            all_ok = False

    return all_ok


def check_aws_credentials():
    """Verifica credenciais AWS."""
    try:
        from storage import validate_credentials
        if validate_credentials():
            logger.info("✓ Credenciais AWS configuradas")
            return True
        else:
            logger.error("✗ Credenciais AWS nao configuradas")
            logger.error("   Configure com: aws configure")
            logger.error("   Ou defina variaveis de ambiente:")
            logger.error("   - AWS_ACCESS_KEY_ID")
            logger.error("   - AWS_SECRET_ACCESS_KEY")
            logger.error("   - AWS_DEFAULT_REGION (opcional)")
            return False
    except Exception as e:
        logger.error(f"✗ Erro ao validar credenciais AWS: {e}")
        return False


def check_s3_bucket():
    """Verifica acesso ao bucket S3."""
    try:
        from config import S3_BUCKET
        from storage import validate_bucket

        logger.info(f"Verificando bucket: {S3_BUCKET}")
        if validate_bucket():
            logger.info(f"✓ Bucket S3 '{S3_BUCKET}' acessivel")
            return True
        else:
            logger.error(f"✗ Bucket S3 '{S3_BUCKET}' nao acessivel")
            logger.error(f"   Crie o bucket: aws s3 mb s3://{S3_BUCKET}")
            logger.error(f"   Ou configure outro bucket via variavel de ambiente:")
            logger.error(f"   export CNES_S3_BUCKET=seu-bucket")
            return False
    except Exception as e:
        logger.error(f"✗ Erro ao validar bucket S3: {e}")
        return False


def check_imports():
    """Verifica imports do projeto."""
    try:
        from config import PREFIXOS, UFS, S3_BUCKET
        from extracao import download_cnes, get_previous_month
        from transformacao import transform
        from storage import upload_parquet, file_exists

        logger.info("✓ Imports do projeto funcionando")
        logger.info(f"  - Prefixos: {', '.join(PREFIXOS)}")
        logger.info(f"  - UFs: {len(UFS)} estados")
        return True
    except Exception as e:
        logger.error(f"✗ Erro nos imports do projeto: {e}")
        return False


def main():
    """Executa todas as validacoes."""
    logger.info("=" * 60)
    logger.info("VALIDACAO DO AMBIENTE - CNES ETL")
    logger.info("=" * 60)

    checks = [
        ("Versao do Python", check_python_version),
        ("Dependencias Python", check_dependencies),
        ("Imports do Projeto", check_imports),
        ("Credenciais AWS", check_aws_credentials),
        ("Bucket S3", check_s3_bucket),
    ]

    results = {}
    for name, check_func in checks:
        logger.info(f"\n[{name}]")
        results[name] = check_func()

    # Resumo
    logger.info("\n" + "=" * 60)
    logger.info("RESUMO")
    logger.info("=" * 60)

    total = len(results)
    passed = sum(results.values())

    for name, result in results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        logger.info(f"{status} - {name}")

    logger.info("=" * 60)
    logger.info(f"Resultado: {passed}/{total} verificacoes passaram")

    if passed == total:
        logger.info("\n✓ Ambiente configurado corretamente!")
        logger.info("\nVoce pode executar o ETL com:")
        logger.info("  python3 etl.py --prefixos ST --uf SP")
        return 0
    else:
        logger.error(f"\n✗ {total - passed} problema(s) encontrado(s)")
        logger.error("Corrija os erros acima antes de executar o ETL")
        return 1


if __name__ == "__main__":
    sys.exit(main())
