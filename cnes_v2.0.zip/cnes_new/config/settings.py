"""
Configuracoes do projeto CNES.
"""
import os
from pathlib import Path

# Paths locais
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"

# S3 - Configuravel via variaveis de ambiente
S3_BUCKET = os.getenv("CNES_S3_BUCKET", "datasus-cnes-dev")
S3_PREFIX = os.getenv("CNES_S3_PREFIX", "cnes")
AWS_REGION = os.getenv("AWS_REGION", os.getenv("AWS_DEFAULT_REGION", "us-east-1"))

# Prefixos CNES
PREFIXOS = ["ST", "PF", "EQ", "SR"]

PREFIXO_DESCRICAO = {
    "ST": "Estabelecimentos",
    "PF": "Profissionais",
    "EQ": "Equipamentos",
    "SR": "Servicos Especializados",
}

# UFs do Brasil
UFS = [
    "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA",
    "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN",
    "RO", "RR", "RS", "SC", "SE", "SP", "TO"
]

# Mapeamento UF codigo -> (sigla, nome, regiao)
UF_MAP = {
    "11": ("RO", "Rondonia", "Norte"),
    "12": ("AC", "Acre", "Norte"),
    "13": ("AM", "Amazonas", "Norte"),
    "14": ("RR", "Roraima", "Norte"),
    "15": ("PA", "Para", "Norte"),
    "16": ("AP", "Amapa", "Norte"),
    "17": ("TO", "Tocantins", "Norte"),
    "21": ("MA", "Maranhao", "Nordeste"),
    "22": ("PI", "Piaui", "Nordeste"),
    "23": ("CE", "Ceara", "Nordeste"),
    "24": ("RN", "Rio Grande do Norte", "Nordeste"),
    "25": ("PB", "Paraiba", "Nordeste"),
    "26": ("PE", "Pernambuco", "Nordeste"),
    "27": ("AL", "Alagoas", "Nordeste"),
    "28": ("SE", "Sergipe", "Nordeste"),
    "29": ("BA", "Bahia", "Nordeste"),
    "31": ("MG", "Minas Gerais", "Sudeste"),
    "32": ("ES", "Espirito Santo", "Sudeste"),
    "33": ("RJ", "Rio de Janeiro", "Sudeste"),
    "35": ("SP", "Sao Paulo", "Sudeste"),
    "41": ("PR", "Parana", "Sul"),
    "42": ("SC", "Santa Catarina", "Sul"),
    "43": ("RS", "Rio Grande do Sul", "Sul"),
    "50": ("MS", "Mato Grosso do Sul", "Centro-Oeste"),
    "51": ("MT", "Mato Grosso", "Centro-Oeste"),
    "52": ("GO", "Goias", "Centro-Oeste"),
    "53": ("DF", "Distrito Federal", "Centro-Oeste"),
}
