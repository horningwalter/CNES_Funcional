from .settings import (
    BASE_DIR,
    DATA_DIR,
    S3_BUCKET,
    S3_PREFIX,
    AWS_REGION,
    PREFIXOS,
    PREFIXO_DESCRICAO,
    UFS,
    UF_MAP,
)
from .dominios import decodificar, get_tabela
