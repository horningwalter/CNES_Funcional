"""
Tabelas de domínio para decodificação de valores do CNES.
Baseado na documentação oficial do DATASUS.
"""

# =============================================================================
# ESTABELECIMENTOS (ST)
# =============================================================================

# Tipo de Pessoa (PF_PJ)
TIPO_PESSOA = {
    "1": "Pessoa Física",
    "3": "Pessoa Jurídica",
}

# Nível de Dependência (NIV_DEP)
NIVEL_DEPENDENCIA = {
    "1": "Individual",
    "3": "Mantida",
}

# Tipo de Gestão (TPGESTAO)
TIPO_GESTAO = {
    "Z": "Não informado",
    "D": "Dupla",
    "E": "Estadual",
    "M": "Municipal",
    "S": "Sem gestão",
}

# Esfera Administrativa (ESFERA_A)
ESFERA_ADMINISTRATIVA = {
    "01": "Federal",
    "02": "Estadual",
    "03": "Municipal",
    "04": "Privada",
    "99": "Não informada",
}

# Natureza da Organização (NATUREZA)
NATUREZA_ORGANIZACAO = {
    "01": "Administração Direta da Saúde (MS, SES, SMS)",
    "02": "Administração Direta outros órgãos (MEx, Marinha...)",
    "03": "Administração Indireta - Autarquias",
    "04": "Administração Indireta - Fundação Pública",
    "05": "Administração Indireta - Empresa Pública",
    "06": "Administração Indireta - Organização Social Pública",
    "07": "Empresa Privada",
    "08": "Fundação Privada",
    "09": "Cooperativa",
    "10": "Serviço Social Autônomo",
    "11": "Entidade Beneficente sem fins lucrativos",
    "12": "Economia Mista",
    "13": "Sindicato",
    "00": "Natureza inexistente",
    "99": "Natureza não informada",
}

# Fluxo de Clientela (CLIENTEL)
FLUXO_CLIENTELA = {
    "01": "Atendimento de demanda espontânea",
    "02": "Atendimento de demanda referenciada",
    "03": "Atendimento de demanda espontânea e referenciada",
    "00": "Fluxo de clientela não exigido",
    "99": "Fluxo de clientela não informado",
}

# Tipo de Unidade (TP_UNID)
TIPO_UNIDADE = {
    "01": "Posto de Saúde",
    "02": "Centro de Saúde/Unidade Básica",
    "04": "Policlínica",
    "05": "Hospital Geral",
    "07": "Hospital Especializado",
    "15": "Unidade Mista",
    "20": "Pronto Socorro Geral",
    "21": "Pronto Socorro Especializado",
    "22": "Consultório Isolado",
    "32": "Unidade Móvel Fluvial",
    "36": "Clínica/Centro de Especialidade",
    "39": "Unidade de Apoio Diagnose e Terapia",
    "40": "Unidade Móvel Terrestre",
    "42": "Unidade Móvel Pré-Hospitalar Urgência",
    "43": "Farmácia",
    "50": "Unidade de Vigilância em Saúde",
    "60": "Cooperativa/Empresa Cessão de Trabalhadores",
    "61": "Centro de Parto Normal",
    "62": "Hospital/Dia - Isolado",
    "64": "Central de Regulação de Serviços de Saúde",
    "67": "Laboratório Central de Saúde Pública - LACEN",
    "68": "Central de Regulação das Urgências",
    "69": "Centro de Atenção Hemoterapia/Hematológica",
    "70": "Centro de Atenção Psicossocial",
    "71": "Centro de Apoio à Saúde da Família",
    "72": "Unidade de Atenção à Saúde Indígena",
    "73": "Pronto Atendimento",
    "74": "Polo Academia da Saúde",
    "75": "Telessaúde",
    "76": "Central de Regulação Médica das Urgências",
    "77": "Serviço de Atenção Domiciliar Isolado (Home Care)",
    "78": "Unidade de Atenção em Regime Residencial",
    "79": "Oficina Ortopédica",
    "80": "Laboratório de Saúde Pública",
    "81": "Central de Regulação do Acesso",
    "82": "Central de Notificação/Captação/Distrib Órgãos",
    "83": "Polo de Prevenção de Doenças e Agravos",
    "84": "Central de Abastecimento",
    "85": "Centro de Imunização",
    "86": "Central de Gestão em Saúde",
}

# Turno de Atendimento (TURNO_AT)
TURNO_ATENDIMENTO = {
    "01": "Turnos intermitentes",
    "02": "Contínuo 24h (Pl/Sab/Dom/Fer)",
    "03": "Manhã/Tarde/Noite",
    "04": "Somente manhã",
    "05": "Somente tarde",
    "06": "Manhã/Tarde",
    "07": "Somente noite",
    "99": "Não informado",
}

# Nível de Hierarquia (NIV_HIER)
NIVEL_HIERARQUIA = {
    "01": "PAB - Atenção Básica",
    "02": "Média M1",
    "03": "Média M2 e M3",
    "04": "Alta Complexidade Ambulatorial",
    "05": "Baixa M1 e M2",
    "06": "Média M2 e M3",
    "07": "Média M3",
    "08": "Alta Complexidade Hospitalar/Ambulatorial",
    "00": "Não informado",
    "99": "Não informado",
}

# Tipo de Prestador (TP_PREST)
TIPO_PRESTADOR = {
    "20": "Privado com fins lucrativos",
    "22": "Privado optante pelo Simples",
    "30": "Público Federal",
    "40": "Público Estadual",
    "50": "Público Municipal",
    "60": "Privado sem fins lucrativos",
    "61": "Filantrópico com CNAS válido",
    "80": "Sindicato",
    "99": "Não informado",
}

# Atividade de Ensino (ATIVIDAD)
ATIVIDADE_ENSINO = {
    "01": "Unidade Universitária",
    "02": "Unidade Escola Superior Isolada",
    "03": "Unidade Auxiliar de Ensino",
    "04": "Unidade sem atividade de Ensino",
    "05": "Hospital de Ensino",
    "99": "Não informada",
}

# Retenção de Tributos (RETENCAO / COD_IR)
RETENCAO_TRIBUTOS = {
    "00": "Não informada",
    "10": "Estabelecimento Público",
    "11": "Estabelecimento Filantrópico",
    "12": "Estabelecimento Sem Fins Lucrativos",
    "13": "Privado Lucrativo Simples",
    "14": "Privado Lucrativo",
    "15": "Estabelecimento Sindical",
    "16": "Estabelecimento Pessoa Física",
    "19": "Ret. Mantenedora código 19",
    "99": "Não informada",
}

# =============================================================================
# PROFISSIONAIS (PF)
# =============================================================================

# Tipo de Vínculo (VINCULAC)
TIPO_VINCULO = {
    "01": "Vínculo empregatício",
    "02": "Autônomo",
    "03": "Estágio",
    "04": "Residência",
    "05": "Bolsa",
    "06": "Proprietário/Sócio",
    "07": "Cooperado",
    "08": "Contrato por prazo determinado",
    "09": "Contrato Verbal/Informal",
    "10": "Contrato - CLT",
    "99": "Outro",
}

# Vínculo SUS (VINCULUS)
VINCULO_SUS = {
    "0": "Não",
    "1": "Sim",
}

# CBO - Classificação Brasileira de Ocupações (principais da saúde)
CBO = {
    # Médicos
    "225103": "Médico Anestesiologista",
    "225105": "Médico Cirurgião Cardiovascular",
    "225106": "Médico Cirurgião Cabeça e Pescoço",
    "225109": "Médico Cirurgião Digestivo",
    "225110": "Médico Cirurgião Geral",
    "225112": "Médico Cirurgião Pediátrico",
    "225113": "Médico Cirurgião Plástico",
    "225114": "Médico Cirurgião Torácico",
    "225115": "Médico Clínico",
    "225116": "Médico Cardiologista",
    "225118": "Médico Oncologista",
    "225119": "Médico Dermatologista",
    "225120": "Médico do Trabalho",
    "225121": "Médico Endocrinologista",
    "225122": "Médico Gastroenterologista",
    "225123": "Médico Generalista",
    "225124": "Médico Geneticista",
    "225125": "Médico Geriatra",
    "225126": "Médico Ginecologista e Obstetra",
    "225127": "Médico Hematologista",
    "225128": "Médico Homeopata",
    "225129": "Médico Infectologista",
    "225130": "Médico Legista",
    "225131": "Médico Nefrologista",
    "225132": "Médico Neurologista",
    "225133": "Médico Neurocirurgião",
    "225134": "Médico Oftalmologista",
    "225135": "Médico Ortopedista e Traumatologista",
    "225136": "Médico Otorrinolaringologista",
    "225137": "Médico Pediatra",
    "225138": "Médico Pneumologista",
    "225139": "Médico Proctologista",
    "225140": "Médico Psiquiatra",
    "225141": "Médico Radiologista",
    "225142": "Médico Reumatologista",
    "225143": "Médico Urologista",
    "225145": "Médico Patologista",
    "225146": "Médico Mastologista",
    "225148": "Médico Cancerologista Pediátrico",
    "225149": "Médico Fisiatra",
    "225150": "Médico Neonatologista",
    "225151": "Médico Angiologista",
    "225152": "Médico Nutrologista",
    "225153": "Médico Intensivista",
    "225154": "Médico de Família e Comunidade",
    "225155": "Médico Sanitarista",
    "225170": "Médico Residente",
    "225180": "Médico de Saúde Pública",
    "225195": "Médico em Medicina de Tráfego",
    # Enfermagem
    "223505": "Enfermeiro",
    "223510": "Enfermeiro Auditor",
    "223515": "Enfermeiro de Bordo",
    "223520": "Enfermeiro de Centro Cirúrgico",
    "223525": "Enfermeiro de Terapia Intensiva",
    "223530": "Enfermeiro do Trabalho",
    "223535": "Enfermeiro Nefrologista",
    "223540": "Enfermeiro Neonatologista",
    "223545": "Enfermeiro Obstétrico",
    "223550": "Enfermeiro Psiquiátrico",
    "223555": "Enfermeiro Puericultor e Pediátrico",
    "223560": "Enfermeiro Sanitarista",
    "223565": "Enfermeiro da Estratégia de Saúde da Família",
    "322205": "Técnico de Enfermagem",
    "322210": "Técnico de Enfermagem de Terapia Intensiva",
    "322215": "Técnico de Enfermagem do Trabalho",
    "322220": "Técnico de Enfermagem Psiquiátrica",
    "322230": "Auxiliar de Enfermagem",
    "322235": "Auxiliar de Enfermagem do Trabalho",
    "322245": "Instrumentador Cirúrgico",
    # Odontologia
    "223208": "Cirurgião Dentista",
    "223212": "Cirurgião Dentista Auditor",
    "223216": "Cirurgião Dentista Bucomaxilofacial",
    "223220": "Cirurgião Dentista Endodontista",
    "223224": "Cirurgião Dentista Epidemiologista",
    "223228": "Cirurgião Dentista Estomatologista",
    "223232": "Cirurgião Dentista Implantodontista",
    "223236": "Cirurgião Dentista Odontogeriatra",
    "223240": "Cirurgião Dentista Odontologista Legal",
    "223244": "Cirurgião Dentista Odontopediatra",
    "223248": "Cirurgião Dentista Ortodontista",
    "223252": "Cirurgião Dentista Ortopedista",
    "223256": "Cirurgião Dentista Patologista Bucal",
    "223260": "Cirurgião Dentista Periodontista",
    "223264": "Cirurgião Dentista Protesiólogo Bucomaxilofacial",
    "223268": "Cirurgião Dentista Protesista",
    "223272": "Cirurgião Dentista Radiologista",
    "223276": "Cirurgião Dentista Reabilitador Oral",
    "223280": "Cirurgião Dentista Traumatologista",
    "223284": "Cirurgião Dentista de Saúde Coletiva",
    "223288": "Cirurgião Dentista de Dor Orofacial",
    "223293": "Cirurgião Dentista da ESF",
    "322405": "Técnico em Higiene Dental",
    "322410": "Técnico em Prótese Dentária",
    "322415": "Auxiliar de Saúde Bucal",
    "322420": "Auxiliar em Prótese Dentária",
    "322425": "Técnico em Saúde Bucal",
    # Outros profissionais de saúde
    "223405": "Fisioterapeuta",
    "223605": "Fonoaudiólogo",
    "223705": "Nutricionista",
    "223810": "Terapeuta Ocupacional",
    "223905": "Psicólogo Clínico",
    "226305": "Farmacêutico",
    "221105": "Biólogo",
    "221205": "Biomédico",
    "226105": "Assistente Social",
    "515105": "Agente Comunitário de Saúde",
    "515140": "Agente de Combate às Endemias",
    "322110": "Técnico em Laboratório de Análises Clínicas",
    "324115": "Técnico em Radiologia",
    "322505": "Técnico em Farmácia",
}

# =============================================================================
# EQUIPAMENTOS (EQ)
# =============================================================================

# Tipo de Equipamento (TIPEQUIP)
TIPO_EQUIPAMENTO = {
    "01": "Diagnóstico por Imagem",
    "02": "Infraestrutura",
    "03": "Métodos Ópticos",
    "04": "Métodos Gráficos",
    "05": "Manutenção da Vida",
    "06": "Odontologia",
    "07": "Outros Equipamentos",
}

# Códigos de Equipamento (CODEQUIP) - principais
CODIGO_EQUIPAMENTO = {
    # Diagnóstico por Imagem
    "01001": "Raio-X até 100mA",
    "01002": "Raio-X de 100 a 500mA",
    "01003": "Raio-X mais de 500mA",
    "01004": "Raio-X Odontológico",
    "01005": "Raio-X com Fluoroscopia",
    "01006": "Tomógrafo Computadorizado",
    "01007": "Ressonância Magnética",
    "01008": "Ultrassom Doppler Colorido",
    "01009": "Mamógrafo",
    "01010": "Mamógrafo com Comando Simples",
    "01011": "Mamógrafo com Estereotaxia",
    "01012": "Densitômetro Ósseo",
    "01013": "Angiógrafo",
    "01014": "Gama Câmara",
    "01015": "PET-CT",
    "01016": "Raio-X com Telecomando",
    "01017": "Raio-X Dental Panorâmico",
    "01018": "Tomógrafo Computadorizado Multislice",
    "01019": "Ultrassom Ecógrafo",
    # Infraestrutura
    "02001": "Berço Aquecido",
    "02002": "Bilirrubinômetro",
    "02003": "Incubadora",
    "02004": "Reanimador Infantil",
    "02005": "Fototerapia",
    "02006": "Monitor de ECG",
    "02007": "Oxímetro",
    "02008": "Bomba de Infusão",
    "02009": "Desfibrilador/Cardioversor",
    "02010": "Monitor Multiparâmetro",
    "02011": "Eletrocardiógrafo",
    "02012": "Ventilador Pulmonar/Respirador",
    "02013": "Ventilador Pulmonar Neonatal",
    "02014": "Capnógrafo",
    "02015": "Monitor de Pressão Invasiva",
    # Métodos Ópticos
    "03001": "Colposcópio",
    "03002": "Endoscópio Digestivo",
    "03003": "Broncoscópio",
    "03004": "Laparoscópio/Vídeolaparoscópio",
    "03005": "Retinógrafo",
    "03006": "Microscópio Cirúrgico",
    "03007": "Lâmpada de Fenda",
    # Métodos Gráficos
    "04001": "Eletroencefalógrafo",
    "04002": "Eletromiógrafo",
    "04003": "Polígrafo",
    "04004": "Holter",
    "04005": "Teste Ergométrico",
    "04006": "Ecocardiograma",
    "04007": "Urodinâmico",
    # Manutenção da Vida
    "05001": "Equipamento de Hemodiálise",
    "05002": "Equipamento de Diálise Peritoneal",
    "05003": "Circulação Extracorpórea",
    "05004": "CPAP/BIPAP",
    # Odontologia
    "06001": "Equipo Odontológico",
    "06002": "Compressor Odontológico",
    "06003": "Fotopolimerizador",
    "06004": "Amalgamador",
    "06005": "Caneta de Alta Rotação",
    # Outros
    "07001": "Autoclave",
    "07002": "Estufa de Esterilização",
    "07003": "Cabine de Segurança Biológica",
    "07004": "Forno de Bier",
    "07005": "Acelerador Linear",
    "07006": "Bomba de Cobalto",
    "07007": "Braquiterapia",
    "07008": "Litotripsor",
    "07009": "Processadora de Filme",
}

# Disponibilidade SUS (IND_SUS)
DISPONIBILIDADE_SUS = {
    "0": "Não disponível SUS",
    "1": "Disponível SUS",
}

# =============================================================================
# SERVIÇOS ESPECIALIZADOS (SR)
# =============================================================================

# Serviço Especializado (SERV_ESP)
SERVICO_ESPECIALIZADO = {
    "100": "Serviço de Atenção à Saúde Reprodutiva",
    "101": "Serviço de Atenção ao Pré-natal, Parto e Nascimento",
    "102": "Serviço de Atenção ao Paciente com Tuberculose",
    "103": "Serviço de Atenção em Hanseníase",
    "104": "Serviço de Controle de Tabagismo",
    "105": "Serviço de Diagnóstico por Imagem",
    "106": "Serviço de Diagnóstico por Laboratório Clínico",
    "107": "Serviço de Endoscopia",
    "108": "Serviço de Farmácia",
    "109": "Serviço de Fisioterapia",
    "110": "Serviço de Hemoterapia",
    "111": "Serviço de Nefrologia",
    "112": "Serviço de Oncologia",
    "113": "Serviço de Pneumologia",
    "114": "Serviço de Práticas Integrativas",
    "115": "Serviço de Reabilitação",
    "116": "Serviço de Saúde Auditiva",
    "117": "Serviço de Saúde Bucal",
    "118": "Serviço de Saúde do Trabalhador",
    "119": "Serviço de Saúde Mental",
    "120": "Serviço de Terapia Nutricional",
    "121": "Serviço de Transplante",
    "122": "Serviço de Urgência e Emergência",
    "123": "Serviço de Vigilância em Saúde",
    "124": "Serviço de Atenção à DST/HIV/AIDS",
    "125": "Serviço de Atenção à Saúde do Idoso",
    "126": "Serviço de Atenção Cardiovascular/Cardiologia",
    "127": "Serviço de Atenção Domiciliar",
    "128": "Serviço de Cirurgia Cardiovascular",
    "129": "Serviço de Cirurgia Plástica/Reparadora",
    "130": "Serviço de Atendimento Pré-Hospitalar",
    "131": "Serviço de Atenção às Doenças Raras",
    "132": "Serviço de Traumato-Ortopedia",
    "133": "Serviço de Oftalmologia",
    "134": "Serviço de Medicina Nuclear",
    "135": "Serviço de Radioterapia",
    "136": "Serviço de Quimioterapia",
    "137": "Serviço de UTI",
    "138": "Serviço de Assistência de Alta Complexidade em Neurocirurgia",
    "139": "Serviço de Hemodinâmica",
    "140": "Serviço de Internação Domiciliar",
    "141": "Serviço de Laboratório de Histocompatibilidade",
    "142": "Serviço de Atenção Psicossocial",
    "143": "Serviço de Hospital Dia",
    "144": "Serviço de Atenção ao Paciente com Obesidade",
    "145": "Serviço de Genética Clínica",
    "146": "Serviço de Triagem Neonatal",
    "147": "Serviço de Videolaparoscopia",
    "148": "Serviço de Neurofisiologia Clínica",
    "149": "Serviço de Lactário",
    "150": "Serviço de Banco de Leite Humano",
    "151": "Serviço de Processamento de Roupa",
    "152": "Serviço de Manutenção de Equipamentos",
    "153": "Serviço de Nutrição e Dietética",
    "154": "Serviço de Esterilização de Materiais",
    "155": "Serviço de Imunização",
    "156": "Serviço de Coleta de Materiais Biológicos",
    "157": "Serviço de Diálise",
    "158": "Serviço de Terapia Intensiva",
    "159": "Serviço de Anatomia Patológica e/ou Citopatologia",
}

# Classificação do Serviço (CLASS_SR) - alguns exemplos por serviço
CLASSIFICACAO_SERVICO = {
    # Diagnóstico por Imagem (105)
    "001": "Radiologia",
    "002": "Tomografia Computadorizada",
    "003": "Ressonância Magnética",
    "004": "Ultrassonografia",
    "005": "Mamografia",
    "006": "Densitometria Óssea",
    "007": "Medicina Nuclear",
    # Hemoterapia (110)
    "001": "Hemocentro",
    "002": "Núcleo de Hemoterapia",
    "003": "Unidade de Coleta e Transfusão",
    "004": "Agência Transfusional",
    # Oncologia (112)
    "001": "Oncologia Clínica",
    "002": "Oncologia Cirúrgica",
    "003": "Oncologia Pediátrica",
    "004": "Hematologia",
    # Reabilitação (115)
    "001": "Reabilitação Física",
    "002": "Reabilitação Intelectual",
    "003": "Reabilitação Auditiva",
    "004": "Reabilitação Visual",
    "005": "Reabilitação em Múltiplas Deficiências",
    "006": "Reabilitação Autismo",
    # UTI (137)
    "001": "UTI Adulto Tipo I",
    "002": "UTI Adulto Tipo II",
    "003": "UTI Adulto Tipo III",
    "004": "UTI Pediátrica Tipo I",
    "005": "UTI Pediátrica Tipo II",
    "006": "UTI Pediátrica Tipo III",
    "007": "UTI Neonatal Tipo I",
    "008": "UTI Neonatal Tipo II",
    "009": "UTI Neonatal Tipo III",
    "010": "UTI Coronariana",
    "011": "UTI Queimados",
    # Diálise (157)
    "001": "Hemodiálise",
    "002": "Diálise Peritoneal Ambulatorial",
    "003": "Diálise Peritoneal Automática",
}

# Característica do Serviço (CATEFLE)
CARACTERISTICA_SERVICO = {
    "001": "Ambulatorial",
    "002": "Hospitalar",
    "003": "Ambulatorial e Hospitalar",
}


# =============================================================================
# FUNÇÕES AUXILIARES
# =============================================================================

def decodificar(valor, tabela: dict, default: str = None) -> str:
    """Decodifica um valor usando a tabela de domínio."""
    if valor is None:
        return default
    chave = str(valor).strip().zfill(2) if len(str(valor).strip()) == 1 else str(valor).strip()
    return tabela.get(chave, tabela.get(str(valor).strip(), default or f"Cód: {valor}"))


def get_tabela(nome: str) -> dict:
    """Retorna uma tabela de domínio pelo nome."""
    tabelas = {
        # ST
        "tipo_pessoa": TIPO_PESSOA,
        "nivel_dependencia": NIVEL_DEPENDENCIA,
        "tipo_gestao": TIPO_GESTAO,
        "esfera_administrativa": ESFERA_ADMINISTRATIVA,
        "natureza_organizacao": NATUREZA_ORGANIZACAO,
        "fluxo_clientela": FLUXO_CLIENTELA,
        "tipo_unidade": TIPO_UNIDADE,
        "turno_atendimento": TURNO_ATENDIMENTO,
        "nivel_hierarquia": NIVEL_HIERARQUIA,
        "tipo_prestador": TIPO_PRESTADOR,
        "atividade_ensino": ATIVIDADE_ENSINO,
        "retencao_tributos": RETENCAO_TRIBUTOS,
        # PF
        "tipo_vinculo": TIPO_VINCULO,
        "vinculo_sus": VINCULO_SUS,
        "cbo": CBO,
        # EQ
        "tipo_equipamento": TIPO_EQUIPAMENTO,
        "codigo_equipamento": CODIGO_EQUIPAMENTO,
        "disponibilidade_sus": DISPONIBILIDADE_SUS,
        # SR
        "servico_especializado": SERVICO_ESPECIALIZADO,
        "classificacao_servico": CLASSIFICACAO_SERVICO,
        "caracteristica_servico": CARACTERISTICA_SERVICO,
    }
    return tabelas.get(nome, {})
