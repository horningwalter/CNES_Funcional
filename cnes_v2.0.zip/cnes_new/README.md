# CNES ETL - Pipeline de Dados DATASUS
## Desenvolvido por triggo.ai

Pipeline ETL para extração, transformação e carga de dados do CNES (Cadastro Nacional de Estabelecimentos de Saúde) do DATASUS para AWS S3.

## Características

- **Extração automatizada** via PySUS com retry (3 tentativas)
- **Processamento eficiente** usando Polars (até 10x mais rápido que Pandas)
- **Armazenamento otimizado** em S3 (formato Parquet particionado)
- **Validação completa** de ambiente e credenciais
- **Campos expandidos** baseados no layout oficial IT_CNES_1706

## Requisitos

- Python 3.10+
- Credenciais AWS configuradas
- Bucket S3 criado (padrão: `datasus-cnes-dev`)

## Instalação

### 1. Instalar dependências

```bash
pip install -r requirements.txt
```

### 2. Configurar AWS

**Opção A - AWS CLI (Recomendado):**
```bash
aws configure
```

**Opção B - Variáveis de ambiente:**
```bash
cp .env.example .env
# Edite .env com suas credenciais
export AWS_ACCESS_KEY_ID=sua_key
export AWS_SECRET_ACCESS_KEY=sua_secret
export AWS_DEFAULT_REGION=us-east-1
```

**Opção C - Configurar bucket customizado:**
```bash
export CNES_S3_BUCKET=seu-bucket
export CNES_S3_PREFIX=seu-prefixo
```

### 3. Validar ambiente

```bash
python3 setup_check.py
```

Este script verifica:
- ✓ Versão do Python (3.10+)
- ✓ Dependências instaladas
- ✓ Credenciais AWS válidas
- ✓ Acesso ao bucket S3
- ✓ Imports do projeto

## Uso

### Comandos Básicos

**Processar tudo do mês anterior:**
```bash
python3 etl.py
```

**Processar estabelecimentos de SP:**
```bash
python3 etl.py --prefixos ST --uf SP
```

**Processar múltiplos estados:**
```bash
python3 etl.py --prefixos ST --uf SP RJ MG
```

**Processar múltiplos prefixos:**
```bash
python3 etl.py --prefixos ST PF EQ SR
```

**Mês e ano específicos:**
```bash
python3 etl.py --ano 25 --mes 12
```

**Reprocessar dados existentes:**
```bash
python3 etl.py --force
```

### Prefixos Disponíveis

| Prefixo | Descrição | Campos Processados |
|---------|-----------|-------------------|
| **ST** | Estabelecimentos de Saúde | 32 campos |
| **PF** | Profissionais de Saúde | 22 campos |
| **EQ** | Equipamentos | 14 campos |
| **SR** | Serviços Especializados | 14 campos |

### Campos Processados

#### Campos Comuns (todos os prefixos)
- **Identificação**: cnes, codufmun, cod_uf
- **Geográficos**: regsaude, micr_reg, distrsan, distradm
- **Administrativos**: nat_jur, competen
- **Metadados**: ano_cmp, mes_cmp, data_carga

#### ST - Estabelecimentos
- Identificação: cpf_cnpj, cnpj_man, cod_cep
- Classificação: pf_pj, niv_dep, tp_unid, tpgestao, esfera_a
- Gestão: natureza, niv_hier, turno_at, clientel, tp_prest
- Atividades: atividad, retencao, cod_ir, vinc_sus
- Atendimento: leithosp, urgemerg, atendamb, centobs, apoiodia, serv_hos, outrasat

#### PF - Profissionais
- Identificação: cpf_prof, cns_prof, nomeprof, registro, conselho
- Função: cbo, prof_sus
- Vínculo: vinculac, vinculus, vincul_c, vincul_a
- Carga horária: horaoutr, horahosp, hora_amb

#### EQ - Equipamentos
- Identificação: codequip, tipequip
- SUS: ind_sus, ind_nsus
- Quantidades: qt_exist, qt_uso

#### SR - Serviços Especializados
- Identificação: serv_esp, class_sr
- Classificação: caracter, amb_hosp, srvunico
- Referência: cnesterc

## Estrutura de Saída S3

Os arquivos são salvos no formato:
```
s3://{bucket}/cnes/raw/{prefixo}/ano={ano}/mes={mes}/{prefixo}_{ano}{mes}.parquet
```

**Exemplo:**
```
s3://datasus-cnes-dev/cnes/raw/st/ano=25/mes=12/st_2512.parquet
```

Este formato particionado permite queries eficientes usando ferramentas como Athena, Presto ou DuckDB.

## Estrutura do Projeto

```
cnes_new/
├── config/
│   ├── __init__.py
│   ├── settings.py         # Configurações (S3, AWS)
│   └── dominios.py         # Tabelas de domínio
├── extracao/
│   ├── __init__.py
│   └── download.py         # Download via PySUS
├── transformacao/
│   ├── __init__.py
│   ├── transform.py        # Transformações Polars
│   └── views.py            # Views semânticas dimensionais
├── storage/
│   ├── __init__.py
│   └── s3.py               # Operações S3
├── utils/
│   ├── __init__.py
│   └── logging_config.py   # Configuração de logs
├── logs/                   # Logs de execução (gerado)
├── etl.py                  # Pipeline principal
├── setup_check.py          # Validação de ambiente
├── requirements.txt        # Dependências
├── .env.example            # Template de configuração
├── .gitignore
└── README.md
```

## Configurações Avançadas

### Variáveis de Ambiente

```bash
# AWS
AWS_ACCESS_KEY_ID=sua_key
AWS_SECRET_ACCESS_KEY=sua_secret
AWS_DEFAULT_REGION=us-east-1

# S3
CNES_S3_BUCKET=datasus-cnes-dev  # default
CNES_S3_PREFIX=cnes              # default
```

### Retry e Timeout

O sistema está configurado para:
- **3 tentativas** automáticas em caso de falha no download
- **5 segundos** de delay entre tentativas
- Validação robusta de retorno do PySUS

Configurações em `extracao/download.py`:
```python
MAX_RETRIES = 3
RETRY_DELAY = 5  # segundos
```

## Troubleshooting

### Erro: "Credenciais AWS não encontradas"

```bash
# Solução 1: AWS CLI
aws configure

# Solução 2: Variáveis de ambiente
export AWS_ACCESS_KEY_ID=sua_key
export AWS_SECRET_ACCESS_KEY=sua_secret
```

### Erro: "Bucket não existe"

```bash
# Criar bucket
aws s3 mb s3://datasus-cnes-dev

# Ou usar bucket existente
export CNES_S3_BUCKET=outro-bucket
```

### Erro: "Timeout no download"

- O servidor DATASUS pode estar lento ou indisponível
- O sistema tentará automaticamente 3 vezes
- Aguarde alguns minutos e tente novamente

### DataFrame vazio após transformação

- Verifique se os campos mapeados existem nos dados do DATASUS
- O sistema processa apenas campos existentes (não gera erro)
- Consulte logs para detalhes

## Logs e Monitoramento

### Arquivos de Log

O sistema salva logs automaticamente em **3 locais**:

1. **Console** (stdout) - saída em tempo real
2. **Arquivo local** - `logs/etl_AAAAMM_HHMMSS.log`
3. **S3** - `s3://{bucket}/cnes/logs/{ano}/{mes}/etl_HHMMSS.log`

### Resumo de Execução

Após cada execução, é gerado um arquivo JSON com estatísticas:

**Local:** `logs/resumo_AAAAMM_HHMMSS.json`
**S3:** `s3://{bucket}/cnes/logs/{ano}/{mes}/resumo_HHMMSS.json`

**Estrutura do resumo:**
```json
{
  "metadata": {
    "data_execucao": "2026-01-20T10:30:45",
    "ano_referencia": 25,
    "mes_referencia": 12,
    "tempo_execucao_segundos": 245.67
  },
  "parametros": {
    "prefixos": ["ST", "PF"],
    "ufs": "Todas"
  },
  "resultados": {
    "ST": {"registros": 50000, "status": "OK"},
    "PF": {"registros": 120000, "status": "OK"}
  },
  "estatisticas": {
    "total_registros": 170000,
    "total_prefixos": 2,
    "sucesso": 2,
    "skip": 0,
    "vazio": 0,
    "erro": 0
  },
  "arquivos": {
    "log": "logs/etl_2512_103045.log",
    "resumo": "logs/resumo_2512_103045.json",
    "log_s3": "s3://datasus-cnes-dev/cnes/logs/25/12/etl_103045.log",
    "resumo_s3": "s3://datasus-cnes-dev/cnes/logs/25/12/resumo_103045.json"
  }
}
```

### Status Possíveis

- **OK**: Processado com sucesso
- **SKIP**: Já existe no S3, pulado (use `--force` para reprocessar)
- **VAZIO**: DataFrame vazio após transformação
- **ERRO**: Falha durante processamento

### Desabilitar Upload de Logs para S3

Por padrão, logs são enviados para S3. Para salvar apenas localmente:

```bash
python3 etl.py --no-s3-logs
```

### Exemplo de Saída no Console

```
2026-01-20 10:00:00 - INFO - Logs salvos em: logs/etl_2512_100000.log
2026-01-20 10:00:00 - INFO - Resumo sera salvo em: logs/resumo_2512_100000.json
2026-01-20 10:00:00 - INFO - Iniciando ETL para 12/25
2026-01-20 10:00:01 - INFO - Prefixos: ['ST', 'PF']
2026-01-20 10:00:05 - INFO - ST: 50000 registros salvos na camada raw
2026-01-20 10:00:06 - INFO - ST: 50000 registros salvos na camada semantic
2026-01-20 10:05:10 - INFO - PF: 120000 registros salvos na camada raw
2026-01-20 10:05:12 - INFO - PF: 120000 registros salvos na camada semantic
==================================================
RESUMO:
  ST: 50000 registros (OK)
  PF: 120000 registros (OK)
Tempo total: 245.67 segundos
2026-01-20 10:05:15 - INFO - Resumo salvo em: logs/resumo_2512_100000.json
2026-01-20 10:05:16 - INFO - Log enviado para: s3://datasus-cnes-dev/cnes/logs/25/12/etl_100000.log
2026-01-20 10:05:17 - INFO - Resumo enviado para: s3://datasus-cnes-dev/cnes/logs/25/12/resumo_100000.json
```

## Dependências

```
pysus>=0.12.0      # Download de dados DATASUS
polars>=0.20.0     # Processamento de dados
pyarrow>=14.0.0    # Suporte Parquet
boto3>=1.34.0      # Cliente AWS S3
python-dateutil>=2.8.0  # Manipulação de datas
```

## Segurança

- Credenciais AWS nunca são commitadas no código
- Arquivo `.env` está no `.gitignore`
- Use `.env.example` como template
- Recomenda-se usar IAM roles em produção

## Performance

- **Polars** é até 10x mais rápido que Pandas
- **Parquet** reduz tamanho dos arquivos em ~70%
- **Particionamento** S3 permite queries eficientes
- **Compressão Snappy** balanceia tamanho e velocidade

## Integração com Outras Ferramentas

### AWS Athena
```sql
CREATE EXTERNAL TABLE cnes_st (
  cnes STRING,
  codufmun STRING,
  ...
)
PARTITIONED BY (ano INT, mes INT)
STORED AS PARQUET
LOCATION 's3://datasus-cnes-dev/cnes/raw/st/';

-- Adicionar partições
MSCK REPAIR TABLE cnes_st;
```

### DuckDB
```python
import duckdb

conn = duckdb.connect()
conn.execute("""
    SELECT COUNT(*)
    FROM 's3://datasus-cnes-dev/cnes/raw/st/**/*.parquet'
    WHERE ano = 25 AND mes = 12
""")
```

### Polars
```python
import polars as pl

df = pl.read_parquet('s3://datasus-cnes-dev/cnes/raw/st/ano=25/mes=12/*.parquet')
print(df.head())
```

## Licença

Este projeto processa dados públicos do DATASUS/Ministério da Saúde.

