"""
Configuracao de logging para ETL CNES.
Salva logs localmente e opcionalmente no S3.
"""
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Any

from config import S3_BUCKET, S3_PREFIX


def setup_logging(ano: int, mes: int, upload_to_s3: bool = True) -> tuple[Path, Path]:
    """
    Configura logging para salvar em arquivo local e console.

    Retorna tupla (log_file_path, summary_file_path).
    """
    logs_dir = Path("logs")
    logs_dir.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = logs_dir / f"etl_{ano}{mes:02d}_{timestamp}.log"
    summary_file = logs_dir / f"resumo_{ano}{mes:02d}_{timestamp}.json"

    # Remove handlers existentes
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Formato de log
    formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # Handler para arquivo
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)

    # Handler para console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    # Configurar root logger
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    logging.info(f"Logs salvos em: {log_file}")
    logging.info(f"Resumo sera salvo em: {summary_file}")

    return log_file, summary_file


def save_execution_summary(
    summary_file: Path,
    log_file: Path,
    ano: int,
    mes: int,
    resultado: dict[str, int],
    prefixos: list[str],
    ufs: list[str] | None,
    tempo_execucao: float,
    upload_to_s3: bool = True,
) -> None:
    """
    Salva resumo da execucao em JSON localmente e opcionalmente no S3.
    """
    # Calcular estatisticas
    total_registros = sum(qtd for qtd in resultado.values() if qtd > 0)
    total_sucesso = sum(1 for qtd in resultado.values() if qtd > 0)
    total_skip = sum(1 for qtd in resultado.values() if qtd == -1)
    total_vazio = sum(1 for qtd in resultado.values() if qtd == 0)
    total_erro = len([qtd for qtd in resultado.values() if qtd < -1])

    # Construir resumo
    resumo = {
        "metadata": {
            "data_execucao": datetime.now().isoformat(),
            "ano_referencia": ano,
            "mes_referencia": mes,
            "tempo_execucao_segundos": round(tempo_execucao, 2),
        },
        "parametros": {
            "prefixos": prefixos,
            "ufs": ufs or "Todas",
        },
        "resultados": {
            prefixo: {
                "registros": qtd,
                "status": "OK" if qtd > 0 else ("SKIP" if qtd == -1 else "VAZIO" if qtd == 0 else "ERRO")
            }
            for prefixo, qtd in resultado.items()
        },
        "estatisticas": {
            "total_registros": total_registros,
            "total_prefixos": len(resultado),
            "sucesso": total_sucesso,
            "skip": total_skip,
            "vazio": total_vazio,
            "erro": total_erro,
        },
        "arquivos": {
            "log": str(log_file),
            "resumo": str(summary_file),
        }
    }

    # Salvar JSON localmente
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(resumo, f, indent=2, ensure_ascii=False)

    logging.info(f"Resumo salvo em: {summary_file}")

    # Upload para S3 se habilitado
    if upload_to_s3:
        try:
            from storage import get_client

            client = get_client()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

            # Upload log file
            log_key = f"{S3_PREFIX}/logs/{ano}/{mes:02d}/etl_{timestamp}.log"
            with open(log_file, "rb") as f:
                client.put_object(
                    Bucket=S3_BUCKET,
                    Key=log_key,
                    Body=f.read(),
                    ContentType="text/plain",
                )
            logging.info(f"Log enviado para: s3://{S3_BUCKET}/{log_key}")

            # Upload summary JSON
            summary_key = f"{S3_PREFIX}/logs/{ano}/{mes:02d}/resumo_{timestamp}.json"
            with open(summary_file, "rb") as f:
                client.put_object(
                    Bucket=S3_BUCKET,
                    Key=summary_key,
                    Body=f.read(),
                    ContentType="application/json",
                )
            logging.info(f"Resumo enviado para: s3://{S3_BUCKET}/{summary_key}")

            # Adicionar URLs S3 ao resumo
            resumo["arquivos"]["log_s3"] = f"s3://{S3_BUCKET}/{log_key}"
            resumo["arquivos"]["resumo_s3"] = f"s3://{S3_BUCKET}/{summary_key}"

            # Atualizar arquivo local com URLs S3
            with open(summary_file, "w", encoding="utf-8") as f:
                json.dump(resumo, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logging.warning(f"Nao foi possivel enviar logs para S3: {e}")
