"""
Modulo de transformacao de dados CNES usando Polars.
"""
import logging
from datetime import datetime
from pathlib import Path

import polars as pl

logger = logging.getLogger(__name__)

# Colunas que devem ser tratadas como string por prefixo
COLS_STR = {
    "ST": [
        # Campos de identificação
        "cnes", "codufmun", "cpf_cnpj", "cnpj_man", "cod_cep",
        # Campos administrativos
        "pf_pj", "niv_dep", "tp_unid", "tpgestao", "esfera_a",
        "natureza", "niv_hier", "turno_at", "clientel", "tp_prest",
        "atividad", "retencao", "cod_ir", "vinc_sus",
        # Campos geográficos/administrativos CRÍTICOS
        "regsaude", "micr_reg", "distrsan", "distradm", "nat_jur",
        # Campos de atendimento importantes
        "leithosp", "urgemerg", "atendamb", "centobs", "apoiodia",
        "serv_hos", "outrasat",
    ],
    "PF": [
        # Campos de identificação
        "cnes", "codufmun", "cpf_prof", "cns_prof", "registro",
        "cbo", "vinculac", "vinculus",
        # Campos geográficos/administrativos CRÍTICOS
        "regsaude", "micr_reg", "distrsan", "distradm", "nat_jur",
        # Campos profissionais importantes
        "nomeprof", "conselho", "prof_sus", "vincul_c", "vincul_a",
    ],
    "EQ": [
        # Campos de identificação
        "cnes", "codufmun", "codequip", "tipequip", "ind_sus",
        # Campos geográficos/administrativos CRÍTICOS
        "regsaude", "micr_reg", "distrsan", "distradm", "nat_jur",
        # Campos adicionais
        "ind_nsus",
    ],
    "SR": [
        # Campos de identificação
        "cnes", "codufmun", "serv_esp", "class_sr",
        # Campos geográficos/administrativos CRÍTICOS
        "regsaude", "micr_reg", "distrsan", "distradm", "nat_jur",
        # Campos corretos conforme IT_CNES_1706.pdf
        "caracter", "amb_hosp", "srvunico", "cnesterc",
    ],
}

# Colunas numericas por prefixo
COLS_INT = {
    "ST": ["competen"],
    "PF": ["horaoutr", "horahosp", "hora_amb", "competen"],
    "EQ": ["qt_exist", "qt_uso", "competen"],
    "SR": ["competen"],
}


def transform(prefixo: str, arquivos: list[Path], ano: int, mes: int) -> pl.DataFrame:
    """Transforma dados CNES aplicando tipos e adicionando metadados."""
    if not arquivos:
        return pl.DataFrame()

    logger.info(f"{prefixo}: Lendo {len(arquivos)} arquivos parquet...")
    df = pl.read_parquet(arquivos)

    if df.is_empty():
        return df

    df = df.rename({col: col.lower() for col in df.columns})

    cols_str = COLS_STR.get(prefixo, [])
    for col in cols_str:
        if col in df.columns:
            df = df.with_columns(
                pl.col(col).cast(pl.Utf8).str.strip_chars().alias(col)
            )

    cols_int = COLS_INT.get(prefixo, [])
    for col in cols_int:
        if col in df.columns:
            df = df.with_columns(
                pl.col(col).cast(pl.Int64, strict=False).fill_null(0).alias(col)
            )

    df = df.with_columns([
        pl.lit(ano).alias("ano_cmp"),
        pl.lit(mes).alias("mes_cmp"),
        pl.lit(datetime.now()).alias("data_carga"),
    ])

    if "codufmun" in df.columns:
        df = df.with_columns(
            pl.col("codufmun").str.slice(0, 2).alias("cod_uf")
        )

    logger.info(f"{prefixo}: {len(df)} registros transformados")
    return df
