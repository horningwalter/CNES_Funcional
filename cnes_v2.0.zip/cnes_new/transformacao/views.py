"""
Views semanticas para analytics - modelagem dimensional.
Transforma dados brutos em estruturas otimizadas para BI e analise.
"""
import logging
import polars as pl

from config.dominios import (
    TIPO_PESSOA, NIVEL_DEPENDENCIA, TIPO_GESTAO, ESFERA_ADMINISTRATIVA,
    NATUREZA_ORGANIZACAO, TIPO_UNIDADE, NIVEL_HIERARQUIA, TURNO_ATENDIMENTO,
    FLUXO_CLIENTELA, TIPO_PRESTADOR, RETENCAO_TRIBUTOS, VINCULO_SUS,
    TIPO_EQUIPAMENTO, DISPONIBILIDADE_SUS, CARACTERISTICA_SERVICO
)

logger = logging.getLogger(__name__)


def create_st_semantic_view(df: pl.DataFrame) -> pl.DataFrame:
    """
    Cria view semantica dimensional de estabelecimentos.

    Estrutura otimizada para queries de BI:
    - Dimensoes geograficas (UF, municipio, regiao)
    - Dimensoes administrativas (gestao, esfera, natureza)
    - Dimensoes operacionais (tipo, hierarquia, prestador)
    - Metricas booleanas para filtros rapidos
    - Campos decodificados para reports
    """
    if df.is_empty():
        return df

    view = df.clone()

    # Decodificacoes (manter campos originais + criar _desc)
    decodificacoes = {
        "pf_pj": (TIPO_PESSOA, "tipo_pessoa_desc"),
        "niv_dep": (NIVEL_DEPENDENCIA, "nivel_dependencia_desc"),
        "tpgestao": (TIPO_GESTAO, "tipo_gestao_desc"),
        "esfera_a": (ESFERA_ADMINISTRATIVA, "esfera_administrativa_desc"),
        "natureza": (NATUREZA_ORGANIZACAO, "natureza_organizacao_desc"),
        "tp_unid": (TIPO_UNIDADE, "tipo_unidade_desc"),
        "niv_hier": (NIVEL_HIERARQUIA, "nivel_hierarquia_desc"),
        "turno_at": (TURNO_ATENDIMENTO, "turno_atendimento_desc"),
        "clientel": (FLUXO_CLIENTELA, "fluxo_clientela_desc"),
        "tp_prest": (TIPO_PRESTADOR, "tipo_prestador_desc"),
        "retencao": (RETENCAO_TRIBUTOS, "retencao_tributos_desc"),
        "vinc_sus": (VINCULO_SUS, "vinculo_sus_desc"),
    }

    for col, (mapping, new_col) in decodificacoes.items():
        if col in view.columns:
            view = view.with_columns(
                pl.col(col).map_dict(mapping, default="Não informado").alias(new_col)
            )

    # Dimensoes geograficas hierarquicas
    if "codufmun" in view.columns:
        view = view.with_columns([
            pl.col("codufmun").str.slice(0, 2).alias("cod_uf"),
            pl.col("codufmun").str.slice(0, 4).alias("cod_regiao_saude"),
        ])

    # Flags booleanas para filtros rapidos (otimizado para WHERE clauses)
    flags = []

    if "esfera_a" in view.columns:
        flags.extend([
            (pl.col("esfera_a") == "01").alias("is_federal"),
            (pl.col("esfera_a") == "02").alias("is_estadual"),
            (pl.col("esfera_a") == "03").alias("is_municipal"),
            (pl.col("esfera_a") == "04").alias("is_privado"),
        ])

    if "tpgestao" in view.columns:
        flags.extend([
            (pl.col("tpgestao").is_in(["M", "D"])).alias("has_gestao_municipal"),
            (pl.col("tpgestao").is_in(["E", "D"])).alias("has_gestao_estadual"),
        ])

    if "vinc_sus" in view.columns:
        flags.append((pl.col("vinc_sus") == "1").alias("is_sus"))

    if "leithosp" in view.columns:
        flags.append((pl.col("leithosp") == "1").alias("tem_leitos"))

    if "urgemerg" in view.columns:
        flags.append((pl.col("urgemerg") == "1").alias("tem_urgencia"))

    if "atendamb" in view.columns:
        flags.append((pl.col("atendamb") == "1").alias("tem_ambulatorio"))

    if flags:
        view = view.with_columns(flags)

    # Categorias de analise
    if "tp_unid" in view.columns:
        view = view.with_columns(
            pl.when(pl.col("tp_unid").is_in(["01", "02", "15", "20", "21", "22", "36", "39", "40", "42", "60", "61", "62", "64", "70", "71", "72", "73", "74", "75", "76"]))
            .then(pl.lit("Hospitalar"))
            .when(pl.col("tp_unid").is_in(["04", "05", "32", "83"]))
            .then(pl.lit("Ambulatorial"))
            .when(pl.col("tp_unid").is_in(["07", "69", "79"]))
            .then(pl.lit("Apoio Diagnóstico"))
            .otherwise(pl.lit("Outros"))
            .alias("categoria_estabelecimento")
        )

    logger.info(f"ST: View semantica criada com {len(decodificacoes)} decodificacoes e {len(flags)} flags booleanas")
    return view


def create_pf_semantic_view(df: pl.DataFrame) -> pl.DataFrame:
    """
    Cria view semantica dimensional de profissionais.

    Estrutura otimizada para analytics RH:
    - Agregacao por CBO (ocupacao)
    - Agregacao por vinculo
    - Metricas de carga horaria
    - Flags de atuacao (SUS, ambulatorio, hospital)
    """
    if df.is_empty():
        return df

    view = df.clone()

    # Dimensao geografica
    if "codufmun" in view.columns:
        view = view.with_columns([
            pl.col("codufmun").str.slice(0, 2).alias("cod_uf"),
        ])

    # Metricas de carga horaria total
    carga_cols = ["horaoutr", "horahosp", "hora_amb"]
    existing_cols = [c for c in carga_cols if c in view.columns]

    if existing_cols:
        view = view.with_columns(
            pl.sum_horizontal(existing_cols).alias("carga_horaria_total")
        )

    # Flags de atuacao
    flags = []

    if "prof_sus" in view.columns:
        flags.append((pl.col("prof_sus") == "S").alias("atua_sus"))

    if "vincul_a" in view.columns:
        flags.append((pl.col("vincul_a").is_not_null()).alias("tem_vinculo_autonomo"))

    if "vincul_c" in view.columns:
        flags.append((pl.col("vincul_c").is_not_null()).alias("tem_vinculo_clt"))

    if "horahosp" in view.columns:
        flags.append((pl.col("horahosp") > 0).alias("atua_hospital"))

    if "hora_amb" in view.columns:
        flags.append((pl.col("hora_amb") > 0).alias("atua_ambulatorio"))

    if flags:
        view = view.with_columns(flags)

    # Categoria profissional baseada em CBO
    if "cbo" in view.columns:
        view = view.with_columns(
            pl.when(pl.col("cbo").str.starts_with("22"))
            .then(pl.lit("Médico"))
            .when(pl.col("cbo").str.starts_with("223"))
            .then(pl.lit("Enfermeiro"))
            .when(pl.col("cbo").str.starts_with("322"))
            .then(pl.lit("Técnico de Enfermagem"))
            .when(pl.col("cbo").str.starts_with("225"))
            .then(pl.lit("Odontólogo"))
            .when(pl.col("cbo").str.starts_with("251"))
            .then(pl.lit("Psicólogo"))
            .otherwise(pl.lit("Outros"))
            .alias("categoria_profissional")
        )

    logger.info(f"PF: View semantica criada com {len(flags)} flags e metricas de carga horaria")
    return view


def create_eq_semantic_view(df: pl.DataFrame) -> pl.DataFrame:
    """
    Cria view semantica dimensional de equipamentos.

    Estrutura otimizada para analytics de infraestrutura:
    - Decodificacao de tipos
    - Metricas de disponibilidade e uso
    - Taxa de utilizacao
    - Flags de disponibilidade SUS/nao-SUS
    """
    if df.is_empty():
        return df

    view = df.clone()

    # Decodificacoes
    if "tipequip" in view.columns:
        view = view.with_columns(
            pl.col("tipequip").map_dict(TIPO_EQUIPAMENTO, default="Não informado").alias("tipo_equipamento_desc")
        )

    if "ind_sus" in view.columns:
        view = view.with_columns(
            pl.col("ind_sus").map_dict(DISPONIBILIDADE_SUS, default="Não informado").alias("disponivel_sus_desc")
        )

    if "ind_nsus" in view.columns:
        view = view.with_columns(
            pl.col("ind_nsus").map_dict(DISPONIBILIDADE_SUS, default="Não informado").alias("disponivel_nao_sus_desc")
        )

    # Dimensao geografica
    if "codufmun" in view.columns:
        view = view.with_columns([
            pl.col("codufmun").str.slice(0, 2).alias("cod_uf"),
        ])

    # Metricas de utilizacao
    if all(c in view.columns for c in ["qt_exist", "qt_uso"]):
        view = view.with_columns([
            (pl.col("qt_uso") - pl.col("qt_exist")).alias("qt_ociosa"),
            (pl.col("qt_uso") / pl.col("qt_exist") * 100).alias("taxa_utilizacao_pct"),
        ])

    # Flags
    flags = []

    if "ind_sus" in view.columns:
        flags.append((pl.col("ind_sus") == "S").alias("disponivel_sus"))

    if "ind_nsus" in view.columns:
        flags.append((pl.col("ind_nsus") == "S").alias("disponivel_nao_sus"))

    if "qt_uso" in view.columns and "qt_exist" in view.columns:
        flags.extend([
            (pl.col("qt_uso") > pl.col("qt_exist")).alias("tem_equipamento_ocioso"),
            (pl.col("qt_uso") == pl.col("qt_exist")).alias("uso_total"),
        ])

    if flags:
        view = view.with_columns(flags)

    logger.info(f"EQ: View semantica criada com 3 decodificacoes, metricas de uso e {len(flags)} flags")
    return view


def create_sr_semantic_view(df: pl.DataFrame) -> pl.DataFrame:
    """
    Cria view semantica dimensional de servicos especializados.

    Estrutura otimizada para analytics de servicos:
    - Decodificacao de caracteristicas
    - Flags de tipo de atendimento
    - Categoria de servico
    """
    if df.is_empty():
        return df

    view = df.clone()

    # Decodificacao
    if "caracter" in view.columns:
        view = view.with_columns(
            pl.col("caracter").map_dict(CARACTERISTICA_SERVICO, default="Não informado").alias("caracteristica_desc")
        )

    # Dimensao geografica
    if "codufmun" in view.columns:
        view = view.with_columns([
            pl.col("codufmun").str.slice(0, 2).alias("cod_uf"),
        ])

    # Flags de tipo de atendimento
    flags = []

    if "amb_hosp" in view.columns:
        flags.extend([
            (pl.col("amb_hosp") == "A").alias("is_ambulatorial"),
            (pl.col("amb_hosp") == "H").alias("is_hospitalar"),
            (pl.col("amb_hosp") == "B").alias("is_ambos"),
        ])

    if "srvunico" in view.columns:
        flags.append((pl.col("srvunico") == "S").alias("is_servico_unico"))

    if flags:
        view = view.with_columns(flags)

    logger.info(f"SR: View semantica criada com 1 decodificacao e {len(flags)} flags")
    return view


def create_semantic_view(prefixo: str, df: pl.DataFrame) -> pl.DataFrame:
    """Cria view semantica dimensional baseado no prefixo."""
    creators = {
        "ST": create_st_semantic_view,
        "PF": create_pf_semantic_view,
        "EQ": create_eq_semantic_view,
        "SR": create_sr_semantic_view,
    }

    creator = creators.get(prefixo)
    if not creator:
        logger.warning(f"{prefixo}: Nenhum criador de view semantica disponivel")
        return df

    return creator(df)
