"""
Modulo de storage S3 para dados CNES.
"""
import io
import logging

import boto3
import polars as pl
from botocore.exceptions import ClientError, NoCredentialsError

from config import S3_BUCKET, S3_PREFIX, AWS_REGION

logger = logging.getLogger(__name__)

# Cliente S3
_s3_client = None


def validate_credentials():
    """Valida credenciais AWS."""
    try:
        client = boto3.client("s3", region_name=AWS_REGION)
        client.list_buckets()
        logger.info("Credenciais AWS validadas com sucesso")
        return True
    except NoCredentialsError:
        logger.error("Credenciais AWS nao encontradas. Configure usando 'aws configure' ou variaveis de ambiente")
        return False
    except ClientError as e:
        logger.error(f"Erro ao validar credenciais AWS: {e}")
        return False
    except Exception as e:
        logger.error(f"Erro inesperado ao validar credenciais: {e}")
        return False


def validate_bucket():
    """Valida existencia e acesso ao bucket S3."""
    try:
        client = get_client()
        client.head_bucket(Bucket=S3_BUCKET)
        logger.info(f"Bucket S3 '{S3_BUCKET}' validado com sucesso")
        return True
    except ClientError as e:
        error_code = e.response["Error"]["Code"]
        if error_code == "404":
            logger.error(f"Bucket '{S3_BUCKET}' nao existe")
        elif error_code == "403":
            logger.error(f"Sem permissao para acessar bucket '{S3_BUCKET}'")
        else:
            logger.error(f"Erro ao validar bucket: {e}")
        return False


def get_client():
    """Retorna cliente S3 singleton."""
    global _s3_client
    if _s3_client is None:
        _s3_client = boto3.client("s3", region_name=AWS_REGION)
    return _s3_client


def get_s3_key(prefixo: str, ano: int, mes: int, layer: str = "raw") -> str:
    """Gera chave S3 no formato particionado por ano/mes."""
    return f"{S3_PREFIX}/{layer}/{prefixo.lower()}/ano={ano}/mes={mes:02d}/{prefixo.lower()}_{ano}{mes:02d}.parquet"


def upload_parquet(df: pl.DataFrame, prefixo: str, ano: int, mes: int, layer: str = "raw") -> str:
    """Salva DataFrame como Parquet no S3."""
    if df.is_empty():
        logger.warning(f"{prefixo}: DataFrame vazio, nada a salvar")
        return ""

    key = get_s3_key(prefixo, ano, mes, layer)

    buffer = io.BytesIO()
    df.write_parquet(buffer, compression="snappy")
    buffer.seek(0)

    client = get_client()
    client.put_object(
        Bucket=S3_BUCKET,
        Key=key,
        Body=buffer.getvalue(),
        ContentType="application/octet-stream",
    )

    logger.info(f"{prefixo}: Upload concluido -> s3://{S3_BUCKET}/{key}")
    return key


def file_exists(prefixo: str, ano: int, mes: int) -> bool:
    """Verifica se arquivo ja existe no S3."""
    key = get_s3_key(prefixo, ano, mes)
    client = get_client()

    try:
        client.head_object(Bucket=S3_BUCKET, Key=key)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return False
        raise


def list_files(prefixo: str | None = None, ano: int | None = None) -> list[str]:
    """Lista arquivos no S3, opcionalmente filtrados por prefixo e ano."""
    client = get_client()

    search_prefix = S3_PREFIX + "/raw/"
    if prefixo:
        search_prefix += f"{prefixo.lower()}/"
        if ano:
            search_prefix += f"ano={ano}/"

    paginator = client.get_paginator("list_objects_v2")
    keys = []

    for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=search_prefix):
        for obj in page.get("Contents", []):
            keys.append(obj["Key"])

    return keys


def download_parquet(prefixo: str, ano: int, mes: int) -> pl.DataFrame:
    """Baixa e le arquivo Parquet do S3."""
    key = get_s3_key(prefixo, ano, mes)
    client = get_client()

    try:
        response = client.get_object(Bucket=S3_BUCKET, Key=key)
        buffer = io.BytesIO(response["Body"].read())
        return pl.read_parquet(buffer)
    except ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            logger.warning(f"Arquivo nao encontrado: s3://{S3_BUCKET}/{key}")
            return pl.DataFrame()
        raise
