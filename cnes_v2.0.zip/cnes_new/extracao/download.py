"""
Modulo de extracao de dados do CNES via PySUS.
"""
import logging
import time
from datetime import datetime
from dateutil.relativedelta import relativedelta
from pathlib import Path

from pysus.ftp.databases.cnes import CNES

logger = logging.getLogger(__name__)

# Configuracoes de retry
MAX_RETRIES = 3
RETRY_DELAY = 5  # segundos


def get_previous_month() -> tuple[int, int]:
    """Retorna ano e mes do mes anterior."""
    prev = datetime.now() - relativedelta(months=1)
    return prev.year % 100, prev.month


def download_cnes(
    ano: int,
    mes: int,
    prefixos: list[str],
    ufs: list[str] | None = None,
) -> dict[str, list[Path]]:
    """Baixa arquivos CNES do DATASUS com retry automatico."""
    cnes = CNES().load()
    resultado = {}

    for prefixo in prefixos:
        parquet_files = []

        for tentativa in range(1, MAX_RETRIES + 1):
            try:
                logger.info(f"{prefixo}: Buscando arquivos (tentativa {tentativa}/{MAX_RETRIES})...")
                arquivos = cnes.get_files(group=prefixo, uf=ufs, year=ano, month=mes)

                if not arquivos:
                    logger.warning(f"{prefixo}: Nenhum arquivo encontrado")
                    resultado[prefixo] = []
                    break

                logger.info(f"{prefixo}: Baixando {len(arquivos)} arquivos...")
                parquet_set = cnes.download(arquivos)

                if parquet_set is None:
                    raise ValueError("Download retornou None")

                if hasattr(parquet_set, "path") and parquet_set.path:
                    parquet_path = Path(parquet_set.path)
                    if not parquet_path.exists():
                        raise ValueError(f"Diretorio de parquets nao encontrado: {parquet_path}")

                    parquet_files = list(parquet_path.glob("*.parquet"))
                    if not parquet_files:
                        logger.warning(f"{prefixo}: Nenhum arquivo parquet encontrado em {parquet_path}")
                    else:
                        logger.info(f"{prefixo}: {len(parquet_files)} arquivos baixados com sucesso")
                    resultado[prefixo] = parquet_files
                    break
                else:
                    raise ValueError("Objeto download nao possui atributo 'path' ou esta vazio")

            except Exception as e:
                logger.error(f"{prefixo}: Erro na tentativa {tentativa}/{MAX_RETRIES} - {e}")

                if tentativa < MAX_RETRIES:
                    logger.info(f"{prefixo}: Aguardando {RETRY_DELAY}s antes de tentar novamente...")
                    time.sleep(RETRY_DELAY)
                else:
                    logger.error(f"{prefixo}: Todas as tentativas falharam")
                    resultado[prefixo] = []

    return resultado
