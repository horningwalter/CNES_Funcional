# Dicionário de Dados - CNES (Cadastro Nacional de Estabelecimentos de Saúde)

## Índice
- [Visão Geral](#visão-geral)
- [ST - Estabelecimentos](#st---estabelecimentos-facilities)
- [PF - Profissionais](#pf---profissionais-professionals)
- [EQ - Equipamentos](#eq---equipamentos-equipment)
- [SR - Serviços Especializados](#sr---serviços-especializados-specialized-services)
- [Dimensões Criadas](#dimensões-criadas)
- [Fatos Criados](#fatos-criados)
- [Views Agregadas](#views-agregadas)

---

## Visão Geral

Este dicionário documenta a estrutura de dados do CNES, desde os arquivos brutos (raw) até as views semânticas criadas para análise.

### Estrutura de Auditoria (Comum a Todas as Tabelas)

| Campo Raw | Campo View | Tipo | Descrição |
|-----------|------------|------|-----------|
| - | `_ano_cmp` | INTEGER | Ano de competência da carga |
| - | `_mes_cmp` | INTEGER | Mês de competência da carga |
| - | `_data_carga` | TIMESTAMP | Data/hora da carga no banco |

### Campos Comuns (Chaves de Relacionamento)

| Campo Raw | Campo View | Tipo | Descrição |
|-----------|------------|------|-----------|
| `CNES` | `cnes` | TEXT | Código do estabelecimento (7 dígitos) - Chave primária |
| `CODUFMUN` | `codufmun` | TEXT | Código IBGE do município (7 dígitos: 2 UF + 5 município) |

---

## ST - Estabelecimentos (Facilities)

Arquivo: **STAAMM.dbc** (AA=ano, MM=mês)
Tabela Raw: `raw_st`
Fato: `fato_estabelecimento`

### Campos de Identificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `CNES` | `cnes` | TEXT | facility_code | Código CNES do estabelecimento | - |
| `CODUFMUN` | `codufmun` | TEXT | municipality_code | Código município IBGE | - |
| `CPF_CNPJ` | `cpf_cnpj` | TEXT | tax_id | CPF ou CNPJ do responsável | - |
| `CNPJ_MAN` | `cnpj_man` | TEXT | maintainer_tax_id | CNPJ da mantenedora | - |
| `COD_CEP` | `cod_cep` | TEXT | zipcode | CEP do estabelecimento | - |
| `PF_PJ` | `pf_pj` | TEXT | person_type | Tipo de pessoa | 1=Física, 3=Jurídica |
| `NIV_DEP` | `niv_dep` | TEXT | dependency_level | Nível de dependência | 1=Individual, 3=Mantida |

### Campos de Classificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `TP_UNID` | `tp_unid` | TEXT | facility_type | Tipo de unidade | Ver TIPO_UNIDADE (85 tipos) |
| `TPGESTAO` | `tpgestao` | TEXT | management_type | Tipo de gestão | D=Dupla, E=Estadual, M=Municipal |
| `ESFERA_A` | `esfera_a` | TEXT | administrative_sphere | Esfera administrativa | 01=Federal, 02=Estadual, 03=Municipal, 04=Privada |
| `NATUREZA` | `natureza` | TEXT | legal_nature | Natureza jurídica | Ver NATUREZA_ORGANIZACAO (13 tipos) |
| `NIV_HIER` | `niv_hier` | TEXT | hierarchy_level | Nível de hierarquia | 01=Atenção Básica, 03=Média, 08=Alta |
| `TURNO_AT` | `turno_at` | TEXT | shift | Turno de atendimento | 02=24h, 03=M/T/N, 04=Manhã, etc |
| `CLIENTEL` | `clientel` | TEXT | patient_flow | Fluxo de clientela | 01=Espontânea, 02=Referenciada, 03=Ambas |
| `TP_PREST` | `tp_prest` | TEXT | provider_type | Tipo de prestador | 20=Privado, 30/40/50=Público, 60=Sem fins lucrativos |
| `ATIVIDAD` | `atividad` | TEXT | teaching_activity | Atividade de ensino | 01=Universitária, 05=Hospital Ensino |
| `RETENCAO` | `retencao` | TEXT | tax_retention | Retenção de tributos | Ver RETENCAO_TRIBUTOS |
| `COD_IR` | `cod_ir` | TEXT | income_tax_code | Código IR | - |

### Campos SUS

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `VINC_SUS` | `vinc_sus` | TEXT | sus_linked | Vinculado ao SUS | 0=Não, 1=Sim |

### Campos Calculados no Fato

| Campo View | Tipo | Descrição |
|------------|------|-----------|
| `cod_municipio` | TEXT | Código do município (cópia de codufmun) |
| `cod_uf` | TEXT | Código UF (2 primeiros dígitos de codufmun) |
| `sk_tempo` | INTEGER | Surrogate key tempo (ano*100 + mes) |
| `cod_tipo_unidade` | TEXT | Código tipo unidade (cópia de tp_unid) |
| `cod_natureza` | TEXT | Código natureza (cópia de natureza) |
| `tipo_gestao` | TEXT | Tipo gestão (cópia de tpgestao) |
| `vinculo_sus` | INTEGER | Indicador SUS (0/1) |
| `esfera_administrativa` | TEXT | Esfera administrativa (cópia de esfera_a) |
| `turno_atendimento` | TEXT | Turno atendimento (cópia de turno_at) |
| `nivel_hierarquia` | TEXT | Nível hierarquia (cópia de niv_hier) |
| `qtd_estabelecimentos` | INTEGER | Contador fixo = 1 (para agregações) |

---

## PF - Profissionais (Professionals)

Arquivo: **PFAAMM.dbc**
Tabela Raw: `raw_pf`
Fato: `fato_profissional`

### Campos de Identificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `CNES` | `cnes` | TEXT | facility_code | Código CNES do estabelecimento | - |
| `CODUFMUN` | `codufmun` | TEXT | municipality_code | Código município IBGE | - |
| `CPF_PROF` | `cpf_prof` | TEXT | professional_tax_id | CPF do profissional | - |
| `CNS_PROF` | `cns_prof` | TEXT | national_health_card | Cartão Nacional de Saúde | - |
| `REGISTRO` | `registro` | TEXT | registration | Registro profissional (CRM, COREN, etc) | - |

### Campos de Classificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `CBO` | `cbo` | TEXT | occupation_code | Código CBO (Classificação Brasileira Ocupações) | Ver CBO (316 códigos) |
| `VINCULAC` | `vinculac` | TEXT | employment_type | Tipo de vínculo | 01=Empregatício, 02=Autônomo, 04=Residência, etc |
| `VINCULUS` | `vinculus` | TEXT | sus_linked | Vínculo SUS | 0=Não, 1=Sim |

### Campos de Carga Horária

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição |
|-----------|------------|------|-------------|-----------|
| `HORAOUTR` | `horaoutr` | TEXT→INT | other_hours | Carga horária outros |
| `HORAHOSP` | `horahosp` | TEXT→INT | hospital_hours | Carga horária hospitalar |
| `HORA_AMB` | `hora_amb` | TEXT→INT | outpatient_hours | Carga horária ambulatorial |

### Campos Calculados no Fato

| Campo View | Tipo | Descrição |
|------------|------|-----------|
| `cod_municipio` | TEXT | Código do município |
| `cod_uf` | TEXT | Código UF (2 dígitos) |
| `sk_tempo` | INTEGER | Surrogate key tempo |
| `cod_cbo` | TEXT | Código CBO |
| `cns_profissional` | TEXT | CNS do profissional |
| `cod_vinculo` | TEXT | Código tipo vínculo |
| `vinculo_sus` | INTEGER | Indicador SUS (0/1) |
| `ch_outros` | INTEGER | Carga horária outros (convertido) |
| `ch_hospitalar` | INTEGER | Carga horária hospitalar (convertido) |
| `ch_ambulatorial` | INTEGER | Carga horária ambulatorial (convertido) |
| `ch_total` | INTEGER | Soma de todas as cargas horárias |
| `qtd_vinculos` | INTEGER | Contador fixo = 1 |

---

## EQ - Equipamentos (Equipment)

Arquivo: **EQAAMM.dbc**
Tabela Raw: `raw_eq`
Fato: `fato_equipamento`

### Campos de Identificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `CNES` | `cnes` | TEXT | facility_code | Código CNES do estabelecimento | - |
| `CODUFMUN` | `codufmun` | TEXT | municipality_code | Código município IBGE | - |

### Campos de Classificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `CODEQUIP` | `codequip` | TEXT | equipment_code | Código do equipamento | Ver CODIGO_EQUIPAMENTO (60+ códigos) |
| `TIPEQUIP` | `tipequip` | TEXT | equipment_type | Tipo de equipamento | 01=Imagem, 02=Infraestrutura, 05=Manutenção Vida, etc |
| `IND_SUS` | `ind_sus` | TEXT | sus_available | Disponível para SUS | 0=Não, 1=Sim |

### Campos Quantitativos

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição |
|-----------|------------|------|-------------|-----------|
| `QT_EXIST` | `qt_exist` | TEXT→INT | quantity_existing | Quantidade existente |
| `QT_USO` | `qt_uso` | TEXT→INT | quantity_in_use | Quantidade em uso |

### Campos Calculados no Fato

| Campo View | Tipo | Descrição |
|------------|------|-----------|
| `cod_municipio` | TEXT | Código do município |
| `cod_uf` | TEXT | Código UF (2 dígitos) |
| `sk_tempo` | INTEGER | Surrogate key tempo |
| `cod_equipamento` | TEXT | Código do equipamento |
| `tipo_equipamento` | TEXT | Tipo do equipamento |
| `qtd_existente` | INTEGER | Quantidade existente (convertido) |
| `qtd_em_uso` | INTEGER | Quantidade em uso (convertido) |
| `disponivel_sus` | INTEGER | Indicador SUS (0/1) |

---

## SR - Serviços Especializados (Specialized Services)

Arquivo: **SRAAMM.dbc**
Tabela Raw: `raw_sr`
Fato: `fato_servico`

### Campos de Identificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `CNES` | `cnes` | TEXT | facility_code | Código CNES do estabelecimento | - |
| `CODUFMUN` | `codufmun` | TEXT | municipality_code | Código município IBGE | - |

### Campos de Classificação

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição | Domínio |
|-----------|------------|------|-------------|-----------|---------|
| `SERV_ESP` | `serv_esp` | TEXT | service_code | Código serviço especializado | Ver SERVICO_ESPECIALIZADO (50+ serviços) |
| `CLASS_SR` | `class_sr` | TEXT | service_classification | Classificação do serviço | Ver CLASSIFICACAO_SERVICO |
| `CATEFLE` | `catefle` | TEXT | service_characteristic | Característica | 001=Ambulatorial, 002=Hospitalar, 003=Ambos |
| `SESSION` | `session` | TEXT | session | Código de sessão | - |

### Campos SUS (Ambulatorial)

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição |
|-----------|------------|------|-------------|-----------|
| `AMB_SUS` | `amb_sus` | TEXT | outpatient_sus | Ambulatorial SUS |
| `AMB_NSUS` | `amb_nsus` | TEXT | outpatient_non_sus | Ambulatorial não-SUS |

### Campos SUS (Hospitalar)

| Campo Raw | Campo View | Tipo | Tradução EN | Descrição |
|-----------|------------|------|-------------|-----------|
| `HOSP_SUS` | `hosp_sus` | TEXT | hospital_sus | Hospitalar SUS |
| `HOSP_NSUS` | `hosp_nsus` | TEXT | hospital_non_sus | Hospitalar não-SUS |

### Campos Calculados no Fato

| Campo View | Tipo | Descrição |
|------------|------|-----------|
| `cod_municipio` | TEXT | Código do município |
| `cod_uf` | TEXT | Código UF (2 dígitos) |
| `sk_tempo` | INTEGER | Surrogate key tempo |
| `cod_servico` | TEXT | Código do serviço |
| `classificacao` | TEXT | Classificação do serviço |
| `ambulatorial_sus` | INTEGER | Indicador ambulatorial SUS (0/1) |
| `ambulatorial_nao_sus` | INTEGER | Indicador ambulatorial não-SUS (0/1) |
| `hospitalar_sus` | INTEGER | Indicador hospitalar SUS (0/1) |
| `hospitalar_nao_sus` | INTEGER | Indicador hospitalar não-SUS (0/1) |
| `qtd_servicos` | INTEGER | Contador fixo = 1 |

---

## Dimensões Criadas

### dim_tempo (Time Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `sk_tempo` | INTEGER | Chave surrogate (AAAAMM) |
| `ano` | INTEGER | Ano (2024, 2025, etc) |
| `mes` | INTEGER | Mês (1-12) |
| `nome_mes` | TEXT | Nome do mês (Janeiro, Fevereiro, ...) |
| `trimestre` | INTEGER | Trimestre (1-4) |
| `semestre` | INTEGER | Semestre (1-2) |

**Fonte**: `raw_st` (_ano_cmp, _mes_cmp)

---

### dim_uf (State/Region Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `cod_uf` | TEXT | Código UF (11-53) |
| `sigla_uf` | TEXT | Sigla UF (RO, AC, AM, ..., DF) |
| `nome_uf` | TEXT | Nome completo (Rondônia, Acre, ...) |
| `regiao` | TEXT | Região (Norte, Nordeste, Sudeste, Sul, Centro-Oeste) |

**Fonte**: `raw_st` (codufmun - 2 primeiros dígitos)

**Mapeamento Completo**:
- **Norte**: RO(11), AC(12), AM(13), RR(14), PA(15), AP(16), TO(17)
- **Nordeste**: MA(21), PI(22), CE(23), RN(24), PB(25), PE(26), AL(27), SE(28), BA(29)
- **Sudeste**: MG(31), ES(32), RJ(33), SP(35)
- **Sul**: PR(41), SC(42), RS(43)
- **Centro-Oeste**: MS(50), MT(51), GO(52), DF(53)

---

### dim_tipo_unidade (Facility Type Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `cod_tipo_unidade` | TEXT | Código tipo (01-86) |
| `desc_tipo_unidade` | TEXT | Descrição completa |
| `categoria` | TEXT | Categoria agrupada |

**Fonte**: `raw_st` (tp_unid)

**Categorias**:
- **Atenção Básica**: Posto de Saúde, Centro de Saúde, Centro Apoio SF, Polo Academia
- **Hospitalar**: Hospital Geral, Hospital Especializado, Unidade Mista, Centro Parto Normal, Hospital/Dia
- **Urgência/Emergência**: Pronto Socorro Geral/Especializado, Unidade Móvel Urgência, Pronto Atendimento
- **Ambulatorial**: Policlínica, Consultório Isolado, Clínica/Centro Especialidade, Unidade Apoio Diagnose
- **Especializado**: Centro Hemoterapia, Centro Atenção Psicossocial, Home Care, Laboratório Saúde Pública

---

### dim_natureza_juridica (Legal Nature Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `cod_natureza` | TEXT | Código natureza (01-13) |
| `desc_natureza` | TEXT | Descrição completa |
| `setor` | TEXT | Setor (Público, Privado, Filantrópico) |

**Fonte**: `raw_st` (natureza)

**Setores**:
- **Público**: Adm Direta Saúde(01), Adm Direta outros(02), Autarquias(03), Fundação Pública(04), Empresa Pública(05), Organização Social(06)
- **Privado**: Empresa Privada(07), Fundação Privada(08), Cooperativa(09), Economia Mista(12), Sindicato(13)
- **Filantrópico**: Serviço Social Autônomo(10), Entidade Beneficente(11)

---

### dim_cbo (Professional Classification Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `cod_cbo` | TEXT | Código CBO (6 dígitos) |
| `categoria_profissional` | TEXT | Categoria profissional |
| `nivel_formacao` | TEXT | Nível de formação |

**Fonte**: `raw_pf` (cbo)

**Categorias Profissionais**:
- **Médico**: CBO 2231*, 2251*, 2252*, 2253*
- **Enfermeiro**: CBO 2235*
- **Técnico/Auxiliar Enfermagem**: CBO 3222*
- **Cirurgião Dentista**: CBO 2232*
- **Técnico Saúde Bucal**: CBO 3224*
- **Farmacêutico**: CBO 2234*
- **Fisioterapeuta**: CBO 2236*
- **Nutricionista**: CBO 2237*
- **Fonoaudiólogo**: CBO 2238*
- **Terapeuta Ocupacional**: CBO 2239*
- **Psicólogo**: CBO 2515*
- **Assistente Social**: CBO 2516*
- **Agente Comunitário Saúde**: CBO 5151*
- **Técnico Radiologia**: CBO 3241*
- **Técnico Patologia Clínica**: CBO 3242*

**Níveis de Formação**:
- **Superior**: CBO iniciado com 2
- **Técnico**: CBO iniciado com 3
- **Elementar**: CBO iniciado com 5

---

### dim_servico (Healthcare Service Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `cod_servico` | TEXT | Código serviço (100-159) |
| `desc_servico` | TEXT | Descrição completa |
| `grupo_servico` | TEXT | Grupo de serviço |

**Fonte**: `raw_sr` (serv_esp)

**Grupos de Serviços**:
- **Diagnóstico**: Imagem(105), Laboratório(106), Endoscopia(107), Medicina Nuclear(134)
- **Oncologia**: Oncologia(112), Radioterapia(135), Quimioterapia(136)
- **Reabilitação**: Fisioterapia(109), Reabilitação(115), Saúde Auditiva(116)
- **Urgência/Intensivo**: Urgência/Emergência(122), UTI(137), Terapia Intensiva(158)
- **Nefrologia**: Nefrologia(111), Diálise(157)
- **Materno-Infantil**: Saúde Reprodutiva(100), Pré-natal/Parto(101)

---

### dim_equipamento (Medical Equipment Dimension)

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `cod_equipamento` | TEXT | Código equipamento (5 dígitos) |
| `tipo_equipamento` | TEXT | Tipo equipamento |
| `desc_equipamento` | TEXT | Descrição completa |

**Fonte**: `raw_eq` (codequip, tipequip)

**Tipos de Equipamento**:
- **01 - Diagnóstico por Imagem**: Tomógrafo(10006), Ressonância(10007), Ultrassom(10008/10019), Mamógrafo(10009), PET-CT(10015)
- **02 - Infraestrutura**: Ventilador/Respirador(20012), Desfibrilador(20009)
- **03 - Métodos Ópticos**: Endoscópios, Colposcópios, Laparoscópios
- **04 - Métodos Gráficos**: ECG, EEG, Ecocardiograma
- **05 - Manutenção da Vida**: Hemodiálise(50001), CPAP/BIPAP
- **06 - Odontologia**: Equipos odontológicos
- **07 - Outros**: Acelerador Linear(70005), Autoclaves, Esterilização

---

## Fatos Criados

### fato_estabelecimento (Facility Fact)

**Granularidade**: Um registro por estabelecimento por período (ano/mês)

**Dimensões**:
- `cnes` → Estabelecimento
- `sk_tempo` → dim_tempo
- `cod_uf` → dim_uf
- `cod_tipo_unidade` → dim_tipo_unidade
- `cod_natureza` → dim_natureza_juridica

**Medidas**:
- `qtd_estabelecimentos`: Sempre 1 (para contagem)
- `vinculo_sus`: 0/1 (indicador)

**Atributos**:
- `tipo_gestao`, `esfera_administrativa`, `turno_atendimento`, `nivel_hierarquia`

---

### fato_profissional (Professional Fact)

**Granularidade**: Um registro por vínculo profissional por estabelecimento por período

**Dimensões**:
- `cnes` → Estabelecimento
- `sk_tempo` → dim_tempo
- `cod_uf` → dim_uf
- `cod_cbo` → dim_cbo
- `cns_profissional` → Profissional

**Medidas**:
- `ch_total`: Carga horária total (soma de ambulatorial + hospitalar + outros)
- `ch_hospitalar`: Carga horária hospitalar
- `ch_ambulatorial`: Carga horária ambulatorial
- `ch_outros`: Carga horária outros
- `qtd_vinculos`: Sempre 1 (para contagem)
- `vinculo_sus`: 0/1 (indicador)

**Atributos**:
- `cod_vinculo`: Tipo de vínculo empregatício

---

### fato_equipamento (Equipment Fact)

**Granularidade**: Um registro por equipamento por estabelecimento por período

**Dimensões**:
- `cnes` → Estabelecimento
- `sk_tempo` → dim_tempo
- `cod_uf` → dim_uf
- `cod_equipamento` → dim_equipamento

**Medidas**:
- `qtd_existente`: Quantidade de equipamentos existentes
- `qtd_em_uso`: Quantidade de equipamentos em uso
- `disponivel_sus`: 0/1 (indicador)

**Atributos**:
- `tipo_equipamento`: Categoria do equipamento

---

### fato_servico (Service Fact)

**Granularidade**: Um registro por serviço por estabelecimento por período

**Dimensões**:
- `cnes` → Estabelecimento
- `sk_tempo` → dim_tempo
- `cod_uf` → dim_uf
- `cod_servico` → dim_servico

**Medidas**:
- `qtd_servicos`: Sempre 1 (para contagem)
- `ambulatorial_sus`: 0/1 (indicador)
- `ambulatorial_nao_sus`: 0/1 (indicador)
- `hospitalar_sus`: 0/1 (indicador)
- `hospitalar_nao_sus`: 0/1 (indicador)

**Atributos**:
- `classificacao`: Classificação específica do serviço

---

## Views Agregadas

### vw_estabelecimentos_por_uf

Agregação de estabelecimentos por UF e período.

**Dimensões**: sigla_uf, nome_uf, regiao, ano, mes
**Medidas**:
- `qtd_estabelecimentos`: Total de estabelecimentos distintos
- `qtd_sus`: Total de estabelecimentos vinculados ao SUS

---

### vw_profissionais_por_uf

Agregação de profissionais por UF e período.

**Dimensões**: sigla_uf, nome_uf, regiao, ano, mes
**Medidas**:
- `qtd_vinculos`: Total de vínculos
- `qtd_profissionais`: Total de profissionais distintos (por CNS)
- `total_carga_horaria`: Soma de todas as cargas horárias
- `qtd_vinculos_sus`: Total de vínculos SUS

---

### vw_equipamentos_por_uf

Agregação de equipamentos por UF e período.

**Dimensões**: sigla_uf, nome_uf, regiao, ano, mes
**Medidas**:
- `total_existente`: Soma de equipamentos existentes
- `total_em_uso`: Soma de equipamentos em uso
- `total_sus`: Soma de equipamentos SUS em uso

---

### vw_servicos_por_uf

Agregação de serviços por UF e período.

**Dimensões**: sigla_uf, nome_uf, regiao, ano, mes
**Medidas**:
- `qtd_servicos`: Total de serviços
- `qtd_ambulatorial_sus`: Total de serviços ambulatoriais SUS
- `qtd_hospitalar_sus`: Total de serviços hospitalares SUS

---

## Verificação de Completude

### ✅ ST (Estabelecimentos)
- [x] Todas as colunas principais mapeadas
- [x] Dimensões criadas: dim_uf, dim_tipo_unidade, dim_natureza_juridica
- [x] Fato criado: fato_estabelecimento
- [x] View agregada: vw_estabelecimentos_por_uf
- [x] Domínios documentados (85 tipos de unidade, 13 naturezas, etc)

### ✅ PF (Profissionais)
- [x] Todas as colunas principais mapeadas
- [x] Dimensão criada: dim_cbo
- [x] Fato criado: fato_profissional
- [x] View agregada: vw_profissionais_por_uf
- [x] Domínios documentados (316 CBOs, 11 tipos vínculo)

### ✅ EQ (Equipamentos)
- [x] Todas as colunas principais mapeadas
- [x] Dimensão criada: dim_equipamento
- [x] Fato criado: fato_equipamento
- [x] View agregada: vw_equipamentos_por_uf
- [x] Domínios documentados (7 tipos, 60+ equipamentos)

### ✅ SR (Serviços)
- [x] Todas as colunas principais mapeadas
- [x] Dimensão criada: dim_servico
- [x] Fato criado: fato_servico
- [x] View agregada: vw_servicos_por_uf
- [x] Domínios documentados (50+ serviços especializados)

---

## Resumo Estatístico

| Componente | Quantidade |
|------------|-----------|
| **Arquivos Raw** | 4 (ST, PF, EQ, SR) |
| **Tabelas Raw** | 4 (raw_st, raw_pf, raw_eq, raw_sr) |
| **Dimensões** | 7 (tempo, uf, tipo_unidade, natureza_juridica, cbo, servico, equipamento) |
| **Fatos** | 4 (estabelecimento, profissional, equipamento, servico) |
| **Views Agregadas** | 4 (por UF para cada tipo) |
| **Total Views** | 15 |
| **Domínios Documentados** | 20+ tabelas de domínio |
| **Valores Codificados** | 600+ códigos decodificados |

---

## Convenções de Nomenclatura

### Arquivos Raw
- DATASUS usa maiúsculas: `CNES`, `CODUFMUN`, `TP_UNID`
- Projeto normaliza para minúsculas: `cnes`, `codufmun`, `tp_unid`

### Views
- Dimensões: prefixo `dim_`
- Fatos: prefixo `fato_`
- Agregações: prefixo `vw_`

### Campos
- Raw: preserva nomes originais DATASUS
- Views: nomes descritivos em português
- Traduções EN: fornecidas para referência internacional

### Tipos de Dados
- IDs e códigos: `TEXT` (preserva zeros à esquerda)
- Quantidades: `INTEGER` (após conversão de TEXT)
- Indicadores: `INTEGER` (0/1)
- Timestamps: automáticos no banco

---

## Fontes de Dados

- **Origem**: DATASUS (Ministério da Saúde - Brasil)
- **Biblioteca**: PySUS (https://github.com/AlertaDengue/PySUS)
- **Periodicidade**: Mensal
- **Formato Original**: .dbc (DBF comprimido)
- **Processamento**: Conversão para Parquet → Transformação → SQLite

---

## Referências

- **Base dos Dados**: https://basedosdados.org/dataset/br-ms-cnes
- **Documentação DATASUS**: ftp://ftp.datasus.gov.br/dissemin/publicos/CNES/
- **PySUS**: https://pysus.readthedocs.io/
- **Código Fonte**: /home/user/cnes/

---

**Última Atualização**: 2026-01-13
**Versão**: 1.0
**Mantenedor**: Projeto CNES Data Warehouse
