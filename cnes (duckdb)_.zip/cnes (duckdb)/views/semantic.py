"""
Views semânticas (modelo dimensional) do CNES.
Dimensões e Fatos para os 4 prefixos: ST, PF, EQ, SR.
"""
import logging
from database import get_conn, table_exists

logger = logging.getLogger(__name__)


# =============================================================================
# DEFINIÇÃO DAS VIEWS
# =============================================================================

VIEWS = {
    # =========================================================================
    # DIMENSÕES
    # =========================================================================
    
    "dim_tempo": {
        "deps": ["raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_tempo AS
            SELECT DISTINCT
                _ano_cmp * 100 + _mes_cmp AS sk_tempo,
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                CASE _mes_cmp
                    WHEN 1 THEN 'Janeiro' WHEN 2 THEN 'Fevereiro'
                    WHEN 3 THEN 'Março' WHEN 4 THEN 'Abril'
                    WHEN 5 THEN 'Maio' WHEN 6 THEN 'Junho'
                    WHEN 7 THEN 'Julho' WHEN 8 THEN 'Agosto'
                    WHEN 9 THEN 'Setembro' WHEN 10 THEN 'Outubro'
                    WHEN 11 THEN 'Novembro' WHEN 12 THEN 'Dezembro'
                END AS nome_mes,
                CASE 
                    WHEN _mes_cmp <= 3 THEN 1
                    WHEN _mes_cmp <= 6 THEN 2
                    WHEN _mes_cmp <= 9 THEN 3
                    ELSE 4
                END AS trimestre,
                CASE WHEN _mes_cmp <= 6 THEN 1 ELSE 2 END AS semestre
            FROM raw_st
        """
    },
    
    "dim_uf": {
        "deps": ["raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_uf AS
            SELECT DISTINCT
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                CASE SUBSTR(codufmun, 1, 2)
                    WHEN '11' THEN 'RO' WHEN '12' THEN 'AC' WHEN '13' THEN 'AM'
                    WHEN '14' THEN 'RR' WHEN '15' THEN 'PA' WHEN '16' THEN 'AP'
                    WHEN '17' THEN 'TO' WHEN '21' THEN 'MA' WHEN '22' THEN 'PI'
                    WHEN '23' THEN 'CE' WHEN '24' THEN 'RN' WHEN '25' THEN 'PB'
                    WHEN '26' THEN 'PE' WHEN '27' THEN 'AL' WHEN '28' THEN 'SE'
                    WHEN '29' THEN 'BA' WHEN '31' THEN 'MG' WHEN '32' THEN 'ES'
                    WHEN '33' THEN 'RJ' WHEN '35' THEN 'SP' WHEN '41' THEN 'PR'
                    WHEN '42' THEN 'SC' WHEN '43' THEN 'RS' WHEN '50' THEN 'MS'
                    WHEN '51' THEN 'MT' WHEN '52' THEN 'GO' WHEN '53' THEN 'DF'
                    ELSE 'XX'
                END AS sigla_uf,
                CASE SUBSTR(codufmun, 1, 2)
                    WHEN '11' THEN 'Rondônia' WHEN '12' THEN 'Acre' 
                    WHEN '13' THEN 'Amazonas' WHEN '14' THEN 'Roraima'
                    WHEN '15' THEN 'Pará' WHEN '16' THEN 'Amapá'
                    WHEN '17' THEN 'Tocantins' WHEN '21' THEN 'Maranhão'
                    WHEN '22' THEN 'Piauí' WHEN '23' THEN 'Ceará'
                    WHEN '24' THEN 'Rio Grande do Norte' WHEN '25' THEN 'Paraíba'
                    WHEN '26' THEN 'Pernambuco' WHEN '27' THEN 'Alagoas'
                    WHEN '28' THEN 'Sergipe' WHEN '29' THEN 'Bahia'
                    WHEN '31' THEN 'Minas Gerais' WHEN '32' THEN 'Espírito Santo'
                    WHEN '33' THEN 'Rio de Janeiro' WHEN '35' THEN 'São Paulo'
                    WHEN '41' THEN 'Paraná' WHEN '42' THEN 'Santa Catarina'
                    WHEN '43' THEN 'Rio Grande do Sul' WHEN '50' THEN 'Mato Grosso do Sul'
                    WHEN '51' THEN 'Mato Grosso' WHEN '52' THEN 'Goiás'
                    WHEN '53' THEN 'Distrito Federal'
                    ELSE 'Desconhecido'
                END AS nome_uf,
                CASE 
                    WHEN SUBSTR(codufmun, 1, 2) IN ('11','12','13','14','15','16','17') THEN 'Norte'
                    WHEN SUBSTR(codufmun, 1, 2) IN ('21','22','23','24','25','26','27','28','29') THEN 'Nordeste'
                    WHEN SUBSTR(codufmun, 1, 2) IN ('31','32','33','35') THEN 'Sudeste'
                    WHEN SUBSTR(codufmun, 1, 2) IN ('41','42','43') THEN 'Sul'
                    WHEN SUBSTR(codufmun, 1, 2) IN ('50','51','52','53') THEN 'Centro-Oeste'
                    ELSE 'Desconhecida'
                END AS regiao
            FROM raw_st
            WHERE codufmun IS NOT NULL
        """
    },
    
    "dim_tipo_unidade": {
        "deps": ["raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_tipo_unidade AS
            SELECT DISTINCT
                tp_unid AS cod_tipo_unidade,
                CASE tp_unid
                    WHEN '01' THEN 'Posto de Saúde'
                    WHEN '02' THEN 'Centro de Saúde/Unidade Básica'
                    WHEN '04' THEN 'Policlínica'
                    WHEN '05' THEN 'Hospital Geral'
                    WHEN '07' THEN 'Hospital Especializado'
                    WHEN '15' THEN 'Unidade Mista'
                    WHEN '20' THEN 'Pronto Socorro Geral'
                    WHEN '21' THEN 'Pronto Socorro Especializado'
                    WHEN '22' THEN 'Consultório Isolado'
                    WHEN '36' THEN 'Clínica/Centro de Especialidade'
                    WHEN '39' THEN 'Unidade de Apoio Diagnose e Terapia'
                    WHEN '40' THEN 'Unidade Móvel Terrestre'
                    WHEN '42' THEN 'Unidade Móvel Pré-Hospitalar Urgência'
                    WHEN '43' THEN 'Farmácia'
                    WHEN '61' THEN 'Centro de Parto Normal'
                    WHEN '62' THEN 'Hospital/Dia'
                    WHEN '69' THEN 'Centro Hemoterapia/Hematológica'
                    WHEN '70' THEN 'Centro de Atenção Psicossocial'
                    WHEN '71' THEN 'Centro de Apoio à Saúde da Família'
                    WHEN '72' THEN 'Unidade de Atenção à Saúde Indígena'
                    WHEN '73' THEN 'Pronto Atendimento'
                    WHEN '74' THEN 'Polo Academia da Saúde'
                    WHEN '77' THEN 'Home Care'
                    WHEN '80' THEN 'Laboratório de Saúde Pública'
                    ELSE 'Outros (cód: ' || tp_unid || ')'
                END AS desc_tipo_unidade,
                CASE 
                    WHEN tp_unid IN ('01','02','71','74') THEN 'Atenção Básica'
                    WHEN tp_unid IN ('05','07','15','61','62') THEN 'Hospitalar'
                    WHEN tp_unid IN ('20','21','42','73') THEN 'Urgência/Emergência'
                    WHEN tp_unid IN ('04','22','36','39') THEN 'Ambulatorial'
                    WHEN tp_unid IN ('69','70','77','80') THEN 'Especializado'
                    ELSE 'Outros'
                END AS categoria
            FROM raw_st
            WHERE tp_unid IS NOT NULL
        """
    },
    
    "dim_natureza_juridica": {
        "deps": ["raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_natureza_juridica AS
            SELECT DISTINCT
                nat_jur AS cod_natureza,
                CASE nat_jur
                    WHEN '1015' THEN 'Órgão Público do Poder Executivo Federal'
                    WHEN '1023' THEN 'Órgão Público do Poder Executivo Estadual'
                    WHEN '1031' THEN 'Órgão Público do Poder Executivo Municipal'
                    WHEN '1040' THEN 'Órgão Público do Poder Legislativo'
                    WHEN '1058' THEN 'Órgão Público do Poder Judiciário'
                    WHEN '1066' THEN 'Autarquia Federal'
                    WHEN '1074' THEN 'Autarquia Estadual'
                    WHEN '1082' THEN 'Autarquia Municipal'
                    WHEN '1104' THEN 'Fundação Pública Federal'
                    WHEN '1112' THEN 'Fundação Pública Estadual'
                    WHEN '1120' THEN 'Fundação Pública Municipal'
                    WHEN '2011' THEN 'Empresa Pública'
                    WHEN '2038' THEN 'Sociedade de Economia Mista'
                    WHEN '2046' THEN 'Sociedade Anônima Aberta'
                    WHEN '2054' THEN 'Sociedade Anônima Fechada'
                    WHEN '2062' THEN 'Sociedade Empresária Limitada'
                    WHEN '2135' THEN 'Sociedade Empresária em Comandita Simples'
                    WHEN '2232' THEN 'Sociedade Simples Limitada'
                    WHEN '2240' THEN 'Sociedade Simples Pura'
                    WHEN '3069' THEN 'Fundação Privada'
                    WHEN '3077' THEN 'Serviço Social Autônomo'
                    WHEN '3085' THEN 'Condomínio Edilício'
                    WHEN '3999' THEN 'Associação Privada'
                    WHEN '4014' THEN 'Empresa Individual'
                    WHEN '4022' THEN 'Empresa Individual de Responsabilidade Limitada'
                    WHEN '4081' THEN 'Consórcio Simples'
                    WHEN '5001' THEN 'Organização Internacional'
                    WHEN '5002' THEN 'Representação Estrangeira'
                    ELSE 'Outras (' || nat_jur || ')'
                END AS desc_natureza,
                CASE
                    WHEN nat_jur LIKE '1%' THEN 'Público'
                    WHEN nat_jur IN ('2011','2038') THEN 'Público'
                    WHEN nat_jur LIKE '2%' THEN 'Privado'
                    WHEN nat_jur IN ('3077') THEN 'Serviço Social Autônomo'
                    WHEN nat_jur LIKE '3%' THEN 'Privado sem fins lucrativos'
                    WHEN nat_jur LIKE '4%' THEN 'Privado'
                    ELSE 'Outros'
                END AS setor
            FROM raw_st
            WHERE nat_jur IS NOT NULL AND nat_jur != ''
        """
    },
    
    "dim_cbo": {
        "deps": ["raw_pf"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_cbo AS
            SELECT DISTINCT
                cbo AS cod_cbo,
                CASE 
                    WHEN cbo LIKE '2231%' THEN 'Médico'
                    WHEN cbo LIKE '2251%' THEN 'Médico'
                    WHEN cbo LIKE '2252%' THEN 'Médico'
                    WHEN cbo LIKE '2253%' THEN 'Médico'
                    WHEN cbo LIKE '2235%' THEN 'Enfermeiro'
                    WHEN cbo LIKE '3222%' THEN 'Técnico/Auxiliar Enfermagem'
                    WHEN cbo LIKE '2232%' THEN 'Cirurgião Dentista'
                    WHEN cbo LIKE '3224%' THEN 'Técnico Saúde Bucal'
                    WHEN cbo LIKE '2234%' THEN 'Farmacêutico'
                    WHEN cbo LIKE '2236%' THEN 'Fisioterapeuta'
                    WHEN cbo LIKE '2237%' THEN 'Nutricionista'
                    WHEN cbo LIKE '2238%' THEN 'Fonoaudiólogo'
                    WHEN cbo LIKE '2239%' THEN 'Terapeuta Ocupacional'
                    WHEN cbo LIKE '2515%' THEN 'Psicólogo'
                    WHEN cbo LIKE '2516%' THEN 'Assistente Social'
                    WHEN cbo LIKE '5151%' THEN 'Agente Comunitário de Saúde'
                    WHEN cbo LIKE '3241%' THEN 'Técnico em Radiologia'
                    WHEN cbo LIKE '3242%' THEN 'Técnico em Patologia Clínica'
                    ELSE 'Outros'
                END AS categoria_profissional,
                CASE 
                    WHEN cbo LIKE '2%' THEN 'Superior'
                    WHEN cbo LIKE '3%' THEN 'Técnico'
                    WHEN cbo LIKE '5%' THEN 'Elementar'
                    ELSE 'Outros'
                END AS nivel_formacao
            FROM raw_pf
            WHERE cbo IS NOT NULL AND cbo != ''
        """
    },
    
    "dim_servico": {
        "deps": ["raw_sr"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_servico AS
            SELECT DISTINCT
                serv_esp AS cod_servico,
                CASE serv_esp
                    WHEN '100' THEN 'Atenção à Saúde Reprodutiva'
                    WHEN '101' THEN 'Pré-natal, Parto e Nascimento'
                    WHEN '102' THEN 'Atenção ao Paciente com Tuberculose'
                    WHEN '103' THEN 'Atenção em Hanseníase'
                    WHEN '105' THEN 'Diagnóstico por Imagem'
                    WHEN '106' THEN 'Laboratório Clínico'
                    WHEN '107' THEN 'Endoscopia'
                    WHEN '108' THEN 'Farmácia'
                    WHEN '109' THEN 'Fisioterapia'
                    WHEN '110' THEN 'Hemoterapia'
                    WHEN '111' THEN 'Nefrologia'
                    WHEN '112' THEN 'Oncologia'
                    WHEN '114' THEN 'Práticas Integrativas'
                    WHEN '115' THEN 'Reabilitação'
                    WHEN '116' THEN 'Saúde Auditiva'
                    WHEN '117' THEN 'Saúde Bucal'
                    WHEN '119' THEN 'Saúde Mental'
                    WHEN '121' THEN 'Transplante'
                    WHEN '122' THEN 'Urgência e Emergência'
                    WHEN '124' THEN 'DST/HIV/AIDS'
                    WHEN '126' THEN 'Cardiovascular/Cardiologia'
                    WHEN '127' THEN 'Atenção Domiciliar'
                    WHEN '132' THEN 'Traumato-Ortopedia'
                    WHEN '133' THEN 'Oftalmologia'
                    WHEN '134' THEN 'Medicina Nuclear'
                    WHEN '135' THEN 'Radioterapia'
                    WHEN '136' THEN 'Quimioterapia'
                    WHEN '137' THEN 'UTI'
                    WHEN '157' THEN 'Diálise'
                    WHEN '158' THEN 'Terapia Intensiva'
                    ELSE 'Outros (cód: ' || serv_esp || ')'
                END AS desc_servico,
                CASE 
                    WHEN serv_esp IN ('105','106','107','134') THEN 'Diagnóstico'
                    WHEN serv_esp IN ('112','135','136') THEN 'Oncologia'
                    WHEN serv_esp IN ('109','115','116') THEN 'Reabilitação'
                    WHEN serv_esp IN ('122','137','158') THEN 'Urgência/Intensivo'
                    WHEN serv_esp IN ('111','157') THEN 'Nefrologia'
                    WHEN serv_esp IN ('100','101') THEN 'Materno-Infantil'
                    ELSE 'Outros'
                END AS grupo_servico
            FROM raw_sr
            WHERE serv_esp IS NOT NULL
        """
    },
    
    "dim_equipamento": {
        "deps": ["raw_eq"],
        "sql": """
            CREATE VIEW IF NOT EXISTS dim_equipamento AS
            SELECT DISTINCT
                codequip AS cod_equipamento,
                CASE tipequip
                    WHEN '01' THEN 'Diagnóstico por Imagem'
                    WHEN '02' THEN 'Infraestrutura'
                    WHEN '03' THEN 'Métodos Ópticos'
                    WHEN '04' THEN 'Métodos Gráficos'
                    WHEN '05' THEN 'Manutenção da Vida'
                    WHEN '06' THEN 'Odontologia'
                    WHEN '07' THEN 'Outros'
                    ELSE 'Não classificado'
                END AS tipo_equipamento,
                CASE codequip
                    WHEN '10006' THEN 'Tomógrafo Computadorizado'
                    WHEN '10007' THEN 'Ressonância Magnética'
                    WHEN '10008' THEN 'Ultrassom Doppler Colorido'
                    WHEN '10009' THEN 'Mamógrafo'
                    WHEN '10015' THEN 'PET-CT'
                    WHEN '10019' THEN 'Ultrassom Ecógrafo'
                    WHEN '20012' THEN 'Ventilador/Respirador'
                    WHEN '20009' THEN 'Desfibrilador'
                    WHEN '50001' THEN 'Equipamento de Hemodiálise'
                    WHEN '70005' THEN 'Acelerador Linear'
                    ELSE 'Equipamento ' || codequip
                END AS desc_equipamento
            FROM raw_eq
            WHERE codequip IS NOT NULL
        """
    },
    
    # =========================================================================
    # FATOS
    # =========================================================================
    
    "fato_estabelecimento": {
        "deps": ["raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS fato_estabelecimento AS
            SELECT
                cnes,
                codufmun AS cod_municipio,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                _ano_cmp * 100 + _mes_cmp AS sk_tempo,
                tp_unid AS cod_tipo_unidade,
                natureza AS cod_natureza,
                tpgestao AS tipo_gestao,
                CASE WHEN vinc_sus = '1' THEN 1 ELSE 0 END AS vinculo_sus,
                esfera_a AS esfera_administrativa,
                turno_at AS turno_atendimento,
                niv_hier AS nivel_hierarquia,
                cpf_cnpj,
                cnpj_man,
                cod_cep,
                niv_dep AS nivel_dependencia,
                pf_pj AS tipo_pessoa,
                clientel AS fluxo_clientela,
                tp_prest AS tipo_prestador,
                retencao AS retencao_tributos,
                cod_ir AS codigo_ir,
                atividad AS atividade_ensino,
                1 AS qtd_estabelecimentos,
                _ano_cmp,
                _mes_cmp,
                _data_carga
            FROM raw_st
            WHERE cnes IS NOT NULL
        """
    },
    
    "fato_profissional": {
        "deps": ["raw_pf"],
        "sql": """
            CREATE VIEW IF NOT EXISTS fato_profissional AS
            SELECT
                cnes,
                codufmun AS cod_municipio,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                _ano_cmp * 100 + _mes_cmp AS sk_tempo,
                cbo AS cod_cbo,
                cns_prof AS cns_profissional,
                cpf_prof AS cpf_profissional,
                vinculac AS cod_vinculo,
                CASE WHEN prof_sus = '1' THEN 1 ELSE 0 END AS vinculo_sus,
                registro AS registro_profissional,
                COALESCE(CAST(horaoutr AS INTEGER), 0) AS ch_outros,
                COALESCE(CAST(horahosp AS INTEGER), 0) AS ch_hospitalar,
                COALESCE(CAST(hora_amb AS INTEGER), 0) AS ch_ambulatorial,
                COALESCE(CAST(horaoutr AS INTEGER), 0) +
                    COALESCE(CAST(horahosp AS INTEGER), 0) +
                    COALESCE(CAST(hora_amb AS INTEGER), 0) AS ch_total,
                1 AS qtd_vinculos,
                _ano_cmp,
                _mes_cmp,
                _data_carga
            FROM raw_pf
            WHERE cnes IS NOT NULL
        """
    },
    
    "fato_equipamento": {
        "deps": ["raw_eq"],
        "sql": """
            CREATE VIEW IF NOT EXISTS fato_equipamento AS
            SELECT
                cnes,
                codufmun AS cod_municipio,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                _ano_cmp * 100 + _mes_cmp AS sk_tempo,
                codequip AS cod_equipamento,
                tipequip AS tipo_equipamento,
                COALESCE(CAST(qt_exist AS INTEGER), 0) AS qtd_existente,
                COALESCE(CAST(qt_uso AS INTEGER), 0) AS qtd_em_uso,
                CASE WHEN ind_sus = '1' THEN 1 ELSE 0 END AS disponivel_sus,
                _ano_cmp,
                _mes_cmp,
                _data_carga
            FROM raw_eq
            WHERE cnes IS NOT NULL
        """
    },
    
    "fato_servico": {
        "deps": ["raw_sr"],
        "sql": """
            CREATE VIEW IF NOT EXISTS fato_servico AS
            SELECT
                cnes,
                codufmun AS cod_municipio,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                _ano_cmp * 100 + _mes_cmp AS sk_tempo,
                serv_esp AS cod_servico,
                class_sr AS classificacao,
                caracter AS caracteristica_servico,
                CASE WHEN COALESCE(amb_sus, '0') != '0' THEN 1 ELSE 0 END AS ambulatorial_sus,
                CASE WHEN COALESCE(amb_nsus, '0') != '0' THEN 1 ELSE 0 END AS ambulatorial_nao_sus,
                CASE WHEN COALESCE(hosp_sus, '0') != '0' THEN 1 ELSE 0 END AS hospitalar_sus,
                CASE WHEN COALESCE(hosp_nsus, '0') != '0' THEN 1 ELSE 0 END AS hospitalar_nao_sus,
                1 AS qtd_servicos,
                _ano_cmp,
                _mes_cmp,
                _data_carga
            FROM raw_sr
            WHERE cnes IS NOT NULL
        """
    },
    
    # =========================================================================
    # VIEWS AGREGADAS
    # =========================================================================
    
    "vw_estabelecimentos_por_uf": {
        "deps": ["raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS vw_estabelecimentos_por_uf AS
            SELECT
                u.sigla_uf,
                u.nome_uf,
                u.regiao,
                f._ano_cmp AS ano,
                f._mes_cmp AS mes,
                COUNT(DISTINCT f.cnes) AS qtd_estabelecimentos,
                SUM(CASE WHEN f.vinculo_sus = 1 THEN 1 ELSE 0 END) AS qtd_sus
            FROM fato_estabelecimento f
            JOIN dim_uf u ON f.cod_uf = u.cod_uf
            GROUP BY u.sigla_uf, u.nome_uf, u.regiao, f._ano_cmp, f._mes_cmp
        """
    },
    
    "vw_profissionais_por_uf": {
        "deps": ["raw_pf", "raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS vw_profissionais_por_uf AS
            SELECT
                u.sigla_uf,
                u.nome_uf,
                u.regiao,
                f._ano_cmp AS ano,
                f._mes_cmp AS mes,
                COUNT(*) AS qtd_vinculos,
                COUNT(DISTINCT f.cns_profissional) AS qtd_profissionais,
                SUM(f.ch_total) AS total_carga_horaria,
                SUM(CASE WHEN f.vinculo_sus = 1 THEN 1 ELSE 0 END) AS qtd_vinculos_sus
            FROM fato_profissional f
            JOIN dim_uf u ON f.cod_uf = u.cod_uf
            GROUP BY u.sigla_uf, u.nome_uf, u.regiao, f._ano_cmp, f._mes_cmp
        """
    },
    
    "vw_equipamentos_por_uf": {
        "deps": ["raw_eq", "raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS vw_equipamentos_por_uf AS
            SELECT
                u.sigla_uf,
                u.nome_uf,
                u.regiao,
                f._ano_cmp AS ano,
                f._mes_cmp AS mes,
                SUM(f.qtd_existente) AS total_existente,
                SUM(f.qtd_em_uso) AS total_em_uso,
                SUM(CASE WHEN f.disponivel_sus = 1 THEN f.qtd_em_uso ELSE 0 END) AS total_sus
            FROM fato_equipamento f
            JOIN dim_uf u ON f.cod_uf = u.cod_uf
            GROUP BY u.sigla_uf, u.nome_uf, u.regiao, f._ano_cmp, f._mes_cmp
        """
    },
    
    "vw_servicos_por_uf": {
        "deps": ["raw_sr", "raw_st"],
        "sql": """
            CREATE VIEW IF NOT EXISTS vw_servicos_por_uf AS
            SELECT
                u.sigla_uf,
                u.nome_uf,
                u.regiao,
                f._ano_cmp AS ano,
                f._mes_cmp AS mes,
                COUNT(*) AS qtd_servicos,
                SUM(f.ambulatorial_sus) AS qtd_ambulatorial_sus,
                SUM(f.hospitalar_sus) AS qtd_hospitalar_sus
            FROM fato_servico f
            JOIN dim_uf u ON f.cod_uf = u.cod_uf
            GROUP BY u.sigla_uf, u.nome_uf, u.regiao, f._ano_cmp, f._mes_cmp
        """
    },
}


# =============================================================================
# FUNÇÕES
# =============================================================================

def criar_views():
    """Cria todas as views cujas dependências existem."""
    criadas = []
    puladas = []
    erros = []

    with get_conn() as conn:
        for nome, config in VIEWS.items():
            deps = config["deps"]
            sql = config["sql"]

            # Verifica se todas as dependências existem
            deps_faltando = [t for t in deps if not table_exists(t)]
            if deps_faltando:
                puladas.append((nome, deps_faltando))
                logger.debug(f"Pulando {nome}: dependências não encontradas ({deps_faltando})")
                continue

            try:
                conn.execute(f"DROP VIEW IF EXISTS {nome}")
                conn.execute(sql)
                criadas.append(nome)
                logger.info(f"View criada: {nome}")
            except Exception as e:
                erros.append((nome, str(e)))
                logger.error(f"Erro ao criar view {nome}: {e}")

        conn.commit()

    # Resumo
    logger.info(f"Resumo de views: {len(criadas)} criadas, {len(puladas)} puladas, {len(erros)} com erro")

    if puladas:
        logger.warning(f"Views puladas por falta de dependências:")
        for nome, deps_faltando in puladas:
            logger.warning(f"  • {nome}: faltam {deps_faltando}")

    if erros:
        logger.error(f"Views com erro:")
        for nome, erro in erros:
            logger.error(f"  • {nome}: {erro}")

    return len(criadas)


def listar_views() -> list[str]:
    """Lista views criadas no banco."""
    with get_conn() as conn:
        result = conn.execute("""
            SELECT table_name FROM information_schema.tables
            WHERE table_type='VIEW' ORDER BY table_name
        """).fetchall()
        return [r[0] for r in result]
