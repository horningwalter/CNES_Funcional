from .semantic import criar_views, listar_views, VIEWS
