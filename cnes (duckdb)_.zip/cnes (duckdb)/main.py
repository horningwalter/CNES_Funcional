#!/usr/bin/env python3
"""
Pipeline ETL para dados do CNES (Cadastro Nacional de Estabelecimentos de Saúde).

Extrai dados mensais do DATASUS, transforma e carrega em banco SQLite.
"""
import sys
import logging
import argparse
from pathlib import Path

# Adiciona diretório atual ao path para imports locais
sys.path.insert(0, str(Path(__file__).parent))

from config import PREFIXOS, PREFIXO_DESCRICAO, DB_PATH, UFS
from extracao import download_cnes, get_previous_month
from transformacao import transform
from database import init_db, ja_processado, mes_completo, registrar_inicio, registrar_fim, salvar_df
from views import criar_views

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def run(ano=None, mes=None, prefixos=None, ufs=None, force=False):
    """
    Executa pipeline ETL dos dados CNES.
    
    Args:
        ano: Ano de referência (default: ano do mês anterior)
        mes: Mês de referência (default: mês anterior)
        prefixos: Lista de prefixos CNES a processar (default: todos do settings.py)
        ufs: Lista de UFs para filtrar (default: todas)
        force: Se True, reprocessa mesmo se já existir no banco de dados
    """
    # Usa mês anterior se não especificado
    if not ano or not mes:
        ano, mes = get_previous_month()
    
    # Usa todos os prefixos se não especificado
    prefixos = prefixos or PREFIXOS
    
    # Inicializa banco de dados
    init_db()

    # Verifica se mês já foi completamente processado (todos os prefixos)
    if not force and mes_completo(ano, mes, prefixos):
        logger.info(f"Mês {mes:02d}/{ano} já processado.")
        return

    # Processa cada prefixo (tipo de arquivo CNES)
    for pref in prefixos:
        # Pula se já processado e não for force
        if not force and ja_processado(ano, mes, pref):
            continue
        
        # Registra início da execução para auditoria
        exec_id = registrar_inicio(ano, mes, pref)
        
        try:
            logger.info(f"Processando {pref} ({mes:02d}/{ano})...")

            # Extração: baixa arquivos do DATASUS
            downloads = download_cnes(ano, mes, [pref], ufs)

            # Verifica se houve download
            if pref not in downloads or not downloads[pref]:
                logger.warning(f"{pref}: Nenhum dado disponível para download")
                registrar_fim(exec_id, 0, 'SEM_DADOS')
                continue

            # Transformação: limpa e padroniza dados
            df = transform(pref, downloads[pref])

            # Verifica se há dados após transformação
            if df.is_empty():
                logger.warning(f"{pref}: DataFrame vazio após transformação")
                registrar_fim(exec_id, 0, 'SEM_DADOS')
                continue

            logger.info(f"{pref}: {len(df)} registros a serem salvos")

            # Carga: salva no banco de dados
            qtd = salvar_df(df, f"raw_{pref.lower()}", ano, mes)

            # Verifica se a quantidade salva corresponde aos dados processados
            if qtd != len(df):
                logger.error(f"{pref}: Inconsistência de dados - processados {len(df)}, salvos {qtd}")
                registrar_fim(exec_id, qtd, 'ERRO')
            else:
                registrar_fim(exec_id, qtd, 'SUCESSO')
                logger.info(f"{pref}: {qtd} registros processados e salvos com sucesso")

        except Exception as e:
            logger.error(f"Erro em {pref}: {e}", exc_info=True)
            registrar_fim(exec_id, 0, 'ERRO')

    # Cria/atualiza views de consulta
    criar_views()

if __name__ == "__main__":
    # Configura argumentos da linha de comando
    parser = argparse.ArgumentParser(description='LINC - Pipeline CNES')
    parser.add_argument('--ano', type=int, help='Ano de referência (YY)')
    parser.add_argument('--mes', type=int, help='Mês de referência (MM)')
    parser.add_argument('--prefixos', nargs='+', choices=PREFIXOS, 
                       help='Prefixos a processar (ex: ST SR EQ)')
    parser.add_argument('--uf', nargs='+', choices=UFS,
                       help='UFs para filtrar (ex: PR SP RJ)')
    parser.add_argument('--force', action='store_true',
                       help='Reprocessa mesmo se já existir no banco de dados')
    args = parser.parse_args()
    
    # Normaliza UFs para uppercase
    ufs = [u.upper() for u in args.uf] if args.uf else None
    
    # Executa pipeline
    run(args.ano, args.mes, args.prefixos, ufs, args.force)