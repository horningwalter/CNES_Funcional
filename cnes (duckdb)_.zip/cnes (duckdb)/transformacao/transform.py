"""
Módulo de transformação de dados do CNES usando Polars.
Polars é ~10-100x mais rápido que Pandas para grandes volumes de dados.
"""
import logging
import polars as pl
from pathlib import Path

logger = logging.getLogger(__name__)

# Colunas que devem ser tratadas como string para cada prefixo
COLS_STR = {
    "ST": ['cnes', 'codufmun', 'cpf_cnpj', 'cnpj_man', 'cod_cep', 'tp_unid', 'tpgestao',
           'esfera_a', 'natureza', 'niv_hier', 'turno_at', 'niv_dep', 'pf_pj', 'clientel',
           'tp_prest', 'retencao', 'cod_ir', 'atividad', 'nat_jur'],
    "PF": ['cnes', 'codufmun', 'cpf_prof', 'cns_prof', 'cbo', 'vinculac', 'vinculus', 'registro'],
    "EQ": ['cnes', 'codufmun', 'codequip', 'tipequip', 'ind_sus'],
    "SR": ['cnes', 'codufmun', 'serv_esp', 'class_sr', 'session', 'catefle', 'amb_sus',
           'amb_nsus', 'hosp_sus', 'hosp_nsus']
}

def transform(prefixo: str, data) -> pl.DataFrame:
    """
    Pipeline de transformação que aceita ParquetSet ou Polars DataFrame.
    Retorna sempre um Polars DataFrame para máxima performance.

    IMPORTANTE: Lê Parquet diretamente com Polars para evitar gargalo de memória!
    """
    try:
        # Detecta tipo de dado e converte para Polars
        if isinstance(data, pl.DataFrame):
            df = data

        elif hasattr(data, 'path'):
            # PySUS ParquetSet - LÊ DIRETAMENTE COM POLARS (não passa por Pandas!)
            logger.info(f"Detectado ParquetSet do PySUS")

            # Obtém o caminho (pode ser diretório ou arquivo)
            path_obj = Path(data.path)

            if not path_obj.exists():
                logger.error(f"Caminho não existe: {path_obj}")
                return pl.DataFrame()

            # Coleta todos os arquivos Parquet
            parquet_files = []

            if path_obj.is_dir():
                # Se for diretório, lista todos os .parquet
                parquet_files = list(path_obj.glob("*.parquet"))
                logger.info(f"Encontrados {len(parquet_files)} arquivos Parquet no diretório")
            elif path_obj.is_file() and path_obj.suffix == '.parquet':
                # Se for arquivo único
                parquet_files = [path_obj]
                logger.info(f"Arquivo Parquet único: {path_obj.name}")
            else:
                logger.error(f"Caminho inválido: {path_obj}")
                return pl.DataFrame()

            if not parquet_files:
                logger.warning(f"Nenhum arquivo Parquet encontrado em {path_obj}")
                return pl.DataFrame()

            # Lê todos os arquivos Parquet com Polars (MUITO mais eficiente que Pandas!)
            # Polars suporta lista de arquivos e lê todos de uma vez
            logger.info(f"Lendo {len(parquet_files)} arquivos Parquet: {[p.name for p in parquet_files]}")
            df = pl.read_parquet(parquet_files)

            logger.info(f"DataFrame carregado: {len(df):,} linhas, {len(df.columns)} colunas")

        else:
            # Tipo de dado não reconhecido
            logger.error(f"Tipo de dado não suportado para {prefixo}: {type(data)}")
            logger.error(f"Atributos disponíveis: {dir(data)}")
            return pl.DataFrame()

        if df.is_empty():
            return pl.DataFrame()

        # Normaliza colunas para lowercase
        df = df.rename({col: col.lower().strip() for col in df.columns})

        # Converte colunas específicas para string e remove espaços
        cols_to_convert = COLS_STR.get(prefixo, [])
        cast_expressions = []

        for col in cols_to_convert:
            if col in df.columns:
                cast_expressions.append(
                    pl.col(col).cast(pl.Utf8).str.strip_chars().alias(col)
                )

        # Mantém colunas que não foram convertidas
        other_cols = [pl.col(c) for c in df.columns if c not in cols_to_convert]

        if cast_expressions:
            df = df.select(other_cols + cast_expressions)

        return df

    except Exception as e:
        logger.error(f"Erro na transformação de {prefixo}: {e}", exc_info=True)
        return pl.DataFrame()
