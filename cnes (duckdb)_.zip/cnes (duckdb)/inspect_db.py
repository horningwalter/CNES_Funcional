#!/usr/bin/env python3
"""Script para verificar dados no banco DuckDB."""
import duckdb
from pathlib import Path

# Conecta ao banco
DB_PATH = Path("data/cnes.db")

if not DB_PATH.exists():
    print(f"❌ Banco não encontrado: {DB_PATH}")
    exit(1)

print("=" * 70)
print(f"📊 INSPEÇÃO DO BANCO: {DB_PATH}")
print("=" * 70)
print()

conn = duckdb.connect(str(DB_PATH), read_only=True)

# 1. Lista todas as tabelas
print("📋 TABELAS RAW:")
print("-" * 70)
tables = conn.execute("""
    SELECT table_name, 
           (SELECT COUNT(*) FROM information_schema.tables t2 
            WHERE t2.table_name = t.table_name) as count
    FROM information_schema.tables t
    WHERE table_schema = 'main' 
      AND table_type = 'BASE TABLE'
      AND table_name LIKE 'raw_%'
    ORDER BY table_name
""").fetchall()

for table, _ in tables:
    count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    print(f"  • {table:15s} → {count:>10,} registros")

print()

# 2. Lista todas as views
print("👁️  VIEWS SEMÂNTICAS:")
print("-" * 70)
views = conn.execute("""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'main' 
      AND table_type = 'VIEW'
    ORDER BY table_name
""").fetchall()

for view, in views:
    try:
        count = conn.execute(f"SELECT COUNT(*) FROM {view}").fetchone()[0]
        print(f"  • {view:30s} → {count:>10,} registros")
    except:
        print(f"  • {view:30s} → ❌ Erro ao contar")

print()

# 3. Mostra amostra de dados de cada tabela raw
print("🔍 AMOSTRAS DE DADOS (primeiras 3 linhas):")
print("=" * 70)

for table, _ in tables:
    print(f"\n📌 {table.upper()}")
    print("-" * 70)
    
    # Pega colunas
    cols = conn.execute(f"PRAGMA table_info({table})").fetchall()
    col_names = [col[1] for col in cols[:10]]  # Primeiras 10 colunas
    
    # Pega dados
    query = f"SELECT {', '.join(col_names)} FROM {table} LIMIT 3"
    rows = conn.execute(query).fetchall()
    
    # Mostra
    if rows:
        for row in rows:
            for col, val in zip(col_names, row):
                print(f"  {col:15s}: {val}")
            print()
    else:
        print("  (vazio)")
    print()

# 4. Análises rápidas
print("=" * 70)
print("📊 ANÁLISES RÁPIDAS")
print("=" * 70)
print()

# Estabelecimentos por UF
print("🏥 Estabelecimentos por UF (top 5):")
try:
    result = conn.execute("""
        SELECT uf, COUNT(*) as total
        FROM raw_st
        GROUP BY uf
        ORDER BY total DESC
        LIMIT 5
    """).fetchall()
    for uf, total in result:
        print(f"  {uf}: {total:,} estabelecimentos")
except Exception as e:
    print(f"  ❌ Erro: {e}")

print()

# Profissionais por CBO (top 5)
print("👨‍⚕️ Profissionais por CBO (top 5):")
try:
    result = conn.execute("""
        SELECT cbo, COUNT(*) as total
        FROM raw_pf
        WHERE cbo IS NOT NULL
        GROUP BY cbo
        ORDER BY total DESC
        LIMIT 5
    """).fetchall()
    for cbo, total in result:
        print(f"  CBO {cbo}: {total:,} profissionais")
except Exception as e:
    print(f"  ❌ Erro: {e}")

print()

# Equipamentos por tipo (top 5)
print("🔧 Equipamentos por tipo (top 5):")
try:
    result = conn.execute("""
        SELECT tipequip, COUNT(*) as total
        FROM raw_eq
        WHERE tipequip IS NOT NULL
        GROUP BY tipequip
        ORDER BY total DESC
        LIMIT 5
    """).fetchall()
    for tipo, total in result:
        print(f"  Tipo {tipo}: {total:,} equipamentos")
except Exception as e:
    print(f"  ❌ Erro: {e}")

print()

# 5. Estatísticas gerais
print("=" * 70)
print("📈 ESTATÍSTICAS GERAIS")
print("=" * 70)
print()

total_estabelecimentos = conn.execute("SELECT COUNT(*) FROM raw_st").fetchone()[0]
total_profissionais = conn.execute("SELECT COUNT(*) FROM raw_pf").fetchone()[0]
total_equipamentos = conn.execute("SELECT COUNT(*) FROM raw_eq").fetchone()[0]
total_servicos = conn.execute("SELECT COUNT(*) FROM raw_sr").fetchone()[0]

print(f"  🏥 Estabelecimentos: {total_estabelecimentos:,}")
print(f"  👨‍⚕️ Profissionais:    {total_profissionais:,}")
print(f"  🔧 Equipamentos:     {total_equipamentos:,}")
print(f"  📋 Serviços:         {total_servicos:,}")

print()

# 6. Consulta personalizada (opcional)
print("=" * 70)
print("💡 EXEMPLOS DE CONSULTAS:")
print("=" * 70)
print()
print("# Ver estabelecimentos de São Paulo:")
print('conn.execute("SELECT cnes, no_fantasia FROM raw_st WHERE uf = \'35\' LIMIT 5").fetchall()')
print()
print("# Ver profissionais médicos (CBO 225...):")
print('conn.execute("SELECT cpf_prof, cbo FROM raw_pf WHERE cbo LIKE \'225%\' LIMIT 5").fetchall()')
print()
print("# Ver equipamentos de raio-X:")
print('conn.execute("SELECT cnes, codequip FROM raw_eq WHERE tipequip = \'01\' LIMIT 5").fetchall()')
print()

conn.close()

print("=" * 70)
print("✅ Inspeção concluída!")
print("=" * 70)
