import os
print(os.listdir(PYSUS_CACHEPATH))