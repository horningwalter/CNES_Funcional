"""
LINC - Pipeline ETL do CNES/DATASUS.
"""
__version__ = "1.0.0"
