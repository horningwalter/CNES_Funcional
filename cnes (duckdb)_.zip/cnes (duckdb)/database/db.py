"""
Módulo de persistência em DuckDB.
DuckDB é otimizado para análise de grandes volumes de dados (OLAP).
"""
import duckdb
import logging
from datetime import datetime
from contextlib import contextmanager
import polars as pl
from config import DB_PATH, DATA_DIR

logger = logging.getLogger(__name__)

@contextmanager
def get_conn():
    """Context manager para conexão DuckDB."""
    conn = duckdb.connect(str(DB_PATH))
    try:
        yield conn
    finally:
        conn.close()

def init_db():
    """Inicializa o banco de dados."""
    # Garante que o diretório de dados existe
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    logger.info(f"Diretório de dados: {DATA_DIR}")
    logger.info(f"Banco de dados: {DB_PATH}")

    if not DB_PATH.exists():
        logger.info("Banco de dados não existe, será criado")

    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS execucao_controle (
                id INTEGER PRIMARY KEY,
                ano INTEGER NOT NULL,
                mes INTEGER NOT NULL,
                prefixo VARCHAR NOT NULL,
                qtd_registros INTEGER,
                iniciado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                finalizado_em TIMESTAMP,
                status VARCHAR DEFAULT 'EXECUTANDO',
                UNIQUE(ano, mes, prefixo)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_execucao_periodo ON execucao_controle(ano, mes)")

    logger.info(f"Banco de dados inicializado ({DB_PATH.stat().st_size} bytes)")

def ja_processado(ano: int, mes: int, prefixo: str) -> bool:
    with get_conn() as conn:
        result = conn.execute(
            "SELECT 1 FROM execucao_controle WHERE ano=? AND mes=? AND prefixo=? AND status='SUCESSO'",
            (ano, mes, prefixo)
        ).fetchone()
        return result is not None

def mes_completo(ano: int, mes: int, prefixos: list) -> bool:
    with get_conn() as conn:
        result = conn.execute(
            "SELECT COUNT(DISTINCT prefixo) FROM execucao_controle WHERE ano=? AND mes=? AND status='SUCESSO'",
            (ano, mes)
        ).fetchone()
        return result[0] >= len(prefixos) if result else False

def registrar_inicio(ano: int, mes: int, prefixo: str) -> int:
    with get_conn() as conn:
        # Deleta qualquer execução anterior deste período/prefixo
        conn.execute("DELETE FROM execucao_controle WHERE ano=? AND mes=? AND prefixo=?", (ano, mes, prefixo))

        # Gera próximo ID baseado no MAX atual
        max_id = conn.execute("SELECT COALESCE(MAX(id), 0) FROM execucao_controle").fetchone()[0]
        exec_id = max_id + 1

        # Insere novo registro
        conn.execute(
            "INSERT INTO execucao_controle (id, ano, mes, prefixo) VALUES (?, ?, ?, ?)",
            (exec_id, ano, mes, prefixo)
        )

        return exec_id

def registrar_fim(exec_id: int, qtd: int, status: str = 'SUCESSO'):
    with get_conn() as conn:
        conn.execute(
            "UPDATE execucao_controle SET finalizado_em=CURRENT_TIMESTAMP, qtd_registros=?, status=? WHERE id=?",
            (qtd, status, exec_id)
        )

def salvar_df(df: pl.DataFrame, table: str, ano: int, mes: int) -> int:
    """
    Salva DataFrame Polars no DuckDB.
    DuckDB tem integração nativa com Polars via Arrow.
    """
    if df.is_empty():
        logger.warning(f"DataFrame vazio para {table}, nenhum dado para salvar")
        return 0

    # Garante que o diretório existe
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    # Adiciona colunas de controle
    df = df.with_columns([
        pl.lit(ano).alias("_ano_cmp"),
        pl.lit(mes).alias("_mes_cmp"),
        pl.lit(datetime.now().isoformat()).alias("_data_carga")
    ])

    try:
        with get_conn() as conn:
            # Verifica se tabela existe e deleta dados do período
            table_exists_query = conn.execute(
                "SELECT COUNT(*) FROM information_schema.tables WHERE table_name=?",
                (table,)
            ).fetchone()

            if table_exists_query and table_exists_query[0] > 0:
                result = conn.execute(
                    f"DELETE FROM {table} WHERE _ano_cmp=? AND _mes_cmp=?",
                    (ano, mes)
                )
                deleted = result.fetchone()
                deleted_count = deleted[0] if deleted else 0
                logger.info(f"{table}: {deleted_count} registros antigos deletados para {mes:02d}/{ano}")

            # Salva dados usando integração nativa Arrow do DuckDB
            # DuckDB pode ler diretamente de Polars DataFrame via Arrow
            conn.execute(f"CREATE TABLE IF NOT EXISTS {table} AS SELECT * FROM df WHERE 1=0")
            conn.execute(f"INSERT INTO {table} SELECT * FROM df")

            # Verifica se dados foram realmente salvos
            count = conn.execute(
                f"SELECT COUNT(*) FROM {table} WHERE _ano_cmp=? AND _mes_cmp=?",
                (ano, mes)
            ).fetchone()[0]

            if count != len(df):
                logger.error(f"{table}: Esperado {len(df)} registros, mas salvou apenas {count}")
                raise ValueError(f"Falha na verificação de integridade: esperado {len(df)}, salvou {count}")

            logger.info(f"{table}: {count} registros salvos com sucesso no banco")
            return count

    except Exception as e:
        logger.error(f"Erro ao salvar dados em {table}: {e}", exc_info=True)
        raise

def executar_sql(sql: str):
    with get_conn() as conn:
        # DuckDB executa múltiplas statements separadamente
        statements = [s.strip() for s in sql.split(';') if s.strip()]
        for stmt in statements:
            conn.execute(stmt)

def table_exists(table: str) -> bool:
    with get_conn() as conn:
        result = conn.execute(
            "SELECT COUNT(*) FROM information_schema.tables WHERE table_name=?",
            (table,)
        ).fetchone()
        return result[0] > 0 if result else False
