"""
Modulo de Semantic Views do Snowflake para dados CNES.

Define o modelo dimensional semantico utilizando Snowflake Semantic Views.
As Semantic Views permitem definir dimensoes, metricas e relacionamentos
de forma declarativa, facilitando analises e integracao com ferramentas de BI.

Referencia: https://docs.snowflake.com/en/user-guide/views-semantic/overview

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import logging
from typing import List

from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from .connector import executar_multiplos_sql

logger = logging.getLogger(__name__)

# Schema para semantic views (separado das tabelas raw)
SEMANTIC_SCHEMA = "SEMANTIC"


def _criar_schema_semantic() -> None:
    """Cria schema para as semantic views se nao existir."""
    sql = f"""
    CREATE SCHEMA IF NOT EXISTS {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}
    """
    executar_multiplos_sql([sql])
    logger.info(f"Schema {SEMANTIC_SCHEMA} verificado/criado")


def criar_semantic_views() -> List[str]:
    """
    Cria todas as Semantic Views do modelo CNES.

    As Semantic Views definem:
    - Entidades de negocio (Estabelecimentos, Profissionais, etc.)
    - Dimensoes (Tempo, UF, Tipo de Unidade, etc.)
    - Metricas (contagens, somas, etc.)
    - Relacionamentos entre entidades

    Returns:
        Lista com os nomes das semantic views criadas.
    """
    logger.info("Criando Semantic Views no Snowflake...")

    # Garante que o schema existe
    _criar_schema_semantic()

    views_criadas = []

    # Cria cada semantic view
    views = [
        ("sv_cnes_analise", _get_sql_semantic_view_cnes()),
    ]

    for nome, sql in views:
        try:
            executar_multiplos_sql([sql])
            views_criadas.append(nome)
            logger.info(f"Semantic View {nome} criada com sucesso")
        except Exception as e:
            logger.error(f"Erro ao criar Semantic View {nome}: {e}")

    return views_criadas


def _get_sql_semantic_view_cnes() -> str:
    """
    Retorna o SQL para criar a Semantic View principal do CNES.

    A Semantic View define o modelo dimensional completo com:
    - Tabelas logicas para cada entidade
    - Relacionamentos via chaves
    - Dimensoes para analise
    - Metricas agregadas
    """
    return f"""
    CREATE OR REPLACE SEMANTIC VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.sv_cnes_analise

    -- ==========================================================================
    -- TABELAS LOGICAS (Entidades)
    -- ==========================================================================
    TABLES (
        -- Tabela de Estabelecimentos de Saude
        estabelecimento AS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_st
            PRIMARY KEY (cnes, _ano_cmp, _mes_cmp),

        -- Tabela de Profissionais de Saude
        profissional AS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_pf
            PRIMARY KEY (cnes, cns_prof, cbo, _ano_cmp, _mes_cmp),

        -- Tabela de Equipamentos
        equipamento AS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_eq
            PRIMARY KEY (cnes, codequip, _ano_cmp, _mes_cmp),

        -- Tabela de Servicos Especializados
        servico AS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_sr
            PRIMARY KEY (cnes, serv_esp, _ano_cmp, _mes_cmp)
    )

    -- ==========================================================================
    -- RELACIONAMENTOS
    -- ==========================================================================
    RELATIONSHIPS (
        -- Profissionais estao vinculados a Estabelecimentos
        profissional (cnes, _ano_cmp, _mes_cmp) REFERENCES estabelecimento,

        -- Equipamentos estao em Estabelecimentos
        equipamento (cnes, _ano_cmp, _mes_cmp) REFERENCES estabelecimento,

        -- Servicos sao oferecidos por Estabelecimentos
        servico (cnes, _ano_cmp, _mes_cmp) REFERENCES estabelecimento
    )

    -- ==========================================================================
    -- DIMENSOES
    -- ==========================================================================
    DIMENSIONS (
        -- Dimensao Temporal
        estabelecimento._ano_cmp AS ano
            LABEL 'Ano de Competencia'
            DESCRIPTION 'Ano de referencia dos dados',

        estabelecimento._mes_cmp AS mes
            LABEL 'Mes de Competencia'
            DESCRIPTION 'Mes de referencia dos dados (1-12)',

        -- Dimensao Geografica
        estabelecimento.codufmun AS cod_municipio
            LABEL 'Codigo do Municipio'
            DESCRIPTION 'Codigo IBGE do municipio (7 digitos)',

        SUBSTR(estabelecimento.codufmun, 1, 2) AS cod_uf
            LABEL 'Codigo da UF'
            DESCRIPTION 'Codigo IBGE da Unidade Federativa (2 digitos)',

        -- Dimensao Tipo de Unidade
        estabelecimento.tp_unid AS cod_tipo_unidade
            LABEL 'Codigo do Tipo de Unidade'
            DESCRIPTION 'Codigo do tipo de estabelecimento de saude',

        CASE estabelecimento.tp_unid
            WHEN '01' THEN 'Posto de Saude'
            WHEN '02' THEN 'Centro de Saude/Unidade Basica'
            WHEN '04' THEN 'Policlinica'
            WHEN '05' THEN 'Hospital Geral'
            WHEN '07' THEN 'Hospital Especializado'
            WHEN '15' THEN 'Unidade Mista'
            WHEN '20' THEN 'Pronto Socorro Geral'
            WHEN '21' THEN 'Pronto Socorro Especializado'
            WHEN '22' THEN 'Consultorio Isolado'
            WHEN '36' THEN 'Clinica/Centro de Especialidade'
            WHEN '39' THEN 'Unidade de Apoio Diagnose e Terapia'
            WHEN '40' THEN 'Unidade Movel Terrestre'
            WHEN '42' THEN 'Unidade Movel Pre-Hospitalar Urgencia'
            WHEN '43' THEN 'Farmacia'
            WHEN '61' THEN 'Centro de Parto Normal'
            WHEN '62' THEN 'Hospital/Dia'
            WHEN '69' THEN 'Centro Hemoterapia/Hematologica'
            WHEN '70' THEN 'Centro de Atencao Psicossocial'
            WHEN '71' THEN 'Centro de Apoio a Saude da Familia'
            WHEN '72' THEN 'Unidade de Atencao a Saude Indigena'
            WHEN '73' THEN 'Pronto Atendimento'
            WHEN '74' THEN 'Polo Academia da Saude'
            WHEN '77' THEN 'Home Care'
            WHEN '80' THEN 'Laboratorio de Saude Publica'
            ELSE 'Outros'
        END AS desc_tipo_unidade
            LABEL 'Descricao do Tipo de Unidade'
            DESCRIPTION 'Nome descritivo do tipo de estabelecimento',

        -- Dimensao Natureza Juridica
        estabelecimento.nat_jur AS cod_natureza_juridica
            LABEL 'Codigo da Natureza Juridica'
            DESCRIPTION 'Codigo da natureza juridica do estabelecimento',

        CASE
            WHEN estabelecimento.nat_jur LIKE '1%' THEN 'Administracao Publica'
            WHEN estabelecimento.nat_jur IN ('2011', '2038') THEN 'Empresa Publica'
            WHEN estabelecimento.nat_jur LIKE '2%' THEN 'Entidade Empresarial'
            WHEN estabelecimento.nat_jur LIKE '3%' THEN 'Entidade sem Fins Lucrativos'
            WHEN estabelecimento.nat_jur LIKE '4%' THEN 'Pessoa Fisica'
            ELSE 'Outras'
        END AS setor
            LABEL 'Setor'
            DESCRIPTION 'Classificacao do setor (Publico/Privado)',

        -- Dimensao Vinculo SUS
        CASE WHEN estabelecimento.vinc_sus = '1' THEN 'Sim' ELSE 'Nao' END AS vinculo_sus
            LABEL 'Vinculo SUS'
            DESCRIPTION 'Indica se o estabelecimento tem vinculo com o SUS',

        -- Dimensao Turno de Atendimento
        estabelecimento.turno_at AS cod_turno_atendimento
            LABEL 'Codigo Turno de Atendimento'
            DESCRIPTION 'Codigo do turno de funcionamento',

        CASE estabelecimento.turno_at
            WHEN '1' THEN 'Manha'
            WHEN '2' THEN 'Tarde'
            WHEN '3' THEN 'Manha e Tarde'
            WHEN '4' THEN 'Noite'
            WHEN '5' THEN 'Manha, Tarde e Noite'
            WHEN '6' THEN 'Continuo 24h'
            ELSE 'Nao Informado'
        END AS desc_turno_atendimento
            LABEL 'Turno de Atendimento'
            DESCRIPTION 'Descricao do turno de funcionamento',

        -- Dimensao Clientela
        estabelecimento.clientel AS cod_clientela
            LABEL 'Codigo da Clientela'
            DESCRIPTION 'Codigo do tipo de clientela atendida',

        CASE estabelecimento.clientel
            WHEN '1' THEN 'Atendimento de demanda espontanea'
            WHEN '2' THEN 'Atendimento de demanda referenciada'
            WHEN '3' THEN 'Atendimento de demanda espontanea e referenciada'
            ELSE 'Nao Informado'
        END AS desc_clientela
            LABEL 'Tipo de Clientela'
            DESCRIPTION 'Descricao do tipo de clientela atendida',

        -- Dimensao Atividade
        estabelecimento.atividad AS cod_atividade
            LABEL 'Codigo da Atividade'
            DESCRIPTION 'Codigo da atividade de ensino/pesquisa',

        -- Dimensao Esfera Administrativa
        estabelecimento.esfera_a AS cod_esfera_administrativa
            LABEL 'Codigo da Esfera Administrativa'
            DESCRIPTION 'Codigo da esfera administrativa do estabelecimento',

        CASE estabelecimento.esfera_a
            WHEN '1' THEN 'Federal'
            WHEN '2' THEN 'Estadual'
            WHEN '3' THEN 'Municipal'
            WHEN '4' THEN 'Privado'
            ELSE 'Nao Informado'
        END AS desc_esfera_administrativa
            LABEL 'Esfera Administrativa'
            DESCRIPTION 'Descricao da esfera administrativa',

        -- Dimensao Nivel de Hierarquia
        estabelecimento.niv_hier AS cod_nivel_hierarquia
            LABEL 'Codigo do Nivel de Hierarquia'
            DESCRIPTION 'Codigo do nivel de hierarquia no sistema de saude',

        CASE estabelecimento.niv_hier
            WHEN '1' THEN 'Atencao Basica'
            WHEN '2' THEN 'Media Complexidade'
            WHEN '3' THEN 'Alta Complexidade'
            WHEN '4' THEN 'Nao se Aplica'
            ELSE 'Nao Informado'
        END AS desc_nivel_hierarquia
            LABEL 'Nivel de Hierarquia'
            DESCRIPTION 'Descricao do nivel de hierarquia',

        -- Dimensao Tipo de Prestador
        estabelecimento.tp_prest AS cod_tipo_prestador
            LABEL 'Codigo do Tipo de Prestador'
            DESCRIPTION 'Codigo do tipo de prestador de servicos',

        CASE estabelecimento.tp_prest
            WHEN '00' THEN 'Nao Informado'
            WHEN '01' THEN 'Publico'
            WHEN '02' THEN 'Filantropico'
            WHEN '03' THEN 'Privado Lucrativo'
            WHEN '04' THEN 'Privado Nao Lucrativo (Sindicato)'
            WHEN '05' THEN 'Privado Nao Lucrativo (Simples)'
            WHEN '06' THEN 'Pessoa Fisica'
            ELSE 'Outros'
        END AS desc_tipo_prestador
            LABEL 'Tipo de Prestador'
            DESCRIPTION 'Descricao do tipo de prestador',

        -- Dimensao Profissional
        profissional.cbo AS cod_cbo
            LABEL 'Codigo CBO'
            DESCRIPTION 'Classificacao Brasileira de Ocupacoes',

        profissional.cbounico AS cod_cbo_unico
            LABEL 'Codigo CBO Unico'
            DESCRIPTION 'Classificacao Brasileira de Ocupacoes (unico)',

        profissional.conselho AS cod_conselho
            LABEL 'Codigo do Conselho'
            DESCRIPTION 'Codigo do conselho profissional',

        CASE profissional.conselho
            WHEN '01' THEN 'CRM - Conselho Regional de Medicina'
            WHEN '02' THEN 'COREN - Conselho Regional de Enfermagem'
            WHEN '03' THEN 'CRO - Conselho Regional de Odontologia'
            WHEN '04' THEN 'CRF - Conselho Regional de Farmacia'
            WHEN '05' THEN 'CREFITO - Conselho Regional de Fisioterapia'
            WHEN '06' THEN 'CRN - Conselho Regional de Nutricao'
            WHEN '07' THEN 'CRP - Conselho Regional de Psicologia'
            WHEN '08' THEN 'CRESS - Conselho Regional de Servico Social'
            WHEN '09' THEN 'CRBM - Conselho Regional de Biomedicina'
            WHEN '10' THEN 'CREFONO - Conselho Regional de Fonoaudiologia'
            WHEN '11' THEN 'CRBio - Conselho Regional de Biologia'
            ELSE 'Outros/Nao Aplicavel'
        END AS desc_conselho
            LABEL 'Conselho Profissional'
            DESCRIPTION 'Nome do conselho profissional',

        profissional.vinculac AS cod_tipo_vinculo
            LABEL 'Codigo Tipo de Vinculo'
            DESCRIPTION 'Codigo do tipo de vinculo empregaticio',

        CASE profissional.vinculac
            WHEN '01' THEN 'Vinculo empregaticio'
            WHEN '02' THEN 'Autonomo'
            WHEN '03' THEN 'Bolsa'
            WHEN '04' THEN 'Residencia'
            WHEN '05' THEN 'Estagio'
            WHEN '06' THEN 'Cooperativa'
            WHEN '07' THEN 'Cedido'
            WHEN '08' THEN 'Contrato temporario'
            ELSE 'Outros'
        END AS desc_tipo_vinculo
            LABEL 'Tipo de Vinculo'
            DESCRIPTION 'Descricao do tipo de vinculo empregaticio',

        CASE WHEN profissional.prof_sus = '1' THEN 'Sim' ELSE 'Nao' END AS profissional_sus
            LABEL 'Profissional SUS'
            DESCRIPTION 'Indica se o profissional atende pelo SUS',

        CASE
            WHEN profissional.cbo LIKE '2231%' THEN 'Medico'
            WHEN profissional.cbo LIKE '2251%' THEN 'Medico'
            WHEN profissional.cbo LIKE '2252%' THEN 'Medico'
            WHEN profissional.cbo LIKE '2253%' THEN 'Medico'
            WHEN profissional.cbo LIKE '2235%' THEN 'Enfermeiro'
            WHEN profissional.cbo LIKE '3222%' THEN 'Tecnico/Auxiliar Enfermagem'
            WHEN profissional.cbo LIKE '2232%' THEN 'Cirurgiao Dentista'
            WHEN profissional.cbo LIKE '2234%' THEN 'Farmaceutico'
            WHEN profissional.cbo LIKE '2236%' THEN 'Fisioterapeuta'
            WHEN profissional.cbo LIKE '2237%' THEN 'Nutricionista'
            WHEN profissional.cbo LIKE '2515%' THEN 'Psicologo'
            WHEN profissional.cbo LIKE '2516%' THEN 'Assistente Social'
            WHEN profissional.cbo LIKE '5151%' THEN 'Agente Comunitario de Saude'
            ELSE 'Outros Profissionais'
        END AS categoria_profissional
            LABEL 'Categoria Profissional'
            DESCRIPTION 'Categoria do profissional de saude',

        -- Dimensao Equipamento
        equipamento.tipequip AS cod_tipo_equipamento
            LABEL 'Codigo Tipo de Equipamento'
            DESCRIPTION 'Codigo do tipo de equipamento',

        CASE equipamento.tipequip
            WHEN '01' THEN 'Diagnostico por Imagem'
            WHEN '02' THEN 'Infraestrutura'
            WHEN '03' THEN 'Metodos Graficos'
            WHEN '04' THEN 'Odontologico'
            WHEN '05' THEN 'Manutencao da Vida'
            WHEN '06' THEN 'Outros Equipamentos'
            ELSE 'Nao Informado'
        END AS desc_tipo_equipamento
            LABEL 'Tipo de Equipamento'
            DESCRIPTION 'Descricao do tipo de equipamento',

        equipamento.codequip AS cod_equipamento
            LABEL 'Codigo do Equipamento'
            DESCRIPTION 'Codigo especifico do equipamento',

        CASE equipamento.codequip
            -- Diagnostico por Imagem (01)
            WHEN '01' THEN 'Raio X ate 100 mA'
            WHEN '02' THEN 'Raio X de 100 a 500 mA'
            WHEN '03' THEN 'Raio X mais de 500 mA'
            WHEN '04' THEN 'Mamografo com Comando Simples'
            WHEN '05' THEN 'Mamografo com Estereotaxia'
            WHEN '06' THEN 'Tomografo Computadorizado'
            WHEN '07' THEN 'Ressonancia Magnetica'
            WHEN '08' THEN 'Ultrassom Doppler Colorido'
            WHEN '09' THEN 'Gama Camara'
            WHEN '10' THEN 'PET-CT'
            WHEN '11' THEN 'Densitometro Osseo'
            WHEN '12' THEN 'Raio X Odontologico Intra-oral'
            WHEN '13' THEN 'Raio X Odontologico Extra-oral'
            -- Metodos Graficos (03)
            WHEN '30' THEN 'Eletrocardiografo'
            WHEN '31' THEN 'Eletroencefalografo'
            -- Odontologico (04)
            WHEN '40' THEN 'Equipo Odontologico'
            WHEN '41' THEN 'Compressor Odontologico'
            WHEN '42' THEN 'Fotopolimerizador'
            WHEN '43' THEN 'Caneta de Alta Rotacao'
            WHEN '44' THEN 'Amalgamador'
            WHEN '45' THEN 'Aparelho de Profilaxia'
            -- Manutencao da Vida (05)
            WHEN '50' THEN 'Monitor de ECG'
            WHEN '51' THEN 'Desfibrilador'
            WHEN '52' THEN 'Cardioversor'
            WHEN '53' THEN 'Marcapasso Temporario'
            WHEN '54' THEN 'Bomba de Infusao'
            WHEN '55' THEN 'Respirador/Ventilador'
            WHEN '56' THEN 'Reanimador Pulmonar'
            WHEN '57' THEN 'Oximetro'
            WHEN '58' THEN 'Monitor Multiparametrico'
            WHEN '59' THEN 'Incubadora'
            WHEN '60' THEN 'Berco Aquecido'
            WHEN '61' THEN 'Fototerapia'
            WHEN '62' THEN 'CPAP'
            WHEN '63' THEN 'Maquina de Hemodialise'
            WHEN '64' THEN 'Equipamento de Circulacao Extra-corporea'
            ELSE 'Outro Equipamento'
        END AS desc_equipamento
            LABEL 'Descricao do Equipamento'
            DESCRIPTION 'Nome descritivo do equipamento',

        CASE WHEN equipamento.ind_sus = '1' THEN 'Sim' ELSE 'Nao' END AS equipamento_sus
            LABEL 'Equipamento SUS'
            DESCRIPTION 'Indica se o equipamento esta disponivel para o SUS',

        -- Dimensao Servico
        servico.serv_esp AS cod_servico
            LABEL 'Codigo do Servico'
            DESCRIPTION 'Codigo do servico especializado',

        CASE servico.serv_esp
            -- Servicos de Atencao Basica
            WHEN '100' THEN 'Servico de Atencao Basica'
            WHEN '101' THEN 'Estrategia Saude da Familia'
            WHEN '102' THEN 'Atencao Domiciliar'
            WHEN '103' THEN 'Nucleo Apoio Saude Familia (NASF)'
            WHEN '104' THEN 'Consultorio na Rua'
            -- Servicos de Urgencia/Emergencia
            WHEN '105' THEN 'Servico de Atencao a Urgencia/Emergencia'
            WHEN '106' THEN 'SAMU 192'
            WHEN '107' THEN 'UPA 24 horas'
            -- Servicos Especializados
            WHEN '108' THEN 'Servico de Reabilitacao'
            WHEN '109' THEN 'Servico de Terapia Renal Substitutiva'
            WHEN '110' THEN 'Servico de Oncologia'
            WHEN '111' THEN 'Servico de Cardiologia'
            WHEN '112' THEN 'Servico de Neurologia'
            WHEN '113' THEN 'Servico de Ortopedia/Traumatologia'
            WHEN '114' THEN 'Servico de Pediatria'
            WHEN '115' THEN 'Servico de Ginecologia/Obstetricia'
            WHEN '116' THEN 'Servico de Neonatologia'
            WHEN '117' THEN 'Servico de Cirurgia Geral'
            WHEN '118' THEN 'Servico de Oftalmologia'
            WHEN '119' THEN 'Servico de Otorrinolaringologia'
            -- Servicos de Saude Mental
            WHEN '120' THEN 'Servico de Atencao Psicossocial'
            WHEN '121' THEN 'CAPS I'
            WHEN '122' THEN 'CAPS II'
            WHEN '123' THEN 'CAPS III'
            WHEN '124' THEN 'CAPS AD'
            WHEN '125' THEN 'CAPS Infantil'
            -- Servicos de Diagnostico
            WHEN '126' THEN 'Servico de Diagnostico por Imagem'
            WHEN '127' THEN 'Servico de Laboratorio Clinico'
            WHEN '128' THEN 'Servico de Anatomia Patologica'
            WHEN '129' THEN 'Servico de Hemoterapia'
            -- Servicos Hospitalares
            WHEN '130' THEN 'Servico de Internacao'
            WHEN '131' THEN 'UTI Adulto'
            WHEN '132' THEN 'UTI Pediatrica'
            WHEN '133' THEN 'UTI Neonatal'
            WHEN '134' THEN 'Centro Cirurgico'
            WHEN '135' THEN 'Centro Obstetrico'
            -- Outros Servicos
            WHEN '136' THEN 'Servico de Transplante'
            WHEN '137' THEN 'Servico de Quimioterapia'
            WHEN '138' THEN 'Servico de Radioterapia'
            WHEN '139' THEN 'Servico de Medicina Nuclear'
            WHEN '140' THEN 'Servico de Hemodinamica'
            WHEN '141' THEN 'Servico de Litotripsia'
            WHEN '142' THEN 'Servico de Odontologia'
            ELSE 'Outro Servico'
        END AS desc_servico
            LABEL 'Descricao do Servico'
            DESCRIPTION 'Nome descritivo do servico especializado',

        servico.class_sr AS classificacao_servico
            LABEL 'Classificacao do Servico'
            DESCRIPTION 'Classificacao do servico especializado',

        CASE
            WHEN servico.amb_sus = '1' OR servico.hosp_sus = '1' THEN 'Sim'
            ELSE 'Nao'
        END AS servico_sus
            LABEL 'Servico SUS'
            DESCRIPTION 'Indica se o servico e oferecido pelo SUS',

        CASE servico.amb_sus
            WHEN '1' THEN 'Sim'
            ELSE 'Nao'
        END AS ambulatorial_sus
            LABEL 'Ambulatorial SUS'
            DESCRIPTION 'Servico ambulatorial disponivel pelo SUS',

        CASE servico.hosp_sus
            WHEN '1' THEN 'Sim'
            ELSE 'Nao'
        END AS hospitalar_sus
            LABEL 'Hospitalar SUS'
            DESCRIPTION 'Servico hospitalar disponivel pelo SUS'
    )

    -- ==========================================================================
    -- METRICAS
    -- ==========================================================================
    METRICS (
        -- Metricas de Estabelecimentos
        COUNT(DISTINCT estabelecimento.cnes) AS qtd_estabelecimentos
            LABEL 'Quantidade de Estabelecimentos'
            DESCRIPTION 'Total de estabelecimentos de saude unicos',

        COUNT(DISTINCT CASE WHEN estabelecimento.vinc_sus = '1' THEN estabelecimento.cnes END) AS qtd_estabelecimentos_sus
            LABEL 'Estabelecimentos SUS'
            DESCRIPTION 'Total de estabelecimentos vinculados ao SUS',

        -- Metricas de Profissionais
        COUNT(DISTINCT profissional.cns_prof) AS qtd_profissionais
            LABEL 'Quantidade de Profissionais'
            DESCRIPTION 'Total de profissionais unicos (por CNS)',

        COUNT(*) AS qtd_vinculos_profissionais
            LABEL 'Vinculos Profissionais'
            DESCRIPTION 'Total de vinculos profissionais',

        SUM(COALESCE(TRY_CAST(profissional.hora_amb AS INTEGER), 0)) AS carga_horaria_ambulatorial
            LABEL 'Carga Horaria Ambulatorial'
            DESCRIPTION 'Soma das horas ambulatoriais',

        SUM(COALESCE(TRY_CAST(profissional.horahosp AS INTEGER), 0)) AS carga_horaria_hospitalar
            LABEL 'Carga Horaria Hospitalar'
            DESCRIPTION 'Soma das horas hospitalares',

        SUM(COALESCE(TRY_CAST(profissional.horaoutr AS INTEGER), 0)) AS carga_horaria_outros
            LABEL 'Carga Horaria Outros'
            DESCRIPTION 'Soma das horas em outros vinculos',

        -- Metricas de Equipamentos
        SUM(COALESCE(TRY_CAST(equipamento.qt_exist AS INTEGER), 0)) AS qtd_equipamentos_existentes
            LABEL 'Equipamentos Existentes'
            DESCRIPTION 'Total de equipamentos existentes',

        SUM(COALESCE(TRY_CAST(equipamento.qt_uso AS INTEGER), 0)) AS qtd_equipamentos_em_uso
            LABEL 'Equipamentos em Uso'
            DESCRIPTION 'Total de equipamentos em uso',

        SUM(CASE WHEN equipamento.ind_sus = '1' THEN COALESCE(TRY_CAST(equipamento.qt_uso AS INTEGER), 0) ELSE 0 END) AS qtd_equipamentos_sus
            LABEL 'Equipamentos SUS'
            DESCRIPTION 'Total de equipamentos disponiveis para o SUS',

        -- Metricas de Servicos
        COUNT(DISTINCT servico.serv_esp) AS qtd_servicos_distintos
            LABEL 'Servicos Distintos'
            DESCRIPTION 'Total de tipos de servicos oferecidos',

        COUNT(*) AS qtd_ofertas_servico
            LABEL 'Ofertas de Servico'
            DESCRIPTION 'Total de ofertas de servicos (estabelecimento x servico)',

        COUNT(DISTINCT CASE WHEN servico.amb_sus = '1' OR servico.hosp_sus = '1' THEN CONCAT(servico.cnes, servico.serv_esp) END) AS qtd_ofertas_servico_sus
            LABEL 'Ofertas de Servico SUS'
            DESCRIPTION 'Total de ofertas de servicos pelo SUS',

        -- Metricas de Profissionais por categoria
        COUNT(DISTINCT CASE WHEN profissional.cbo LIKE '2231%' OR profissional.cbo LIKE '2251%' OR profissional.cbo LIKE '2252%' OR profissional.cbo LIKE '2253%' THEN profissional.cns_prof END) AS qtd_medicos
            LABEL 'Quantidade de Medicos'
            DESCRIPTION 'Total de medicos unicos',

        COUNT(DISTINCT CASE WHEN profissional.cbo LIKE '2235%' THEN profissional.cns_prof END) AS qtd_enfermeiros
            LABEL 'Quantidade de Enfermeiros'
            DESCRIPTION 'Total de enfermeiros unicos',

        COUNT(DISTINCT CASE WHEN profissional.cbo LIKE '3222%' THEN profissional.cns_prof END) AS qtd_tecnicos_enfermagem
            LABEL 'Quantidade de Tecnicos/Auxiliares de Enfermagem'
            DESCRIPTION 'Total de tecnicos e auxiliares de enfermagem unicos',

        COUNT(DISTINCT CASE WHEN profissional.cbo LIKE '2232%' THEN profissional.cns_prof END) AS qtd_dentistas
            LABEL 'Quantidade de Dentistas'
            DESCRIPTION 'Total de cirurgioes dentistas unicos',

        COUNT(DISTINCT CASE WHEN profissional.cbo LIKE '5151%' THEN profissional.cns_prof END) AS qtd_acs
            LABEL 'Quantidade de ACS'
            DESCRIPTION 'Total de agentes comunitarios de saude unicos',

        -- Metricas de Taxa de Utilizacao
        ROUND(
            CASE
                WHEN SUM(COALESCE(TRY_CAST(equipamento.qt_exist AS FLOAT), 0)) > 0
                THEN SUM(COALESCE(TRY_CAST(equipamento.qt_uso AS FLOAT), 0)) / SUM(COALESCE(TRY_CAST(equipamento.qt_exist AS FLOAT), 0)) * 100
                ELSE 0
            END, 2
        ) AS taxa_utilizacao_equipamentos
            LABEL 'Taxa de Utilizacao de Equipamentos (%)'
            DESCRIPTION 'Percentual de equipamentos em uso em relacao aos existentes'
    )
    """


def criar_views_auxiliares() -> List[str]:
    """
    Cria views auxiliares para facilitar consultas comuns.

    Estas views materializam consultas frequentes e servem como
    camada intermediaria entre as tabelas raw e as analises.

    Returns:
        Lista com os nomes das views criadas.
    """
    logger.info("Criando views auxiliares...")

    views = [
        # View de Estabelecimentos por UF
        (
            "vw_estabelecimentos_uf",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.vw_estabelecimentos_uf AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                COUNT(DISTINCT cnes) AS qtd_estabelecimentos,
                COUNT(DISTINCT CASE WHEN vinc_sus = '1' THEN cnes END) AS qtd_sus
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_st
            GROUP BY 1, 2, 3
            """
        ),
        # View de Profissionais por UF
        (
            "vw_profissionais_uf",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.vw_profissionais_uf AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                COUNT(DISTINCT cns_prof) AS qtd_profissionais,
                COUNT(*) AS qtd_vinculos,
                SUM(COALESCE(TRY_CAST(hora_amb AS INTEGER), 0) +
                    COALESCE(TRY_CAST(horahosp AS INTEGER), 0) +
                    COALESCE(TRY_CAST(horaoutr AS INTEGER), 0)) AS carga_horaria_total
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_pf
            GROUP BY 1, 2, 3
            """
        ),
        # View de Equipamentos por UF
        (
            "vw_equipamentos_uf",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.vw_equipamentos_uf AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                SUM(COALESCE(TRY_CAST(qt_exist AS INTEGER), 0)) AS qtd_existente,
                SUM(COALESCE(TRY_CAST(qt_uso AS INTEGER), 0)) AS qtd_em_uso,
                SUM(CASE WHEN ind_sus = '1' THEN COALESCE(TRY_CAST(qt_uso AS INTEGER), 0) ELSE 0 END) AS qtd_sus
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_eq
            GROUP BY 1, 2, 3
            """
        ),
        # View de Servicos por UF
        (
            "vw_servicos_uf",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.vw_servicos_uf AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                COUNT(DISTINCT serv_esp) AS qtd_tipos_servico,
                COUNT(*) AS qtd_ofertas,
                COUNT(DISTINCT cnes) AS qtd_estabelecimentos,
                SUM(CASE WHEN amb_sus = '1' THEN 1 ELSE 0 END) AS qtd_amb_sus,
                SUM(CASE WHEN hosp_sus = '1' THEN 1 ELSE 0 END) AS qtd_hosp_sus
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_sr
            GROUP BY 1, 2, 3
            """
        ),
        # Fato Estabelecimento
        (
            "fato_estabelecimento",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.fato_estabelecimento AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                _data_carga AS data_carga,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                codufmun AS cod_municipio,
                cod_cep,
                cnes,
                pfpj AS pessoa_fisica_juridica,
                nivel_dep AS nivel_dependencia,
                tp_unid AS cod_tipo_unidade,
                CASE tp_unid
                    WHEN '01' THEN 'Posto de Saude'
                    WHEN '02' THEN 'Centro de Saude/Unidade Basica'
                    WHEN '04' THEN 'Policlinica'
                    WHEN '05' THEN 'Hospital Geral'
                    WHEN '07' THEN 'Hospital Especializado'
                    WHEN '15' THEN 'Unidade Mista'
                    WHEN '20' THEN 'Pronto Socorro Geral'
                    WHEN '21' THEN 'Pronto Socorro Especializado'
                    WHEN '22' THEN 'Consultorio Isolado'
                    WHEN '36' THEN 'Clinica/Centro de Especialidade'
                    WHEN '39' THEN 'Unidade de Apoio Diagnose e Terapia'
                    WHEN '40' THEN 'Unidade Movel Terrestre'
                    WHEN '42' THEN 'Unidade Movel Pre-Hospitalar Urgencia'
                    WHEN '43' THEN 'Farmacia'
                    WHEN '61' THEN 'Centro de Parto Normal'
                    WHEN '62' THEN 'Hospital/Dia'
                    WHEN '69' THEN 'Centro Hemoterapia/Hematologica'
                    WHEN '70' THEN 'Centro de Atencao Psicossocial'
                    WHEN '71' THEN 'Centro de Apoio a Saude da Familia'
                    WHEN '72' THEN 'Unidade de Atencao a Saude Indigena'
                    WHEN '73' THEN 'Pronto Atendimento'
                    WHEN '74' THEN 'Polo Academia da Saude'
                    WHEN '77' THEN 'Home Care'
                    WHEN '80' THEN 'Laboratorio de Saude Publica'
                    ELSE 'Outros'
                END AS desc_tipo_unidade,
                nat_jur AS cod_natureza_juridica,
                CASE
                    WHEN nat_jur LIKE '1%' THEN 'Administracao Publica'
                    WHEN nat_jur IN ('2011', '2038') THEN 'Empresa Publica'
                    WHEN nat_jur LIKE '2%' THEN 'Entidade Empresarial'
                    WHEN nat_jur LIKE '3%' THEN 'Entidade sem Fins Lucrativos'
                    WHEN nat_jur LIKE '4%' THEN 'Pessoa Fisica'
                    ELSE 'Outras'
                END AS setor,
                natureza AS cod_natureza,
                vinc_sus,
                CASE WHEN vinc_sus = '1' THEN 'Sim' ELSE 'Nao' END AS desc_vinculo_sus,
                tpgestao AS tipo_gestao,
                esfera_a AS cod_esfera_administrativa,
                CASE esfera_a
                    WHEN '1' THEN 'Federal'
                    WHEN '2' THEN 'Estadual'
                    WHEN '3' THEN 'Municipal'
                    WHEN '4' THEN 'Privado'
                    ELSE 'Nao Informado'
                END AS desc_esfera_administrativa,
                retencao AS retencao_tributos,
                atividad AS cod_atividade,
                clientel AS cod_clientela,
                CASE clientel
                    WHEN '1' THEN 'Atendimento de demanda espontanea'
                    WHEN '2' THEN 'Atendimento de demanda referenciada'
                    WHEN '3' THEN 'Atendimento de demanda espontanea e referenciada'
                    ELSE 'Nao Informado'
                END AS desc_clientela,
                turno_at AS cod_turno_atendimento,
                CASE turno_at
                    WHEN '1' THEN 'Manha'
                    WHEN '2' THEN 'Tarde'
                    WHEN '3' THEN 'Manha e Tarde'
                    WHEN '4' THEN 'Noite'
                    WHEN '5' THEN 'Manha, Tarde e Noite'
                    WHEN '6' THEN 'Continuo 24h'
                    ELSE 'Nao Informado'
                END AS desc_turno_atendimento,
                niv_hier AS cod_nivel_hierarquia,
                CASE niv_hier
                    WHEN '1' THEN 'Atencao Basica'
                    WHEN '2' THEN 'Media Complexidade'
                    WHEN '3' THEN 'Alta Complexidade'
                    WHEN '4' THEN 'Nao se Aplica'
                    ELSE 'Nao Informado'
                END AS desc_nivel_hierarquia,
                tp_prest AS cod_tipo_prestador,
                CASE tp_prest
                    WHEN '00' THEN 'Nao Informado'
                    WHEN '01' THEN 'Publico'
                    WHEN '02' THEN 'Filantropico'
                    WHEN '03' THEN 'Privado Lucrativo'
                    WHEN '04' THEN 'Privado Nao Lucrativo (Sindicato)'
                    WHEN '05' THEN 'Privado Nao Lucrativo (Simples)'
                    WHEN '06' THEN 'Pessoa Fisica'
                    ELSE 'Outros'
                END AS desc_tipo_prestador
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_st
            """
        ),
        # Fato Profissional
        (
            "fato_profissional",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.fato_profissional AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                _data_carga AS data_carga,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                codufmun AS cod_municipio,
                cnes,
                cns_prof,
                nomeprof AS nome_profissional,
                cbo AS cod_cbo,
                CASE
                    WHEN cbo LIKE '2231%' THEN 'Medico'
                    WHEN cbo LIKE '2251%' THEN 'Medico'
                    WHEN cbo LIKE '2252%' THEN 'Medico'
                    WHEN cbo LIKE '2253%' THEN 'Medico'
                    WHEN cbo LIKE '2235%' THEN 'Enfermeiro'
                    WHEN cbo LIKE '3222%' THEN 'Tecnico/Auxiliar Enfermagem'
                    WHEN cbo LIKE '2232%' THEN 'Cirurgiao Dentista'
                    WHEN cbo LIKE '2234%' THEN 'Farmaceutico'
                    WHEN cbo LIKE '2236%' THEN 'Fisioterapeuta'
                    WHEN cbo LIKE '2237%' THEN 'Nutricionista'
                    WHEN cbo LIKE '2515%' THEN 'Psicologo'
                    WHEN cbo LIKE '2516%' THEN 'Assistente Social'
                    WHEN cbo LIKE '5151%' THEN 'Agente Comunitario de Saude'
                    ELSE 'Outros Profissionais'
                END AS categoria_profissional,
                cbounico AS cod_cbo_unico,
                conselho AS cod_conselho,
                CASE conselho
                    WHEN '01' THEN 'CRM - Conselho Regional de Medicina'
                    WHEN '02' THEN 'COREN - Conselho Regional de Enfermagem'
                    WHEN '03' THEN 'CRO - Conselho Regional de Odontologia'
                    WHEN '04' THEN 'CRF - Conselho Regional de Farmacia'
                    WHEN '05' THEN 'CREFITO - Conselho Regional de Fisioterapia'
                    WHEN '06' THEN 'CRN - Conselho Regional de Nutricao'
                    WHEN '07' THEN 'CRP - Conselho Regional de Psicologia'
                    WHEN '08' THEN 'CRESS - Conselho Regional de Servico Social'
                    WHEN '09' THEN 'CRBM - Conselho Regional de Biomedicina'
                    WHEN '10' THEN 'CREFONO - Conselho Regional de Fonoaudiologia'
                    WHEN '11' THEN 'CRBio - Conselho Regional de Biologia'
                    ELSE 'Outros/Nao Aplicavel'
                END AS desc_conselho,
                registro AS num_registro_conselho,
                vinculac AS cod_tipo_vinculo,
                CASE vinculac
                    WHEN '01' THEN 'Vinculo empregaticio'
                    WHEN '02' THEN 'Autonomo'
                    WHEN '03' THEN 'Bolsa'
                    WHEN '04' THEN 'Residencia'
                    WHEN '05' THEN 'Estagio'
                    WHEN '06' THEN 'Cooperativa'
                    WHEN '07' THEN 'Cedido'
                    WHEN '08' THEN 'Contrato temporario'
                    ELSE 'Outros'
                END AS desc_tipo_vinculo,
                vincul_c AS vinculo_contratado,
                vincul_a AS vinculo_autonomo,
                vincul_n AS vinculo_nao_aplicavel,
                prof_sus AS vinculo_sus,
                CASE WHEN prof_sus = '1' THEN 'Sim' ELSE 'Nao' END AS desc_vinculo_sus,
                profnsus AS vinculo_nao_sus,
                COALESCE(TRY_CAST(hora_amb AS INTEGER), 0) AS carga_horaria_ambulatorial,
                COALESCE(TRY_CAST(horahosp AS INTEGER), 0) AS carga_horaria_hospitalar,
                COALESCE(TRY_CAST(horaoutr AS INTEGER), 0) AS carga_horaria_outros,
                COALESCE(TRY_CAST(hoession AS INTEGER), 0) AS carga_horaria_ses,
                COALESCE(TRY_CAST(hora_amb AS INTEGER), 0) +
                    COALESCE(TRY_CAST(horahosp AS INTEGER), 0) +
                    COALESCE(TRY_CAST(horaoutr AS INTEGER), 0) AS carga_horaria_total
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_pf
            """
        ),
        # Fato Equipamento
        (
            "fato_equipamento",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.fato_equipamento AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                _data_carga AS data_carga,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                codufmun AS cod_municipio,
                cnes,
                tipequip AS cod_tipo_equipamento,
                CASE tipequip
                    WHEN '01' THEN 'Diagnostico por Imagem'
                    WHEN '02' THEN 'Infraestrutura'
                    WHEN '03' THEN 'Metodos Graficos'
                    WHEN '04' THEN 'Odontologico'
                    WHEN '05' THEN 'Manutencao da Vida'
                    WHEN '06' THEN 'Outros Equipamentos'
                    ELSE 'Nao Informado'
                END AS desc_tipo_equipamento,
                codequip AS cod_equipamento,
                CASE codequip
                    WHEN '01' THEN 'Raio X ate 100 mA'
                    WHEN '02' THEN 'Raio X de 100 a 500 mA'
                    WHEN '03' THEN 'Raio X mais de 500 mA'
                    WHEN '04' THEN 'Mamografo com Comando Simples'
                    WHEN '05' THEN 'Mamografo com Estereotaxia'
                    WHEN '06' THEN 'Tomografo Computadorizado'
                    WHEN '07' THEN 'Ressonancia Magnetica'
                    WHEN '08' THEN 'Ultrassom Doppler Colorido'
                    WHEN '09' THEN 'Gama Camara'
                    WHEN '10' THEN 'PET-CT'
                    WHEN '11' THEN 'Densitometro Osseo'
                    WHEN '12' THEN 'Raio X Odontologico Intra-oral'
                    WHEN '13' THEN 'Raio X Odontologico Extra-oral'
                    WHEN '30' THEN 'Eletrocardiografo'
                    WHEN '31' THEN 'Eletroencefalografo'
                    WHEN '40' THEN 'Equipo Odontologico'
                    WHEN '41' THEN 'Compressor Odontologico'
                    WHEN '42' THEN 'Fotopolimerizador'
                    WHEN '43' THEN 'Caneta de Alta Rotacao'
                    WHEN '44' THEN 'Amalgamador'
                    WHEN '45' THEN 'Aparelho de Profilaxia'
                    WHEN '50' THEN 'Monitor de ECG'
                    WHEN '51' THEN 'Desfibrilador'
                    WHEN '52' THEN 'Cardioversor'
                    WHEN '53' THEN 'Marcapasso Temporario'
                    WHEN '54' THEN 'Bomba de Infusao'
                    WHEN '55' THEN 'Respirador/Ventilador'
                    WHEN '56' THEN 'Reanimador Pulmonar'
                    WHEN '57' THEN 'Oximetro'
                    WHEN '58' THEN 'Monitor Multiparametrico'
                    WHEN '59' THEN 'Incubadora'
                    WHEN '60' THEN 'Berco Aquecido'
                    WHEN '61' THEN 'Fototerapia'
                    WHEN '62' THEN 'CPAP'
                    WHEN '63' THEN 'Maquina de Hemodialise'
                    WHEN '64' THEN 'Equipamento de Circulacao Extra-corporea'
                    ELSE 'Outro Equipamento'
                END AS desc_equipamento,
                COALESCE(TRY_CAST(qt_exist AS INTEGER), 0) AS qtd_existente,
                COALESCE(TRY_CAST(qt_uso AS INTEGER), 0) AS qtd_em_uso,
                COALESCE(TRY_CAST(qt_exist AS INTEGER), 0) - COALESCE(TRY_CAST(qt_uso AS INTEGER), 0) AS qtd_disponivel,
                ind_sus AS disponivel_sus,
                CASE WHEN ind_sus = '1' THEN 'Sim' ELSE 'Nao' END AS desc_disponivel_sus,
                ind_nsus AS disponivel_nao_sus
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_eq
            """
        ),
        # Fato Servico
        (
            "fato_servico",
            f"""
            CREATE OR REPLACE VIEW {SNOWFLAKE_DATABASE}.{SEMANTIC_SCHEMA}.fato_servico AS
            SELECT
                _ano_cmp AS ano,
                _mes_cmp AS mes,
                _data_carga AS data_carga,
                SUBSTR(codufmun, 1, 2) AS cod_uf,
                codufmun AS cod_municipio,
                cnes,
                serv_esp AS cod_servico,
                CASE serv_esp
                    WHEN '100' THEN 'Servico de Atencao Basica'
                    WHEN '101' THEN 'Estrategia Saude da Familia'
                    WHEN '102' THEN 'Atencao Domiciliar'
                    WHEN '103' THEN 'Nucleo Apoio Saude Familia (NASF)'
                    WHEN '104' THEN 'Consultorio na Rua'
                    WHEN '105' THEN 'Servico de Atencao a Urgencia/Emergencia'
                    WHEN '106' THEN 'SAMU 192'
                    WHEN '107' THEN 'UPA 24 horas'
                    WHEN '108' THEN 'Servico de Reabilitacao'
                    WHEN '109' THEN 'Servico de Terapia Renal Substitutiva'
                    WHEN '110' THEN 'Servico de Oncologia'
                    WHEN '111' THEN 'Servico de Cardiologia'
                    WHEN '112' THEN 'Servico de Neurologia'
                    WHEN '113' THEN 'Servico de Ortopedia/Traumatologia'
                    WHEN '114' THEN 'Servico de Pediatria'
                    WHEN '115' THEN 'Servico de Ginecologia/Obstetricia'
                    WHEN '116' THEN 'Servico de Neonatologia'
                    WHEN '117' THEN 'Servico de Cirurgia Geral'
                    WHEN '118' THEN 'Servico de Oftalmologia'
                    WHEN '119' THEN 'Servico de Otorrinolaringologia'
                    WHEN '120' THEN 'Servico de Atencao Psicossocial'
                    WHEN '121' THEN 'CAPS I'
                    WHEN '122' THEN 'CAPS II'
                    WHEN '123' THEN 'CAPS III'
                    WHEN '124' THEN 'CAPS AD'
                    WHEN '125' THEN 'CAPS Infantil'
                    WHEN '126' THEN 'Servico de Diagnostico por Imagem'
                    WHEN '127' THEN 'Servico de Laboratorio Clinico'
                    WHEN '128' THEN 'Servico de Anatomia Patologica'
                    WHEN '129' THEN 'Servico de Hemoterapia'
                    WHEN '130' THEN 'Servico de Internacao'
                    WHEN '131' THEN 'UTI Adulto'
                    WHEN '132' THEN 'UTI Pediatrica'
                    WHEN '133' THEN 'UTI Neonatal'
                    WHEN '134' THEN 'Centro Cirurgico'
                    WHEN '135' THEN 'Centro Obstetrico'
                    WHEN '136' THEN 'Servico de Transplante'
                    WHEN '137' THEN 'Servico de Quimioterapia'
                    WHEN '138' THEN 'Servico de Radioterapia'
                    WHEN '139' THEN 'Servico de Medicina Nuclear'
                    WHEN '140' THEN 'Servico de Hemodinamica'
                    WHEN '141' THEN 'Servico de Litotripsia'
                    WHEN '142' THEN 'Servico de Odontologia'
                    ELSE 'Outro Servico'
                END AS desc_servico,
                class_sr AS classificacao_servico,
                session AS terceiros,
                caression AS caracterizacao,
                amb_sus AS ambulatorial_sus,
                CASE WHEN amb_sus = '1' THEN 'Sim' ELSE 'Nao' END AS desc_ambulatorial_sus,
                amb_nsus AS ambulatorial_nao_sus,
                hosp_sus AS hospitalar_sus,
                CASE WHEN hosp_sus = '1' THEN 'Sim' ELSE 'Nao' END AS desc_hospitalar_sus,
                hosp_nsus AS hospitalar_nao_sus,
                CASE
                    WHEN amb_sus = '1' OR hosp_sus = '1' THEN 'Sim'
                    ELSE 'Nao'
                END AS atende_sus
            FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.raw_sr
            """
        ),
    ]

    views_criadas = []
    for nome, sql in views:
        try:
            executar_multiplos_sql([sql])
            views_criadas.append(nome)
            logger.info(f"View {nome} criada com sucesso")
        except Exception as e:
            logger.error(f"Erro ao criar view {nome}: {e}")

    return views_criadas
