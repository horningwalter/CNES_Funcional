"""
Modulo de integracao com Snowflake para dados CNES.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
from .connector import (
    get_connection,
    executar_sql,
    testar_conexao,
)

from .loader import (
    criar_external_stage,
    criar_tabelas_raw,
    carregar_dados_s3,
    refresh_tabelas,
)

from .semantic import (
    criar_semantic_views,
)
