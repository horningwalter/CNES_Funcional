"""
Modulo de carga de dados do S3 para Snowflake.

O S3 serve como area de staging temporaria. Os dados sao copiados
para tabelas NATIVAS do Snowflake usando COPY INTO, ficando armazenados
diretamente no Snowflake (nao requer acesso ao S3 nas consultas).

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import logging
from typing import List, Dict

from config import (
    S3_BUCKET,
    S3_PREFIX,
    S3_REGION,
    SNOWFLAKE_DATABASE,
    SNOWFLAKE_SCHEMA,
    PREFIXOS,
)
from .connector import executar_multiplos_sql, get_connection

logger = logging.getLogger(__name__)

# =============================================================================
# DEFINICAO DAS TABELAS RAW (NATIVAS NO SNOWFLAKE)
# =============================================================================

# Colunas comuns a todas as tabelas (controle)
COLUNAS_CONTROLE = """
    _ano_cmp INTEGER,
    _mes_cmp INTEGER,
    _data_carga VARCHAR
"""

# Definicao das tabelas por prefixo
TABELAS_RAW = {
    "raw_st": """
        cnes VARCHAR,
        codufmun VARCHAR,
        cpf_cnpj VARCHAR,
        pfpj VARCHAR,
        nivel_dep VARCHAR,
        cnpj_man VARCHAR,
        cod_ir VARCHAR,
        vinc_sus VARCHAR,
        tpgestao VARCHAR,
        esfera_a VARCHAR,
        retencao VARCHAR,
        atividad VARCHAR,
        natureza VARCHAR,
        nat_jur VARCHAR,
        clientel VARCHAR,
        tp_unid VARCHAR,
        turno_at VARCHAR,
        niv_hier VARCHAR,
        tp_prest VARCHAR,
        co_banco VARCHAR,
        co_agenc VARCHAR,
        c_corren VARCHAR,
        contession VARCHAR,
        alvession VARCHAR,
        licession VARCHAR,
        cod_cep VARCHAR
    """,
    "raw_pf": """
        cnes VARCHAR,
        codufmun VARCHAR,
        cbo VARCHAR,
        cbounico VARCHAR,
        nomeprof VARCHAR,
        cns_prof VARCHAR,
        cpf_prof VARCHAR,
        conselho VARCHAR,
        registro VARCHAR,
        vinculac VARCHAR,
        vincul_c VARCHAR,
        vincul_a VARCHAR,
        vincul_n VARCHAR,
        prof_sus VARCHAR,
        profnsus VARCHAR,
        hoession VARCHAR,
        horaoutr VARCHAR,
        horahosp VARCHAR,
        hora_amb VARCHAR
    """,
    "raw_eq": """
        cnes VARCHAR,
        codufmun VARCHAR,
        tipequip VARCHAR,
        codequip VARCHAR,
        qt_exist VARCHAR,
        qt_uso VARCHAR,
        ind_sus VARCHAR,
        ind_nsus VARCHAR
    """,
    "raw_sr": """
        cnes VARCHAR,
        codufmun VARCHAR,
        serv_esp VARCHAR,
        class_sr VARCHAR,
        session VARCHAR,
        caression VARCHAR,
        amb_sus VARCHAR,
        amb_nsus VARCHAR,
        hosp_sus VARCHAR,
        hosp_nsus VARCHAR
    """
}


def criar_storage_integration(integration_name: str = "cnes_s3_integration") -> None:
    """
    Cria Storage Integration para acesso ao S3.

    A Storage Integration permite que o Snowflake acesse o S3 de forma
    segura usando IAM Role. Requer configuracao previa na AWS.

    Args:
        integration_name: Nome da integration a ser criada.

    Nota:
        Este comando requer privilegio ACCOUNTADMIN.
        A ARN do IAM Role deve ser configurada na AWS.
    """
    logger.info(f"Criando Storage Integration: {integration_name}")
    logger.warning("ATENCAO: Este comando requer privilegio ACCOUNTADMIN")
    logger.warning("Configure o IAM Role na AWS antes de executar")

    # Nota: O usuario precisa substituir a ARN pelo valor correto
    sql = f"""
    CREATE OR REPLACE STORAGE INTEGRATION {integration_name}
        TYPE = EXTERNAL_STAGE
        STORAGE_PROVIDER = 'S3'
        ENABLED = TRUE
        STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::ACCOUNT_ID:role/snowflake-s3-role'
        STORAGE_ALLOWED_LOCATIONS = ('s3://{S3_BUCKET}/')
    """

    logger.info("SQL para criar Storage Integration:")
    logger.info(sql)
    logger.warning("Execute este comando manualmente com ACCOUNTADMIN")


def criar_external_stage(
    stage_name: str = "cnes_s3_stage",
    integration_name: str = "cnes_s3_integration"
) -> None:
    """
    Cria External Stage apontando para o bucket S3.

    O stage e usado apenas para COPY INTO (staging temporario).
    Os dados sao copiados para tabelas nativas do Snowflake.

    Args:
        stage_name: Nome do stage a ser criado.
        integration_name: Nome da storage integration.
    """
    logger.info(f"Criando External Stage: {stage_name}")

    sqls = [
        # Cria file format para Parquet
        f"""
        CREATE FILE FORMAT IF NOT EXISTS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.parquet_format
            TYPE = PARQUET
            COMPRESSION = SNAPPY
        """,

        # Cria External Stage usando Storage Integration
        f"""
        CREATE OR REPLACE STAGE {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{stage_name}
            STORAGE_INTEGRATION = {integration_name}
            URL = 's3://{S3_BUCKET}/{S3_PREFIX}/'
            FILE_FORMAT = {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.parquet_format
        """
    ]

    executar_multiplos_sql(sqls)
    logger.info(f"External Stage {stage_name} criado com sucesso")


def criar_tabelas_raw() -> List[str]:
    """
    Cria as tabelas RAW NATIVAS no Snowflake.

    As tabelas sao criadas no schema configurado. Os dados serao
    armazenados diretamente no Snowflake (nao em external tables).

    Returns:
        Lista com os nomes das tabelas criadas.
    """
    logger.info("Criando tabelas RAW nativas no Snowflake...")
    tabelas_criadas = []

    for table_name, colunas in TABELAS_RAW.items():
        sql = f"""
        CREATE TABLE IF NOT EXISTS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{table_name} (
            {colunas},
            {COLUNAS_CONTROLE}
        )
        """

        try:
            executar_multiplos_sql([sql])
            tabelas_criadas.append(table_name)
            logger.info(f"Tabela {table_name} criada/verificada")

        except Exception as e:
            logger.error(f"Erro ao criar tabela {table_name}: {e}")

    return tabelas_criadas


def carregar_dados_s3(
    table_name: str,
    ano: int = None,
    mes: int = None,
    stage_name: str = "cnes_s3_stage"
) -> int:
    """
    Copia dados do S3 para tabela NATIVA no Snowflake.

    Utiliza COPY INTO para carregar os arquivos Parquet do stage S3
    para a tabela destino. Os dados ficam armazenados NO Snowflake.

    Args:
        table_name: Nome da tabela destino (ex: raw_st).
        ano: Filtrar por ano (opcional).
        mes: Filtrar por mes (opcional).
        stage_name: Nome do stage S3.

    Returns:
        Quantidade de registros carregados.
    """
    logger.info(f"Copiando dados para {table_name} (COPY INTO)...")

    # Monta pattern de arquivos
    if ano and mes:
        pattern = f".*{table_name}/ano={ano}/mes={mes:02d}/.*\\.parquet"
    elif ano:
        pattern = f".*{table_name}/ano={ano}/.*\\.parquet"
    else:
        pattern = f".*{table_name}/.*\\.parquet"

    # COPY INTO - copia dados do S3 para tabela NATIVA
    sql = f"""
    COPY INTO {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{table_name}
    FROM @{SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{stage_name}/
    PATTERN = '{pattern}'
    FILE_FORMAT = (TYPE = PARQUET)
    MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
    ON_ERROR = CONTINUE
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql)

            # Busca resultado do COPY INTO
            result = cursor.fetchall()
            rows_loaded = 0

            if result:
                # O resultado inclui: file, status, rows_parsed, rows_loaded, etc
                for row in result:
                    if len(row) >= 4:
                        rows_loaded += row[3] if row[3] else 0

            logger.info(f"{table_name}: {rows_loaded} registros copiados para Snowflake")
            cursor.close()
            return rows_loaded

    except Exception as e:
        logger.error(f"Erro ao copiar dados para {table_name}: {e}")
        raise


def deletar_periodo(table_name: str, ano: int, mes: int) -> int:
    """
    Deleta dados de um periodo especifico da tabela.

    Usado antes de recarregar dados para evitar duplicacao.

    Args:
        table_name: Nome da tabela.
        ano: Ano de referencia.
        mes: Mes de referencia.

    Returns:
        Quantidade de registros deletados.
    """
    sql = f"""
    DELETE FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{table_name}
    WHERE _ano_cmp = {ano} AND _mes_cmp = {mes}
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            deleted = cursor.rowcount
            logger.info(f"{table_name}: {deleted} registros deletados ({mes:02d}/{ano})")
            cursor.close()
            return deleted

    except Exception as e:
        logger.error(f"Erro ao deletar periodo de {table_name}: {e}")
        return 0


def refresh_tabelas(ano: int = None, mes: int = None) -> Dict[str, int]:
    """
    Atualiza todas as tabelas RAW com dados do S3.

    Se ano/mes forem especificados, deleta dados do periodo antes
    de recarregar (evita duplicacao).

    Args:
        ano: Ano de referencia (opcional).
        mes: Mes de referencia (opcional).

    Returns:
        Dicionario com contagem de registros por tabela.
    """
    logger.info(f"Atualizando tabelas RAW (ano={ano}, mes={mes})...")
    resultado = {}

    for prefixo in PREFIXOS:
        table_name = f"raw_{prefixo.lower()}"

        # Deleta dados do periodo se especificado (evita duplicacao)
        if ano and mes:
            deletar_periodo(table_name, ano, mes)

        # Copia dados do S3 para tabela nativa
        rows = carregar_dados_s3(table_name, ano, mes)
        resultado[table_name] = rows

    logger.info(f"Tabelas atualizadas: {resultado}")
    return resultado


def contar_registros(table_name: str, ano: int = None, mes: int = None) -> int:
    """
    Conta registros em uma tabela.

    Args:
        table_name: Nome da tabela.
        ano: Filtrar por ano (opcional).
        mes: Filtrar por mes (opcional).

    Returns:
        Quantidade de registros.
    """
    where_clause = ""
    if ano and mes:
        where_clause = f"WHERE _ano_cmp = {ano} AND _mes_cmp = {mes}"
    elif ano:
        where_clause = f"WHERE _ano_cmp = {ano}"

    sql = f"""
    SELECT COUNT(*) FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{table_name}
    {where_clause}
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            result = cursor.fetchone()
            cursor.close()
            return result[0] if result else 0

    except Exception as e:
        logger.error(f"Erro ao contar registros de {table_name}: {e}")
        return 0
