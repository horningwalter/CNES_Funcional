"""
Modulo de conexao com Snowflake.

Gerencia a conexao e execucao de comandos SQL no Snowflake.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import logging
from contextlib import contextmanager
from typing import Optional, List, Any

import snowflake.connector
from snowflake.connector import SnowflakeConnection
from snowflake.connector.errors import Error as SnowflakeError

from config import (
    SNOWFLAKE_ACCOUNT,
    SNOWFLAKE_USER,
    SNOWFLAKE_PASSWORD,
    SNOWFLAKE_WAREHOUSE,
    SNOWFLAKE_DATABASE,
    SNOWFLAKE_SCHEMA,
    SNOWFLAKE_ROLE,
)

logger = logging.getLogger(__name__)


@contextmanager
def get_connection() -> SnowflakeConnection:
    """
    Context manager para conexao com Snowflake.

    Gerencia a abertura e fechamento da conexao automaticamente.
    Utiliza as credenciais definidas nas variaveis de ambiente.

    Yields:
        Conexao ativa com o Snowflake.

    Raises:
        SnowflakeError: Se ocorrer erro na conexao.

    Exemplo:
        >>> with get_connection() as conn:
        ...     cursor = conn.cursor()
        ...     cursor.execute("SELECT CURRENT_VERSION()")
    """
    conn = None
    try:
        # Parametros de conexao
        conn_params = {
            "account": SNOWFLAKE_ACCOUNT,
            "user": SNOWFLAKE_USER,
            "password": SNOWFLAKE_PASSWORD,
            "warehouse": SNOWFLAKE_WAREHOUSE,
            "database": SNOWFLAKE_DATABASE,
            "schema": SNOWFLAKE_SCHEMA,
        }

        # Adiciona role se configurado
        if SNOWFLAKE_ROLE:
            conn_params["role"] = SNOWFLAKE_ROLE

        conn = snowflake.connector.connect(**conn_params)
        logger.debug(f"Conexao estabelecida com Snowflake: {SNOWFLAKE_ACCOUNT}")
        yield conn

    except SnowflakeError as e:
        logger.error(f"Erro ao conectar no Snowflake: {e}")
        raise

    finally:
        if conn:
            conn.close()
            logger.debug("Conexao com Snowflake fechada")


def executar_sql(sql: str, params: Optional[tuple] = None) -> List[Any]:
    """
    Executa comando SQL no Snowflake.

    Args:
        sql: Comando SQL a ser executado.
        params: Parametros para substituicao no SQL (opcional).

    Returns:
        Lista com os resultados da query.

    Raises:
        SnowflakeError: Se ocorrer erro na execucao.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        try:
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)

            # Retorna resultados se for SELECT
            if cursor.description:
                return cursor.fetchall()
            return []

        finally:
            cursor.close()


def executar_multiplos_sql(sqls: List[str]) -> None:
    """
    Executa multiplos comandos SQL no Snowflake.

    Args:
        sqls: Lista de comandos SQL a serem executados.

    Raises:
        SnowflakeError: Se ocorrer erro na execucao.
    """
    with get_connection() as conn:
        cursor = conn.cursor()
        try:
            for sql in sqls:
                sql = sql.strip()
                if sql:
                    logger.debug(f"Executando: {sql[:100]}...")
                    cursor.execute(sql)
                    logger.debug("Comando executado com sucesso")

        finally:
            cursor.close()


def testar_conexao() -> bool:
    """
    Testa a conexao com o Snowflake.

    Returns:
        True se a conexao foi estabelecida com sucesso.

    Raises:
        SnowflakeError: Se ocorrer erro na conexao.
    """
    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT CURRENT_VERSION()")
            version = cursor.fetchone()[0]
            logger.info(f"Conexao Snowflake OK - Versao: {version}")
            cursor.close()
            return True

    except SnowflakeError as e:
        logger.error(f"Falha ao conectar no Snowflake: {e}")
        return False
