"""
Módulo de extração de dados do CNES via PySUS.
"""
import logging
from datetime import date, timedelta
from pysus import CNES
from config import PREFIXOS, UFS

logger = logging.getLogger(__name__)

def get_previous_month(ref_date: date = None) -> tuple[int, int]:
    """Retorna ano e mês anterior à data de referência."""
    ref = ref_date or date.today()
    first_day = ref.replace(day=1)
    last_month = first_day - timedelta(days=1)
    return last_month.year, last_month.month

def download_cnes(year: int, month: int, prefixos: list = None, ufs: list = None) -> dict:
    """Baixa dados do CNES para o período especificado."""
    prefixos = prefixos or PREFIXOS
    ufs = ufs or UFS
    cnes = CNES()
    result = {}
    
    for pref in prefixos:
        try:
            logger.info(f"Buscando {pref} para {month:02d}/{year}")
            files = cnes.get_files([pref], uf=ufs, year=year, month=[month])
            
            if not files:
                logger.warning(f"Nenhum arquivo encontrado para {pref}")
                continue
                
            # O download retorna um ParquetSet
            data = cnes.download(files)
            result[pref] = data
            logger.info(f"{pref}: Dados baixados com sucesso.")
            
        except Exception as e:
            logger.error(f"Erro ao baixar {pref}: {str(e)}", exc_info=True)
            continue
    
    return result
