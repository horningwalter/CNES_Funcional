"""
Configuracoes globais do projeto CNES ETL.

Este modulo centraliza todas as configuracoes do pipeline ETL,
incluindo paths locais, credenciais AWS S3 e Snowflake.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import os
from pathlib import Path

# =============================================================================
# PATHS LOCAIS
# =============================================================================

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"

# =============================================================================
# CONFIGURACOES AWS S3
# =============================================================================

S3_BUCKET = os.getenv("CNES_S3_BUCKET", "cnes-datalake")
S3_PREFIX = os.getenv("CNES_S3_PREFIX", "raw")
S3_REGION = os.getenv("AWS_REGION", "us-east-1")

# =============================================================================
# CONFIGURACOES SNOWFLAKE
# =============================================================================

SNOWFLAKE_ACCOUNT = os.getenv("SNOWFLAKE_ACCOUNT", "")
SNOWFLAKE_USER = os.getenv("SNOWFLAKE_USER", "")
SNOWFLAKE_PASSWORD = os.getenv("SNOWFLAKE_PASSWORD", "")
SNOWFLAKE_WAREHOUSE = os.getenv("SNOWFLAKE_WAREHOUSE", "COMPUTE_WH")
SNOWFLAKE_DATABASE = os.getenv("SNOWFLAKE_DATABASE", "CNES_DB")
SNOWFLAKE_SCHEMA = os.getenv("SNOWFLAKE_SCHEMA", "RAW")
SNOWFLAKE_ROLE = os.getenv("SNOWFLAKE_ROLE", "")

# =============================================================================
# PREFIXOS CNES
# =============================================================================

# Prefixos dos arquivos CNES a serem processados
PREFIXOS = ["ST", "SR", "EQ", "PF"]

# Descricao de cada prefixo para logs e documentacao
PREFIXO_DESCRICAO = {
    "ST": "Estabelecimentos",
    "SR": "Servicos Especializados",
    "EQ": "Equipamentos",
    "PF": "Profissionais",
}

# =============================================================================
# UNIDADES FEDERATIVAS
# =============================================================================

# Lista de siglas das UFs do Brasil
UFS = [
    "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA",
    "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN",
    "RO", "RR", "RS", "SC", "SE", "SP", "TO"
]

# Mapeamento: codigo IBGE -> (sigla, nome, regiao)
UF_MAP = {
    "11": ("RO", "Rondonia", "Norte"),
    "12": ("AC", "Acre", "Norte"),
    "13": ("AM", "Amazonas", "Norte"),
    "14": ("RR", "Roraima", "Norte"),
    "15": ("PA", "Para", "Norte"),
    "16": ("AP", "Amapa", "Norte"),
    "17": ("TO", "Tocantins", "Norte"),
    "21": ("MA", "Maranhao", "Nordeste"),
    "22": ("PI", "Piaui", "Nordeste"),
    "23": ("CE", "Ceara", "Nordeste"),
    "24": ("RN", "Rio Grande do Norte", "Nordeste"),
    "25": ("PB", "Paraiba", "Nordeste"),
    "26": ("PE", "Pernambuco", "Nordeste"),
    "27": ("AL", "Alagoas", "Nordeste"),
    "28": ("SE", "Sergipe", "Nordeste"),
    "29": ("BA", "Bahia", "Nordeste"),
    "31": ("MG", "Minas Gerais", "Sudeste"),
    "32": ("ES", "Espirito Santo", "Sudeste"),
    "33": ("RJ", "Rio de Janeiro", "Sudeste"),
    "35": ("SP", "Sao Paulo", "Sudeste"),
    "41": ("PR", "Parana", "Sul"),
    "42": ("SC", "Santa Catarina", "Sul"),
    "43": ("RS", "Rio Grande do Sul", "Sul"),
    "50": ("MS", "Mato Grosso do Sul", "Centro-Oeste"),
    "51": ("MT", "Mato Grosso", "Centro-Oeste"),
    "52": ("GO", "Goias", "Centro-Oeste"),
    "53": ("DF", "Distrito Federal", "Centro-Oeste")
}

# Atalhos para acesso rapido
UF_CODIGO_SIGLA = {k: v[0] for k, v in UF_MAP.items()}
UF_CODIGO_NOME = {k: v[1] for k, v in UF_MAP.items()}
UF_CODIGO_REGIAO = {k: v[2] for k, v in UF_MAP.items()}
