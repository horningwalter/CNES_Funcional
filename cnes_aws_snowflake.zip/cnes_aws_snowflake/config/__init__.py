"""
Modulo de configuracao do pipeline CNES.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
from .settings import *
from .dominios import *
