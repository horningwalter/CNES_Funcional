"""
Modulo de armazenamento S3 para dados CNES.

Gerencia o armazenamento de arquivos Parquet no Amazon S3.
Os dados sao organizados em estrutura particionada por ano/mes.

Estrutura de armazenamento:
    s3://{bucket}/{prefix}/{tabela}/ano={ano}/mes={mes}/{tabela}_{ano}{mes}.parquet

Exemplo:
    s3://cnes-datalake/raw/raw_st/ano=2024/mes=01/raw_st_202401.parquet

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import logging
from datetime import datetime
from io import BytesIO
from typing import List, Dict, Optional

import boto3
import polars as pl
from botocore.exceptions import ClientError

from config import S3_BUCKET, S3_PREFIX, S3_REGION

logger = logging.getLogger(__name__)

# Cliente S3 com inicializacao lazy
_s3_client = None


def _get_s3_client():
    """
    Retorna cliente S3 com inicializacao lazy.

    O cliente e criado apenas na primeira chamada e reutilizado
    nas chamadas subsequentes para melhor performance.

    Returns:
        Cliente boto3 S3 configurado.
    """
    global _s3_client
    if _s3_client is None:
        _s3_client = boto3.client("s3", region_name=S3_REGION)
        logger.debug(f"Cliente S3 inicializado para regiao {S3_REGION}")
    return _s3_client


def get_s3_path(table: str, ano: int, mes: int) -> str:
    """
    Gera o path S3 para um arquivo de tabela/periodo.

    O path segue o padrao de particionamento Hive para facilitar
    consultas otimizadas no Snowflake e outras ferramentas.

    Args:
        table: Nome da tabela (ex: raw_st).
        ano: Ano de referencia.
        mes: Mes de referencia.

    Returns:
        Path S3 no formato: {prefix}/{table}/ano={ano}/mes={mes:02d}/{table}_{ano}{mes:02d}.parquet
    """
    return f"{S3_PREFIX}/{table}/ano={ano}/mes={mes:02d}/{table}_{ano}{mes:02d}.parquet"


def get_s3_url(table: str, ano: Optional[int] = None, mes: Optional[int] = None) -> str:
    """
    Gera URL S3 completa para leitura de dados.

    Args:
        table: Nome da tabela (ex: raw_st).
        ano: Ano de referencia (opcional).
        mes: Mes de referencia (opcional).

    Returns:
        URL S3 completa. Se ano/mes nao forem informados, retorna
        pattern para todos os arquivos da tabela.
    """
    if ano is None or mes is None:
        # Retorna pattern para todos os arquivos da tabela
        return f"s3://{S3_BUCKET}/{S3_PREFIX}/{table}/"
    else:
        path = get_s3_path(table, ano, mes)
        return f"s3://{S3_BUCKET}/{path}"


def salvar_parquet_s3(df: pl.DataFrame, table: str, ano: int, mes: int) -> int:
    """
    Salva DataFrame Polars como Parquet no S3.

    Adiciona colunas de controle (_ano_cmp, _mes_cmp, _data_carga) ao
    DataFrame antes de salvar. Utiliza compressao Snappy para otimizar
    espaco e performance de leitura.

    Args:
        df: DataFrame Polars a ser salvo.
        table: Nome da tabela (ex: raw_st).
        ano: Ano de referencia.
        mes: Mes de referencia.

    Returns:
        Quantidade de registros salvos.

    Raises:
        ClientError: Se ocorrer erro na comunicacao com o S3.
    """
    if df.is_empty():
        logger.warning(f"DataFrame vazio para {table}, nenhum dado salvo")
        return 0

    # Adiciona colunas de controle para rastreabilidade
    df = df.with_columns([
        pl.lit(ano).alias("_ano_cmp"),
        pl.lit(mes).alias("_mes_cmp"),
        pl.lit(datetime.now().isoformat()).alias("_data_carga")
    ])

    # Gera path S3
    s3_path = get_s3_path(table, ano, mes)

    try:
        s3_client = _get_s3_client()

        # Serializa DataFrame para Parquet em memoria
        buffer = BytesIO()
        df.write_parquet(buffer, compression="snappy")
        buffer.seek(0)

        # Upload para S3
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=s3_path,
            Body=buffer.getvalue(),
            ContentType="application/octet-stream"
        )

        count = len(df)
        logger.info(f"{table}: {count} registros salvos em s3://{S3_BUCKET}/{s3_path}")
        return count

    except ClientError as e:
        logger.error(f"Erro ao salvar {table} no S3: {e}", exc_info=True)
        raise


def listar_arquivos_s3(table: str, ano: Optional[int] = None) -> List[Dict]:
    """
    Lista arquivos Parquet de uma tabela no S3.

    Args:
        table: Nome da tabela (ex: raw_st).
        ano: Filtrar por ano (opcional).

    Returns:
        Lista de dicionarios com informacoes dos arquivos:
        - key: Caminho completo do arquivo no S3.
        - size: Tamanho em bytes.
        - last_modified: Data/hora da ultima modificacao.
    """
    s3_client = _get_s3_client()

    # Monta prefixo de busca
    prefix = f"{S3_PREFIX}/{table}/"
    if ano:
        prefix += f"ano={ano}/"

    try:
        paginator = s3_client.get_paginator("list_objects_v2")
        arquivos = []

        for page in paginator.paginate(Bucket=S3_BUCKET, Prefix=prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith(".parquet"):
                    arquivos.append({
                        "key": obj["Key"],
                        "size": obj["Size"],
                        "last_modified": obj["LastModified"]
                    })

        logger.debug(f"Encontrados {len(arquivos)} arquivos para {table}")
        return arquivos

    except ClientError as e:
        logger.error(f"Erro ao listar arquivos S3: {e}")
        return []


def arquivo_existe_s3(table: str, ano: int, mes: int) -> bool:
    """
    Verifica se arquivo Parquet existe no S3.

    Args:
        table: Nome da tabela.
        ano: Ano de referencia.
        mes: Mes de referencia.

    Returns:
        True se o arquivo existe, False caso contrario.
    """
    s3_client = _get_s3_client()
    s3_path = get_s3_path(table, ano, mes)

    try:
        s3_client.head_object(Bucket=S3_BUCKET, Key=s3_path)
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "404":
            return False
        logger.error(f"Erro ao verificar arquivo S3: {e}")
        raise


def deletar_arquivo_s3(table: str, ano: int, mes: int) -> bool:
    """
    Deleta arquivo Parquet do S3.

    Args:
        table: Nome da tabela.
        ano: Ano de referencia.
        mes: Mes de referencia.

    Returns:
        True se deletado com sucesso, False caso contrario.
    """
    s3_client = _get_s3_client()
    s3_path = get_s3_path(table, ano, mes)

    try:
        s3_client.delete_object(Bucket=S3_BUCKET, Key=s3_path)
        logger.info(f"Arquivo deletado: s3://{S3_BUCKET}/{s3_path}")
        return True
    except ClientError as e:
        logger.error(f"Erro ao deletar arquivo S3: {e}")
        return False
