"""
Modulo de armazenamento S3 para dados CNES.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
from .s3 import (
    salvar_parquet_s3,
    listar_arquivos_s3,
    arquivo_existe_s3,
    deletar_arquivo_s3,
    get_s3_path,
    get_s3_url,
)
