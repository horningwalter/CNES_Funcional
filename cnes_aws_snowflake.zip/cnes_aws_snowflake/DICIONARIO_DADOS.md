# Dicionario de Dados - CNES ETL Pipeline

## Informacoes do Projeto

| Item | Descricao |
|------|-----------|
| **Desenvolvido por** | triggo.ai |
| **Consultor** | Walter Jose Horning Junior |
| **Contato** | walter.junior@triggo.ai |
| **Versao** | 2.0 |
| **Data** | Janeiro/2026 |

---

## Indice

1. [Visao Geral](#visao-geral)
2. [Arquitetura de Dados](#arquitetura-de-dados)
3. [Schema RAW - Tabelas Nativas](#schema-raw---tabelas-nativas)
   - [raw_st - Estabelecimentos](#raw_st---estabelecimentos)
   - [raw_pf - Profissionais](#raw_pf---profissionais)
   - [raw_eq - Equipamentos](#raw_eq---equipamentos)
   - [raw_sr - Servicos](#raw_sr---servicos)
   - [execucao_controle - Auditoria](#execucao_controle---auditoria)
4. [Schema SEMANTIC - Views Analiticas](#schema-semantic---views-analiticas)
   - [sv_cnes_analise - Semantic View Principal](#sv_cnes_analise---semantic-view-principal)
   - [Views Fato](#views-fato)
   - [Views Agregadas por UF](#views-agregadas-por-uf)
5. [Dominios e Codificacoes](#dominios-e-codificacoes)
6. [Relacionamentos](#relacionamentos)

---

## Visao Geral

Este dicionario documenta a estrutura de dados do pipeline CNES no Snowflake, incluindo:

- **4 tabelas nativas** no schema RAW (dados copiados do S3)
- **1 Semantic View** para modelo dimensional
- **4 views fato** para analise detalhada
- **4 views agregadas** por UF

### Fluxo de Dados

```
DATASUS (.dbc) → PySUS → Polars → S3 (Parquet) → COPY INTO → Snowflake RAW → Semantic Views
```

### Schemas Snowflake

| Schema | Proposito | Objetos |
|--------|-----------|---------|
| `CNES_DB.RAW` | Dados brutos (tabelas nativas) | raw_st, raw_pf, raw_eq, raw_sr, execucao_controle |
| `CNES_DB.SEMANTIC` | Modelo analitico | sv_cnes_analise, fato_*, vw_*_uf |

---

## Arquitetura de Dados

### Campos de Controle (Comum a Todas as Tabelas RAW)

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `_ano_cmp` | INTEGER | Ano de competencia (ex: 2024) |
| `_mes_cmp` | INTEGER | Mes de competencia (1-12) |
| `_data_carga` | VARCHAR | Data/hora da carga no formato ISO |

### Chaves de Relacionamento

| Campo | Tipo | Descricao | Presente em |
|-------|------|-----------|-------------|
| `cnes` | VARCHAR | Codigo CNES do estabelecimento (7 digitos) | Todas |
| `codufmun` | VARCHAR | Codigo IBGE do municipio (7 digitos) | Todas |

---

## Schema RAW - Tabelas Nativas

### raw_st - Estabelecimentos

**Descricao**: Cadastro de estabelecimentos de saude do Brasil.

**Granularidade**: Um registro por estabelecimento por periodo (ano/mes).

**Fonte DATASUS**: Arquivo STAAMM.dbc

#### Campos de Identificacao

| Campo | Tipo | Descricao | Exemplo |
|-------|------|-----------|---------|
| `cnes` | VARCHAR | Codigo CNES do estabelecimento | "2077485" |
| `codufmun` | VARCHAR | Codigo IBGE do municipio | "3550308" |
| `cpf_cnpj` | VARCHAR | CPF ou CNPJ do responsavel | "12345678901234" |
| `cnpj_man` | VARCHAR | CNPJ da entidade mantenedora | "12345678000199" |
| `cod_cep` | VARCHAR | CEP do endereco | "01310100" |

#### Campos de Classificacao

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `pfpj` | VARCHAR | Tipo de pessoa | 1=Fisica, 3=Juridica |
| `nivel_dep` | VARCHAR | Nivel de dependencia | 1=Individual, 3=Mantida |
| `tp_unid` | VARCHAR | Tipo de unidade | Ver [Tipo de Unidade](#tipo-de-unidade) |
| `nat_jur` | VARCHAR | Natureza juridica (codigo completo) | Ver [Natureza Juridica](#natureza-juridica) |
| `natureza` | VARCHAR | Natureza organizacional | 01-13 |
| `tpgestao` | VARCHAR | Tipo de gestao | D=Dupla, E=Estadual, M=Municipal |
| `esfera_a` | VARCHAR | Esfera administrativa | 01=Federal, 02=Estadual, 03=Municipal, 04=Privada |
| `niv_hier` | VARCHAR | Nivel de hierarquia | 01=Atencao Basica, 03=Media, 08=Alta |
| `tp_prest` | VARCHAR | Tipo de prestador | 20=Privado, 30/40/50=Publico, 60=Filantropico |
| `clientel` | VARCHAR | Tipo de clientela | 1=Espontanea, 2=Referenciada, 3=Ambas |
| `turno_at` | VARCHAR | Turno de atendimento | Ver [Turno de Atendimento](#turno-de-atendimento) |
| `atividad` | VARCHAR | Atividade de ensino | 01=Universitaria, 05=Hospital Ensino |
| `retencao` | VARCHAR | Retencao de tributos | - |
| `cod_ir` | VARCHAR | Codigo IR | - |

#### Campos SUS e Financeiros

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `vinc_sus` | VARCHAR | Vinculado ao SUS | 0=Nao, 1=Sim |
| `co_banco` | VARCHAR | Codigo do banco | - |
| `co_agenc` | VARCHAR | Codigo da agencia | - |
| `c_corren` | VARCHAR | Conta corrente | - |

#### Campos de Licenciamento

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `contession` | VARCHAR | Concessao |
| `alvession` | VARCHAR | Alvara |
| `licession` | VARCHAR | Licenca |

---

### raw_pf - Profissionais

**Descricao**: Vinculos de profissionais de saude nos estabelecimentos.

**Granularidade**: Um registro por vinculo profissional por estabelecimento por periodo.

**Fonte DATASUS**: Arquivo PFAAMM.dbc

#### Campos de Identificacao

| Campo | Tipo | Descricao | Exemplo |
|-------|------|-----------|---------|
| `cnes` | VARCHAR | Codigo CNES do estabelecimento | "2077485" |
| `codufmun` | VARCHAR | Codigo IBGE do municipio | "3550308" |
| `cns_prof` | VARCHAR | Cartao Nacional de Saude do profissional | "700000000000000" |
| `cpf_prof` | VARCHAR | CPF do profissional | "12345678901" |
| `nomeprof` | VARCHAR | Nome do profissional | "JOAO SILVA" |

#### Campos de Classificacao Profissional

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `cbo` | VARCHAR | Codigo CBO (Classificacao Brasileira de Ocupacoes) | Ver [CBO](#cbo---classificacao-brasileira-de-ocupacoes) |
| `cbounico` | VARCHAR | CBO unico do profissional | - |
| `conselho` | VARCHAR | Codigo do conselho profissional | Ver [Conselho Profissional](#conselho-profissional) |
| `registro` | VARCHAR | Numero do registro no conselho | - |

#### Campos de Vinculo

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `vinculac` | VARCHAR | Tipo de vinculo principal | Ver [Tipo de Vinculo](#tipo-de-vinculo) |
| `vincul_c` | VARCHAR | Vinculo contratado | 0=Nao, 1=Sim |
| `vincul_a` | VARCHAR | Vinculo autonomo | 0=Nao, 1=Sim |
| `vincul_n` | VARCHAR | Vinculo nao aplicavel | 0=Nao, 1=Sim |
| `prof_sus` | VARCHAR | Atende pelo SUS | 0=Nao, 1=Sim |
| `profnsus` | VARCHAR | Atende nao-SUS | 0=Nao, 1=Sim |

#### Campos de Carga Horaria

| Campo | Tipo | Descricao | Unidade |
|-------|------|-----------|---------|
| `hora_amb` | VARCHAR | Carga horaria ambulatorial | Horas/semana |
| `horahosp` | VARCHAR | Carga horaria hospitalar | Horas/semana |
| `horaoutr` | VARCHAR | Carga horaria outros vinculos | Horas/semana |
| `hoession` | VARCHAR | Carga horaria SES | Horas/semana |

---

### raw_eq - Equipamentos

**Descricao**: Equipamentos medicos e hospitalares nos estabelecimentos.

**Granularidade**: Um registro por tipo de equipamento por estabelecimento por periodo.

**Fonte DATASUS**: Arquivo EQAAMM.dbc

#### Campos de Identificacao

| Campo | Tipo | Descricao | Exemplo |
|-------|------|-----------|---------|
| `cnes` | VARCHAR | Codigo CNES do estabelecimento | "2077485" |
| `codufmun` | VARCHAR | Codigo IBGE do municipio | "3550308" |

#### Campos de Classificacao

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `tipequip` | VARCHAR | Tipo de equipamento | Ver [Tipo de Equipamento](#tipo-de-equipamento) |
| `codequip` | VARCHAR | Codigo especifico do equipamento | Ver [Codigo de Equipamento](#codigo-de-equipamento) |

#### Campos Quantitativos

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `qt_exist` | VARCHAR | Quantidade de equipamentos existentes |
| `qt_uso` | VARCHAR | Quantidade de equipamentos em uso |

#### Campos de Disponibilidade

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `ind_sus` | VARCHAR | Disponivel para SUS | 0=Nao, 1=Sim |
| `ind_nsus` | VARCHAR | Disponivel para nao-SUS | 0=Nao, 1=Sim |

---

### raw_sr - Servicos

**Descricao**: Servicos especializados oferecidos pelos estabelecimentos.

**Granularidade**: Um registro por servico por estabelecimento por periodo.

**Fonte DATASUS**: Arquivo SRAAMM.dbc

#### Campos de Identificacao

| Campo | Tipo | Descricao | Exemplo |
|-------|------|-----------|---------|
| `cnes` | VARCHAR | Codigo CNES do estabelecimento | "2077485" |
| `codufmun` | VARCHAR | Codigo IBGE do municipio | "3550308" |

#### Campos de Classificacao

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `serv_esp` | VARCHAR | Codigo do servico especializado | Ver [Servico Especializado](#servico-especializado) |
| `class_sr` | VARCHAR | Classificacao do servico | - |
| `session` | VARCHAR | Terceiros | - |
| `caression` | VARCHAR | Caracterizacao | - |

#### Campos de Modalidade SUS

| Campo | Tipo | Descricao | Dominio |
|-------|------|-----------|---------|
| `amb_sus` | VARCHAR | Ambulatorial SUS | 0=Nao, 1=Sim |
| `amb_nsus` | VARCHAR | Ambulatorial nao-SUS | 0=Nao, 1=Sim |
| `hosp_sus` | VARCHAR | Hospitalar SUS | 0=Nao, 1=Sim |
| `hosp_nsus` | VARCHAR | Hospitalar nao-SUS | 0=Nao, 1=Sim |

---

### execucao_controle - Auditoria

**Descricao**: Tabela de controle de execucoes do pipeline ETL.

**Schema**: CNES_DB.RAW

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `id` | INTEGER | ID da execucao (autoincrement) |
| `ano` | INTEGER | Ano processado |
| `mes` | INTEGER | Mes processado |
| `prefixo` | VARCHAR | Prefixo CNES (ST, PF, EQ, SR) |
| `qtd_registros` | INTEGER | Quantidade de registros processados |
| `iniciado_em` | TIMESTAMP_NTZ | Data/hora de inicio |
| `finalizado_em` | TIMESTAMP_NTZ | Data/hora de termino |
| `status` | VARCHAR | Status da execucao |

**Status possiveis**: EXECUTANDO, SUCESSO, ERRO, SEM_DADOS

---

## Schema SEMANTIC - Views Analiticas

### sv_cnes_analise - Semantic View Principal

**Descricao**: Semantic View que define o modelo dimensional completo do CNES.

**Tipo**: Snowflake Semantic View

#### Entidades (Tabelas Logicas)

| Entidade | Tabela Fisica | Chave Primaria |
|----------|---------------|----------------|
| `estabelecimento` | raw_st | (cnes, _ano_cmp, _mes_cmp) |
| `profissional` | raw_pf | (cnes, cns_prof, cbo, _ano_cmp, _mes_cmp) |
| `equipamento` | raw_eq | (cnes, codequip, _ano_cmp, _mes_cmp) |
| `servico` | raw_sr | (cnes, serv_esp, _ano_cmp, _mes_cmp) |

#### Relacionamentos

```
profissional  ──┐
                │
equipamento   ──┼──> estabelecimento
                │
servico       ──┘
```

Todos os relacionamentos sao via (cnes, _ano_cmp, _mes_cmp).

#### Dimensoes Disponiveis

| Dimensao | Origem | Descricao |
|----------|--------|-----------|
| `ano` | estabelecimento._ano_cmp | Ano de competencia |
| `mes` | estabelecimento._mes_cmp | Mes de competencia |
| `cod_municipio` | estabelecimento.codufmun | Codigo IBGE do municipio |
| `cod_uf` | SUBSTR(codufmun, 1, 2) | Codigo da UF |
| `cod_tipo_unidade` | estabelecimento.tp_unid | Codigo do tipo de unidade |
| `desc_tipo_unidade` | CASE tp_unid | Descricao do tipo de unidade |
| `cod_natureza_juridica` | estabelecimento.nat_jur | Codigo da natureza juridica |
| `setor` | CASE nat_jur | Publico/Privado/Filantropico |
| `vinculo_sus` | CASE vinc_sus | Sim/Nao |
| `cod_turno_atendimento` | estabelecimento.turno_at | Codigo do turno |
| `desc_turno_atendimento` | CASE turno_at | Descricao do turno |
| `cod_clientela` | estabelecimento.clientel | Codigo da clientela |
| `desc_clientela` | CASE clientel | Descricao da clientela |
| `cod_atividade` | estabelecimento.atividad | Codigo de atividade ensino |
| `cod_cbo` | profissional.cbo | Codigo CBO |
| `cod_cbo_unico` | profissional.cbounico | Codigo CBO unico |
| `cod_conselho` | profissional.conselho | Codigo do conselho |
| `desc_conselho` | CASE conselho | Nome do conselho |
| `cod_tipo_vinculo` | profissional.vinculac | Codigo tipo vinculo |
| `profissional_sus` | CASE prof_sus | Sim/Nao |
| `categoria_profissional` | CASE cbo | Categoria agregada |
| `tipo_equipamento` | equipamento.tipequip | Tipo de equipamento |
| `cod_equipamento` | equipamento.codequip | Codigo do equipamento |
| `equipamento_sus` | CASE ind_sus | Sim/Nao |
| `cod_servico` | servico.serv_esp | Codigo do servico |
| `classificacao_servico` | servico.class_sr | Classificacao |
| `servico_sus` | CASE amb_sus/hosp_sus | Sim/Nao |
| `ambulatorial_sus` | CASE amb_sus | Sim/Nao |
| `hospitalar_sus` | CASE hosp_sus | Sim/Nao |

#### Metricas Disponiveis

| Metrica | Descricao | Formula |
|---------|-----------|---------|
| `qtd_estabelecimentos` | Total de estabelecimentos | COUNT(DISTINCT cnes) |
| `qtd_estabelecimentos_sus` | Estabelecimentos SUS | COUNT(DISTINCT cnes WHERE vinc_sus='1') |
| `qtd_profissionais` | Profissionais unicos | COUNT(DISTINCT cns_prof) |
| `qtd_vinculos_profissionais` | Total de vinculos | COUNT(*) |
| `carga_horaria_ambulatorial` | Horas ambulatoriais | SUM(hora_amb) |
| `carga_horaria_hospitalar` | Horas hospitalares | SUM(horahosp) |
| `carga_horaria_outros` | Horas outros | SUM(horaoutr) |
| `qtd_equipamentos_existentes` | Equipamentos existentes | SUM(qt_exist) |
| `qtd_equipamentos_em_uso` | Equipamentos em uso | SUM(qt_uso) |
| `qtd_equipamentos_sus` | Equipamentos SUS | SUM(qt_uso WHERE ind_sus='1') |
| `qtd_servicos_distintos` | Tipos de servicos | COUNT(DISTINCT serv_esp) |
| `qtd_ofertas_servico` | Ofertas totais | COUNT(*) |
| `qtd_ofertas_servico_sus` | Ofertas SUS | COUNT WHERE amb_sus='1' OR hosp_sus='1' |
| `qtd_medicos` | Total de medicos | COUNT(DISTINCT WHERE CBO 2231/2251/2252/2253) |
| `qtd_enfermeiros` | Total de enfermeiros | COUNT(DISTINCT WHERE CBO 2235) |
| `qtd_tecnicos_enfermagem` | Tecnicos/Aux enfermagem | COUNT(DISTINCT WHERE CBO 3222) |
| `qtd_dentistas` | Total de dentistas | COUNT(DISTINCT WHERE CBO 2232) |
| `qtd_acs` | Agentes comunitarios | COUNT(DISTINCT WHERE CBO 5151) |
| `taxa_utilizacao_equipamentos` | Taxa de uso (%) | (qt_uso / qt_exist) * 100 |

---

### Views Fato

#### fato_estabelecimento

**Descricao**: View detalhada de estabelecimentos para analise.

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `data_carga` | VARCHAR | Data/hora da carga |
| `cod_uf` | VARCHAR | Codigo UF (2 digitos) |
| `cod_municipio` | VARCHAR | Codigo municipio IBGE |
| `cod_cep` | VARCHAR | CEP do estabelecimento |
| `cnes` | VARCHAR | Codigo CNES |
| `pessoa_fisica_juridica` | VARCHAR | Tipo de pessoa |
| `nivel_dependencia` | VARCHAR | Nivel de dependencia |
| `cod_tipo_unidade` | VARCHAR | Tipo de unidade |
| `cod_natureza_juridica` | VARCHAR | Natureza juridica |
| `cod_natureza` | VARCHAR | Natureza organizacional |
| `vinc_sus` | VARCHAR | Vinculo SUS (0/1) |
| `tipo_gestao` | VARCHAR | Tipo de gestao |
| `esfera_administrativa` | VARCHAR | Esfera administrativa |
| `retencao_tributos` | VARCHAR | Retencao tributos |
| `cod_atividade` | VARCHAR | Atividade de ensino |
| `cod_clientela` | VARCHAR | Tipo de clientela |
| `turno_atendimento` | VARCHAR | Turno de atendimento |
| `nivel_hierarquia` | VARCHAR | Nivel de hierarquia |
| `tipo_prestador` | VARCHAR | Tipo de prestador |

---

#### fato_profissional

**Descricao**: View detalhada de profissionais para analise.

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `data_carga` | VARCHAR | Data/hora da carga |
| `cod_uf` | VARCHAR | Codigo UF (2 digitos) |
| `cod_municipio` | VARCHAR | Codigo municipio IBGE |
| `cnes` | VARCHAR | Codigo CNES |
| `cns_prof` | VARCHAR | CNS do profissional |
| `nome_profissional` | VARCHAR | Nome do profissional |
| `cod_cbo` | VARCHAR | Codigo CBO |
| `cod_cbo_unico` | VARCHAR | Codigo CBO unico |
| `cod_conselho` | VARCHAR | Codigo do conselho |
| `num_registro_conselho` | VARCHAR | Numero do registro |
| `tipo_vinculo` | VARCHAR | Tipo de vinculo |
| `vinculo_contratado` | VARCHAR | Vinculo contratado (0/1) |
| `vinculo_autonomo` | VARCHAR | Vinculo autonomo (0/1) |
| `vinculo_nao_aplicavel` | VARCHAR | Nao aplicavel (0/1) |
| `vinculo_sus` | VARCHAR | Atende SUS (0/1) |
| `vinculo_nao_sus` | VARCHAR | Atende nao-SUS (0/1) |
| `carga_horaria_ambulatorial` | INTEGER | CH ambulatorial |
| `carga_horaria_hospitalar` | INTEGER | CH hospitalar |
| `carga_horaria_outros` | INTEGER | CH outros |
| `carga_horaria_ses` | INTEGER | CH SES |
| `carga_horaria_total` | INTEGER | CH total (calculado) |

---

#### fato_equipamento

**Descricao**: View detalhada de equipamentos para analise.

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `data_carga` | VARCHAR | Data/hora da carga |
| `cod_uf` | VARCHAR | Codigo UF (2 digitos) |
| `cod_municipio` | VARCHAR | Codigo municipio IBGE |
| `cnes` | VARCHAR | Codigo CNES |
| `tipo_equipamento` | VARCHAR | Tipo de equipamento |
| `cod_equipamento` | VARCHAR | Codigo do equipamento |
| `qtd_existente` | INTEGER | Quantidade existente |
| `qtd_em_uso` | INTEGER | Quantidade em uso |
| `qtd_disponivel` | INTEGER | Disponivel (existente - uso) |
| `disponivel_sus` | VARCHAR | Disponivel SUS (0/1) |
| `disponivel_nao_sus` | VARCHAR | Disponivel nao-SUS (0/1) |

---

#### fato_servico

**Descricao**: View detalhada de servicos para analise.

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `data_carga` | VARCHAR | Data/hora da carga |
| `cod_uf` | VARCHAR | Codigo UF (2 digitos) |
| `cod_municipio` | VARCHAR | Codigo municipio IBGE |
| `cnes` | VARCHAR | Codigo CNES |
| `cod_servico` | VARCHAR | Codigo do servico |
| `classificacao_servico` | VARCHAR | Classificacao |
| `terceiros` | VARCHAR | Terceiros |
| `caracterizacao` | VARCHAR | Caracterizacao |
| `ambulatorial_sus` | VARCHAR | Ambulatorial SUS (0/1) |
| `ambulatorial_nao_sus` | VARCHAR | Ambulatorial nao-SUS (0/1) |
| `hospitalar_sus` | VARCHAR | Hospitalar SUS (0/1) |
| `hospitalar_nao_sus` | VARCHAR | Hospitalar nao-SUS (0/1) |
| `atende_sus` | VARCHAR | Atende SUS (calculado) |

---

### Views Agregadas por UF

#### vw_estabelecimentos_uf

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `cod_uf` | VARCHAR | Codigo UF |
| `qtd_estabelecimentos` | INTEGER | Total de estabelecimentos |
| `qtd_sus` | INTEGER | Estabelecimentos SUS |

---

#### vw_profissionais_uf

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `cod_uf` | VARCHAR | Codigo UF |
| `qtd_profissionais` | INTEGER | Profissionais unicos |
| `qtd_vinculos` | INTEGER | Total de vinculos |
| `carga_horaria_total` | INTEGER | CH total |

---

#### vw_equipamentos_uf

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `cod_uf` | VARCHAR | Codigo UF |
| `qtd_existente` | INTEGER | Equipamentos existentes |
| `qtd_em_uso` | INTEGER | Equipamentos em uso |
| `qtd_sus` | INTEGER | Equipamentos SUS |

---

#### vw_servicos_uf

| Campo | Tipo | Descricao |
|-------|------|-----------|
| `ano` | INTEGER | Ano de competencia |
| `mes` | INTEGER | Mes de competencia |
| `cod_uf` | VARCHAR | Codigo UF |
| `qtd_tipos_servico` | INTEGER | Tipos de servico |
| `qtd_ofertas` | INTEGER | Total de ofertas |
| `qtd_estabelecimentos` | INTEGER | Estabelecimentos com servico |
| `qtd_amb_sus` | INTEGER | Ambulatorial SUS |
| `qtd_hosp_sus` | INTEGER | Hospitalar SUS |

---

## Dominios e Codificacoes

### Tipo de Unidade

| Codigo | Descricao |
|--------|-----------|
| 01 | Posto de Saude |
| 02 | Centro de Saude/Unidade Basica |
| 04 | Policlinica |
| 05 | Hospital Geral |
| 07 | Hospital Especializado |
| 15 | Unidade Mista |
| 20 | Pronto Socorro Geral |
| 21 | Pronto Socorro Especializado |
| 22 | Consultorio Isolado |
| 36 | Clinica/Centro de Especialidade |
| 39 | Unidade de Apoio Diagnose e Terapia |
| 40 | Unidade Movel Terrestre |
| 42 | Unidade Movel Pre-Hospitalar Urgencia |
| 43 | Farmacia |
| 61 | Centro de Parto Normal |
| 62 | Hospital/Dia |
| 69 | Centro Hemoterapia/Hematologica |
| 70 | Centro de Atencao Psicossocial |
| 71 | Centro de Apoio a Saude da Familia |
| 72 | Unidade de Atencao a Saude Indigena |
| 73 | Pronto Atendimento |
| 74 | Polo Academia da Saude |
| 77 | Home Care |
| 80 | Laboratorio de Saude Publica |

---

### Natureza Juridica

| Prefixo | Setor | Exemplos |
|---------|-------|----------|
| 1xxx | Administracao Publica | Federal, Estadual, Municipal |
| 2011, 2038 | Empresa Publica | - |
| 2xxx | Entidade Empresarial | S.A., Ltda |
| 3xxx | Entidade sem Fins Lucrativos | Fundacao, Associacao |
| 4xxx | Pessoa Fisica | - |

---

### Turno de Atendimento

| Codigo | Descricao |
|--------|-----------|
| 1 | Manha |
| 2 | Tarde |
| 3 | Manha e Tarde |
| 4 | Noite |
| 5 | Manha, Tarde e Noite |
| 6 | Continuo 24h |

---

### Clientela

| Codigo | Descricao |
|--------|-----------|
| 1 | Atendimento de demanda espontanea |
| 2 | Atendimento de demanda referenciada |
| 3 | Atendimento de demanda espontanea e referenciada |

---

### Conselho Profissional

| Codigo | Sigla | Nome |
|--------|-------|------|
| 01 | CRM | Conselho Regional de Medicina |
| 02 | COREN | Conselho Regional de Enfermagem |
| 03 | CRO | Conselho Regional de Odontologia |
| 04 | CRF | Conselho Regional de Farmacia |
| 05 | CREFITO | Conselho Regional de Fisioterapia |
| 06 | CRN | Conselho Regional de Nutricao |
| 07 | CRP | Conselho Regional de Psicologia |
| 08 | CRESS | Conselho Regional de Servico Social |
| 09 | CRBM | Conselho Regional de Biomedicina |
| 10 | CREFONO | Conselho Regional de Fonoaudiologia |
| 11 | CRBio | Conselho Regional de Biologia |

---

### Tipo de Vinculo

| Codigo | Descricao |
|--------|-----------|
| 01 | Vinculo empregaticio |
| 02 | Autonomo |
| 03 | Bolsa |
| 04 | Residencia medica |
| 05 | Estagio |
| 06 | Cooperativa |
| 07 | Cedido |
| 08 | Contrato |

---

### CBO - Classificacao Brasileira de Ocupacoes

| Prefixo CBO | Categoria Profissional |
|-------------|------------------------|
| 2231* | Medico |
| 2251*, 2252*, 2253* | Medico Especialista |
| 2235* | Enfermeiro |
| 3222* | Tecnico/Auxiliar de Enfermagem |
| 2232* | Cirurgiao Dentista |
| 3224* | Tecnico de Saude Bucal |
| 2234* | Farmaceutico |
| 2236* | Fisioterapeuta |
| 2237* | Nutricionista |
| 2238* | Fonoaudiologo |
| 2239* | Terapeuta Ocupacional |
| 2515* | Psicologo |
| 2516* | Assistente Social |
| 5151* | Agente Comunitario de Saude |
| 3241* | Tecnico de Radiologia |
| 3242* | Tecnico de Patologia Clinica |

---

### Tipo de Equipamento

| Codigo | Descricao |
|--------|-----------|
| 01 | Diagnostico por Imagem |
| 02 | Infraestrutura |
| 03 | Metodos Opticos |
| 04 | Metodos Graficos |
| 05 | Manutencao da Vida |
| 06 | Odontologia |
| 07 | Outros |

---

### Codigo de Equipamento (Principais)

| Codigo | Descricao |
|--------|-----------|
| 10006 | Tomografo Computadorizado |
| 10007 | Ressonancia Magnetica |
| 10008 | Ultrassom |
| 10009 | Mamografo |
| 10015 | PET-CT |
| 20009 | Desfibrilador |
| 20012 | Ventilador/Respirador |
| 50001 | Maquina de Hemodialise |
| 70005 | Acelerador Linear |

---

### Servico Especializado (Principais)

| Codigo | Descricao |
|--------|-----------|
| 100 | Saude Reprodutiva |
| 101 | Pre-natal e Parto |
| 105 | Diagnostico por Imagem |
| 106 | Laboratorio Clinico |
| 107 | Endoscopia |
| 109 | Fisioterapia |
| 111 | Nefrologia |
| 112 | Oncologia |
| 115 | Reabilitacao |
| 116 | Saude Auditiva |
| 122 | Urgencia e Emergencia |
| 134 | Medicina Nuclear |
| 135 | Radioterapia |
| 136 | Quimioterapia |
| 137 | UTI |
| 157 | Dialise |
| 158 | Terapia Intensiva |

---

### Unidades Federativas

| Codigo | Sigla | Nome | Regiao |
|--------|-------|------|--------|
| 11 | RO | Rondonia | Norte |
| 12 | AC | Acre | Norte |
| 13 | AM | Amazonas | Norte |
| 14 | RR | Roraima | Norte |
| 15 | PA | Para | Norte |
| 16 | AP | Amapa | Norte |
| 17 | TO | Tocantins | Norte |
| 21 | MA | Maranhao | Nordeste |
| 22 | PI | Piaui | Nordeste |
| 23 | CE | Ceara | Nordeste |
| 24 | RN | Rio Grande do Norte | Nordeste |
| 25 | PB | Paraiba | Nordeste |
| 26 | PE | Pernambuco | Nordeste |
| 27 | AL | Alagoas | Nordeste |
| 28 | SE | Sergipe | Nordeste |
| 29 | BA | Bahia | Nordeste |
| 31 | MG | Minas Gerais | Sudeste |
| 32 | ES | Espirito Santo | Sudeste |
| 33 | RJ | Rio de Janeiro | Sudeste |
| 35 | SP | Sao Paulo | Sudeste |
| 41 | PR | Parana | Sul |
| 42 | SC | Santa Catarina | Sul |
| 43 | RS | Rio Grande do Sul | Sul |
| 50 | MS | Mato Grosso do Sul | Centro-Oeste |
| 51 | MT | Mato Grosso | Centro-Oeste |
| 52 | GO | Goias | Centro-Oeste |
| 53 | DF | Distrito Federal | Centro-Oeste |

---

## Relacionamentos

### Diagrama ER Simplificado

```
                    +-------------------+
                    |  raw_st           |
                    |  (Estabelecimento)|
                    +-------------------+
                    | PK: cnes          |
                    |     _ano_cmp      |
                    |     _mes_cmp      |
                    +-------------------+
                           |
          +----------------+----------------+----------------+
          |                |                |                |
          v                v                v                v
+-------------------+ +-------------------+ +-------------------+
|  raw_pf           | |  raw_eq           | |  raw_sr           |
|  (Profissional)   | |  (Equipamento)    | |  (Servico)        |
+-------------------+ +-------------------+ +-------------------+
| FK: cnes          | | FK: cnes          | | FK: cnes          |
|     _ano_cmp      | |     _ano_cmp      | |     _ano_cmp      |
|     _mes_cmp      | |     _mes_cmp      | |     _mes_cmp      |
| PK: + cns_prof    | | PK: + codequip    | | PK: + serv_esp    |
|       cbo         | +-------------------+ +-------------------+
+-------------------+
```

### Regras de Integridade

1. Todo registro em raw_pf, raw_eq e raw_sr deve ter um estabelecimento correspondente em raw_st
2. A chave de relacionamento e composta por (cnes, _ano_cmp, _mes_cmp)
3. Um estabelecimento pode ter multiplos profissionais, equipamentos e servicos
4. Um profissional pode estar em multiplos estabelecimentos (CNS e unico nacionalmente)

---

## Resumo Estatistico

| Componente | Quantidade |
|------------|------------|
| **Tabelas RAW** | 4 + 1 controle |
| **Semantic View** | 1 |
| **Views Fato** | 4 |
| **Views Agregadas** | 4 |
| **Total de Objetos** | 14 |
| **Dimensoes na Semantic View** | 28 |
| **Metricas na Semantic View** | 17 |
| **Dominios Documentados** | 15+ |

---

## Fontes de Referencia

- **Origem**: DATASUS - Ministerio da Saude do Brasil
- **Biblioteca ETL**: PySUS (https://github.com/AlertaDengue/PySUS)
- **Periodicidade**: Mensal
- **Formato Original**: .dbc (DBF comprimido)
- **Armazenamento**: Amazon S3 (staging) + Snowflake (dados finais)

---

## Historico de Versoes

| Versao | Data | Descricao |
|--------|------|-----------|
| 1.0 | 2026-01-13 | Versao inicial (DuckDB + SQLite) |
| 2.0 | 2026-01-13 | Migracao para S3 + Snowflake com Semantic Views |

---

**Desenvolvido por**: triggo.ai

**Consultor**: Walter Jose Horning Junior (walter.junior@triggo.ai)

**Ultima Atualizacao**: 2026-01-13
