"""
CNES ETL Pipeline - Extracao, Transformacao e Carga de dados CNES.

Pipeline para processamento de dados do Cadastro Nacional de
Estabelecimentos de Saude (CNES) do DATASUS.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
__version__ = "1.0.0"
__author__ = "triggo.ai"
