"""
Modulo de controle de execucao do pipeline CNES.

Gerencia o estado das execucoes do pipeline utilizando uma tabela
no Snowflake. Registra inicio, fim, status e quantidade de registros.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import logging
from typing import Optional, List, Dict

import polars as pl

from config import SNOWFLAKE_DATABASE, SNOWFLAKE_SCHEMA
from storage import salvar_parquet_s3

logger = logging.getLogger(__name__)

# Tabela de controle no Snowflake
TABELA_CONTROLE = "execucao_controle"


def init_controle() -> None:
    """
    Inicializa a tabela de controle de execucao no Snowflake.

    Cria a tabela se nao existir. A tabela armazena o historico
    de todas as execucoes do pipeline.
    """
    from snowflake.connector import executar_multiplos_sql

    sql = f"""
    CREATE TABLE IF NOT EXISTS {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE} (
        id INTEGER AUTOINCREMENT PRIMARY KEY,
        ano INTEGER NOT NULL,
        mes INTEGER NOT NULL,
        prefixo VARCHAR NOT NULL,
        qtd_registros INTEGER,
        iniciado_em TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
        finalizado_em TIMESTAMP_NTZ,
        status VARCHAR DEFAULT 'EXECUTANDO',
        UNIQUE(ano, mes, prefixo)
    )
    """

    try:
        executar_multiplos_sql([sql])
        logger.info(f"Tabela de controle verificada: {TABELA_CONTROLE}")
    except Exception as e:
        logger.error(f"Erro ao criar tabela de controle: {e}")
        raise


def ja_processado(ano: int, mes: int, prefixo: str) -> bool:
    """
    Verifica se um periodo/prefixo ja foi processado com sucesso.

    Args:
        ano: Ano de referencia (ex: 2024).
        mes: Mes de referencia (1-12).
        prefixo: Prefixo CNES (ST, SR, EQ, PF).

    Returns:
        True se ja foi processado com sucesso, False caso contrario.
    """
    from snowflake.connector import get_connection

    sql = f"""
    SELECT 1 FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
    WHERE ano = %s AND mes = %s AND prefixo = %s AND status = 'SUCESSO'
    LIMIT 1
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, (ano, mes, prefixo))
            result = cursor.fetchone()
            cursor.close()
            return result is not None
    except Exception as e:
        logger.warning(f"Erro ao verificar processamento: {e}")
        return False


def mes_completo(ano: int, mes: int, prefixos: list) -> bool:
    """
    Verifica se todos os prefixos de um mes foram processados.

    Args:
        ano: Ano de referencia.
        mes: Mes de referencia.
        prefixos: Lista de prefixos esperados.

    Returns:
        True se todos os prefixos foram processados com sucesso.
    """
    from snowflake.connector import get_connection

    sql = f"""
    SELECT COUNT(DISTINCT prefixo) FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
    WHERE ano = %s AND mes = %s AND status = 'SUCESSO'
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, (ano, mes))
            result = cursor.fetchone()
            cursor.close()
            count = result[0] if result else 0
            return count >= len(prefixos)
    except Exception as e:
        logger.warning(f"Erro ao verificar mes completo: {e}")
        return False


def registrar_inicio(ano: int, mes: int, prefixo: str) -> int:
    """
    Registra o inicio de uma execucao.

    Remove execucoes anteriores do mesmo periodo/prefixo e cria um novo
    registro com status EXECUTANDO.

    Args:
        ano: Ano de referencia.
        mes: Mes de referencia.
        prefixo: Prefixo CNES.

    Returns:
        ID da execucao criada.
    """
    from snowflake.connector import get_connection

    try:
        with get_connection() as conn:
            cursor = conn.cursor()

            # Remove execucao anterior do mesmo periodo/prefixo
            delete_sql = f"""
            DELETE FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
            WHERE ano = %s AND mes = %s AND prefixo = %s
            """
            cursor.execute(delete_sql, (ano, mes, prefixo))

            # Insere nova execucao
            insert_sql = f"""
            INSERT INTO {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
            (ano, mes, prefixo, status)
            VALUES (%s, %s, %s, 'EXECUTANDO')
            """
            cursor.execute(insert_sql, (ano, mes, prefixo))

            # Busca o ID gerado
            cursor.execute(f"""
                SELECT id FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
                WHERE ano = %s AND mes = %s AND prefixo = %s
            """, (ano, mes, prefixo))
            result = cursor.fetchone()
            exec_id = result[0] if result else 0

            cursor.close()
            logger.info(f"Execucao {exec_id} iniciada: {prefixo} {mes:02d}/{ano}")
            return exec_id

    except Exception as e:
        logger.error(f"Erro ao registrar inicio: {e}")
        raise


def registrar_fim(exec_id: int, qtd: int, status: str = "SUCESSO") -> None:
    """
    Registra o fim de uma execucao.

    Atualiza o registro da execucao com a quantidade de registros processados,
    data/hora de finalizacao e status final.

    Args:
        exec_id: ID da execucao.
        qtd: Quantidade de registros processados.
        status: Status final (SUCESSO, ERRO, SEM_DADOS).
    """
    from snowflake.connector import get_connection

    sql = f"""
    UPDATE {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
    SET finalizado_em = CURRENT_TIMESTAMP(),
        qtd_registros = %s,
        status = %s
    WHERE id = %s
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, (qtd, status, exec_id))
            cursor.close()
            logger.info(f"Execucao {exec_id} finalizada: {status} ({qtd} registros)")
    except Exception as e:
        logger.error(f"Erro ao registrar fim: {e}")


def salvar_df(df: pl.DataFrame, table: str, ano: int, mes: int) -> int:
    """
    Salva DataFrame Polars como Parquet no S3.

    Os dados sao salvos no S3 em formato Parquet, particionados por ano/mes.
    Posteriormente, os dados sao copiados para tabelas nativas no Snowflake.

    Args:
        df: DataFrame Polars com os dados a serem salvos.
        table: Nome da tabela (ex: raw_st, raw_pf).
        ano: Ano de referencia.
        mes: Mes de referencia.

    Returns:
        Quantidade de registros salvos.

    Raises:
        Exception: Se ocorrer erro ao salvar no S3.
    """
    if df.is_empty():
        logger.warning(f"DataFrame vazio para {table}, nenhum dado salvo")
        return 0

    try:
        count = salvar_parquet_s3(df, table, ano, mes)
        logger.info(f"{table}: {count} registros salvos no S3")
        return count

    except Exception as e:
        logger.error(f"Erro ao salvar {table} no S3: {e}", exc_info=True)
        raise


def listar_execucoes(ano: Optional[int] = None, mes: Optional[int] = None) -> List[Dict]:
    """
    Lista execucoes registradas no Snowflake.

    Args:
        ano: Filtrar por ano (opcional).
        mes: Filtrar por mes (opcional).

    Returns:
        Lista de execucoes filtradas.
    """
    from snowflake.connector import get_connection

    where_clauses = []
    params = []

    if ano:
        where_clauses.append("ano = %s")
        params.append(ano)
    if mes:
        where_clauses.append("mes = %s")
        params.append(mes)

    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

    sql = f"""
    SELECT id, ano, mes, prefixo, qtd_registros, iniciado_em, finalizado_em, status
    FROM {SNOWFLAKE_DATABASE}.{SNOWFLAKE_SCHEMA}.{TABELA_CONTROLE}
    {where_sql}
    ORDER BY iniciado_em DESC
    """

    try:
        with get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql, tuple(params))
            rows = cursor.fetchall()
            cursor.close()

            return [
                {
                    "id": row[0],
                    "ano": row[1],
                    "mes": row[2],
                    "prefixo": row[3],
                    "qtd_registros": row[4],
                    "iniciado_em": row[5],
                    "finalizado_em": row[6],
                    "status": row[7],
                }
                for row in rows
            ]
    except Exception as e:
        logger.error(f"Erro ao listar execucoes: {e}")
        return []
