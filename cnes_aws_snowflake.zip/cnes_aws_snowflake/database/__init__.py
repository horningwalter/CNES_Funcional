"""
Modulo de persistencia e controle do pipeline CNES.

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
from .db import (
    init_controle,
    ja_processado,
    mes_completo,
    registrar_inicio,
    registrar_fim,
    salvar_df,
    listar_execucoes,
)
