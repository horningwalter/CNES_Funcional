#!/usr/bin/env python3
"""
Pipeline ETL para dados do CNES (Cadastro Nacional de Estabelecimentos de Saude).

Este pipeline realiza as seguintes etapas:
1. Extracao: Baixa dados mensais do DATASUS via PySUS
2. Transformacao: Normaliza e padroniza os dados com Polars
3. Carga S3: Salva os dados em formato Parquet no Amazon S3
4. Carga Snowflake: Carrega os dados do S3 para o Snowflake
5. Semantic Views: Cria o modelo dimensional no Snowflake

Desenvolvido por: triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
"""
import sys
import logging
import argparse
from pathlib import Path

# Adiciona diretorio atual ao path para imports locais
sys.path.insert(0, str(Path(__file__).parent))

from config import PREFIXOS, PREFIXO_DESCRICAO, UFS
from extracao import download_cnes, get_previous_month
from transformacao import transform
from database import (
    init_controle,
    ja_processado,
    mes_completo,
    registrar_inicio,
    registrar_fim,
    salvar_df,
)

# Configura logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def run_etl(
    ano: int = None,
    mes: int = None,
    prefixos: list = None,
    ufs: list = None,
    force: bool = False
) -> dict:
    """
    Executa o pipeline ETL: DATASUS -> S3.

    Baixa dados do DATASUS, transforma e salva como Parquet no S3.
    O controle de execucao e mantido localmente em arquivo JSON.

    Args:
        ano: Ano de referencia (default: ano do mes anterior).
        mes: Mes de referencia (default: mes anterior).
        prefixos: Lista de prefixos CNES a processar (default: todos).
        ufs: Lista de UFs para filtrar (default: todas).
        force: Se True, reprocessa mesmo se ja existir.

    Returns:
        Dicionario com resultado por prefixo:
        {prefixo: {'status': str, 'registros': int}}
    """
    # Usa mes anterior se nao especificado
    if not ano or not mes:
        ano, mes = get_previous_month()

    # Usa todos os prefixos se nao especificado
    prefixos = prefixos or PREFIXOS

    logger.info(f"Iniciando ETL para {mes:02d}/{ano}")
    logger.info(f"Prefixos: {prefixos}")
    if ufs:
        logger.info(f"UFs: {ufs}")

    # Inicializa controle de execucao
    init_controle()

    # Verifica se mes ja foi completamente processado
    if not force and mes_completo(ano, mes, prefixos):
        logger.info(f"Mes {mes:02d}/{ano} ja processado completamente")
        return {"status": "JA_PROCESSADO"}

    resultado = {}

    # Processa cada prefixo
    for pref in prefixos:
        desc = PREFIXO_DESCRICAO.get(pref, pref)
        logger.info(f"Processando {pref} - {desc} ({mes:02d}/{ano})...")

        # Pula se ja processado e nao for force
        if not force and ja_processado(ano, mes, pref):
            logger.info(f"{pref}: Ja processado, pulando")
            resultado[pref] = {"status": "JA_PROCESSADO", "registros": 0}
            continue

        # Registra inicio da execucao
        exec_id = registrar_inicio(ano, mes, pref)

        try:
            # Extracao: baixa arquivos do DATASUS
            logger.info(f"{pref}: Baixando dados do DATASUS...")
            downloads = download_cnes(ano, mes, [pref], ufs)

            # Verifica se houve download
            if pref not in downloads or not downloads[pref]:
                logger.warning(f"{pref}: Nenhum dado disponivel")
                registrar_fim(exec_id, 0, "SEM_DADOS")
                resultado[pref] = {"status": "SEM_DADOS", "registros": 0}
                continue

            # Transformacao: limpa e padroniza dados
            logger.info(f"{pref}: Transformando dados...")
            df = transform(pref, downloads[pref])

            # Verifica se ha dados apos transformacao
            if df.is_empty():
                logger.warning(f"{pref}: DataFrame vazio apos transformacao")
                registrar_fim(exec_id, 0, "SEM_DADOS")
                resultado[pref] = {"status": "SEM_DADOS", "registros": 0}
                continue

            logger.info(f"{pref}: {len(df)} registros a serem salvos")

            # Carga: salva no S3
            logger.info(f"{pref}: Salvando no S3...")
            qtd = salvar_df(df, f"raw_{pref.lower()}", ano, mes)

            # Registra sucesso
            registrar_fim(exec_id, qtd, "SUCESSO")
            resultado[pref] = {"status": "SUCESSO", "registros": qtd}
            logger.info(f"{pref}: {qtd} registros salvos com sucesso")

        except Exception as e:
            logger.error(f"{pref}: Erro - {e}", exc_info=True)
            registrar_fim(exec_id, 0, "ERRO")
            resultado[pref] = {"status": "ERRO", "registros": 0, "erro": str(e)}

    return resultado


def run_snowflake_load(ano: int = None, mes: int = None) -> dict:
    """
    Carrega dados do S3 para o Snowflake.

    Cria as tabelas se necessario e carrega os dados Parquet do S3.

    Args:
        ano: Ano de referencia (opcional, carrega todos se nao informado).
        mes: Mes de referencia (opcional).

    Returns:
        Dicionario com resultado da carga por tabela.
    """
    try:
        from snowflake import (
            testar_conexao,
            criar_external_stage,
            criar_tabelas_raw,
            refresh_tabelas,
        )

        logger.info("Iniciando carga para Snowflake...")

        # Testa conexao
        if not testar_conexao():
            logger.error("Falha na conexao com Snowflake")
            return {"status": "ERRO", "erro": "Falha na conexao"}

        # Cria stage e tabelas
        criar_external_stage()
        criar_tabelas_raw()

        # Carrega dados
        resultado = refresh_tabelas(ano, mes)

        logger.info(f"Carga Snowflake concluida: {resultado}")
        return {"status": "SUCESSO", "tabelas": resultado}

    except ImportError:
        logger.warning("Modulo snowflake nao disponivel. Instale snowflake-connector-python")
        return {"status": "ERRO", "erro": "Modulo snowflake nao instalado"}

    except Exception as e:
        logger.error(f"Erro na carga Snowflake: {e}", exc_info=True)
        return {"status": "ERRO", "erro": str(e)}


def run_semantic_views() -> dict:
    """
    Cria as Semantic Views no Snowflake.

    As Semantic Views definem o modelo dimensional para analise
    dos dados CNES.

    Returns:
        Dicionario com resultado da criacao das views.
    """
    try:
        from snowflake import criar_semantic_views
        from snowflake.semantic import criar_views_auxiliares

        logger.info("Criando Semantic Views no Snowflake...")

        # Cria semantic views
        views_semanticas = criar_semantic_views()

        # Cria views auxiliares
        views_auxiliares = criar_views_auxiliares()

        logger.info(f"Semantic Views criadas: {views_semanticas}")
        logger.info(f"Views auxiliares criadas: {views_auxiliares}")

        return {
            "status": "SUCESSO",
            "semantic_views": views_semanticas,
            "views_auxiliares": views_auxiliares
        }

    except ImportError:
        logger.warning("Modulo snowflake nao disponivel")
        return {"status": "ERRO", "erro": "Modulo snowflake nao instalado"}

    except Exception as e:
        logger.error(f"Erro ao criar Semantic Views: {e}", exc_info=True)
        return {"status": "ERRO", "erro": str(e)}


def main():
    """
    Ponto de entrada principal do pipeline.

    Processa argumentos da linha de comando e executa o pipeline.
    """
    parser = argparse.ArgumentParser(
        description="CNES ETL Pipeline - triggo.ai",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main.py                      # Processa mes anterior, salva no S3
  python main.py --ano 24 --mes 6     # Processa junho/2024
  python main.py --snowflake          # Carrega dados do S3 para Snowflake
  python main.py --semantic           # Cria Semantic Views no Snowflake
  python main.py --full               # Executa pipeline completo (ETL + Snowflake)

Desenvolvido por triggo.ai
Consultor: Walter Jose Horning Junior (walter.junior@triggo.ai)
        """
    )

    # Argumentos de periodo
    parser.add_argument(
        "--ano", type=int,
        help="Ano de referencia (formato YY, ex: 24 para 2024)"
    )
    parser.add_argument(
        "--mes", type=int,
        help="Mes de referencia (1-12)"
    )

    # Argumentos de filtro
    parser.add_argument(
        "--prefixos", nargs="+", choices=PREFIXOS,
        help="Prefixos a processar (ex: ST SR EQ)"
    )
    parser.add_argument(
        "--uf", nargs="+", choices=UFS,
        help="UFs para filtrar (ex: PR SP RJ)"
    )

    # Argumentos de execucao
    parser.add_argument(
        "--force", action="store_true",
        help="Reprocessa mesmo se ja existir"
    )
    parser.add_argument(
        "--snowflake", action="store_true",
        help="Carrega dados do S3 para Snowflake"
    )
    parser.add_argument(
        "--semantic", action="store_true",
        help="Cria Semantic Views no Snowflake"
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Executa pipeline completo (ETL + Snowflake + Semantic)"
    )

    args = parser.parse_args()

    # Normaliza UFs para uppercase
    ufs = [u.upper() for u in args.uf] if args.uf else None

    # Executa conforme argumentos
    if args.full:
        # Pipeline completo
        logger.info("=== PIPELINE COMPLETO ===")

        logger.info("--- Etapa 1: ETL (DATASUS -> S3) ---")
        etl_result = run_etl(args.ano, args.mes, args.prefixos, ufs, args.force)
        logger.info(f"ETL: {etl_result}")

        logger.info("--- Etapa 2: Carga Snowflake ---")
        sf_result = run_snowflake_load(args.ano, args.mes)
        logger.info(f"Snowflake: {sf_result}")

        logger.info("--- Etapa 3: Semantic Views ---")
        sem_result = run_semantic_views()
        logger.info(f"Semantic: {sem_result}")

    elif args.snowflake:
        # Apenas carga Snowflake
        result = run_snowflake_load(args.ano, args.mes)
        logger.info(f"Resultado: {result}")

    elif args.semantic:
        # Apenas Semantic Views
        result = run_semantic_views()
        logger.info(f"Resultado: {result}")

    else:
        # Apenas ETL (DATASUS -> S3)
        result = run_etl(args.ano, args.mes, args.prefixos, ufs, args.force)
        logger.info(f"Resultado: {result}")


if __name__ == "__main__":
    main()
